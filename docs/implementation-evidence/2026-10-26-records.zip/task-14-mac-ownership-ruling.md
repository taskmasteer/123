# Approved Mac browser ownership refinement

Implement the already approved no-stale-PGID containment rule with a fixed private Playwright proxy and a watchdog-owned direct anchor child. This is a bounded native helper split, not a vendor patch or a general process broker.

The watchdog spawns and retains the unreaped direct Child/group before GO. It does not reap/try_wait before group cleanup and signals only that still-owned group. The proxy authenticates over owner-only IPC and transfers exactly Playwright fd1/2/3/4 plus bounded trusted Chrome arguments. Preserve default arguments, pipes and chromiumSandbox; reject sandbox-disabling/unsafe overrides. No public PID/executable/profile selector, inherited model/worker credentials or liveness-FD leaks. Helper modes do not initialize Tauri or credential access.

Proxy death or Playwright killing its proxy must trigger cleanup of the REAL browser anchor/group. Watchdog hard death or owner-pipe EOF must make the anchor terminate its own still-owned group; cleanup cannot depend solely on the watchdog surviving. Retain the anchor until cleanup acknowledgement, then reap/unregister safely. Never retry a stale PID/PGID signal.

Add pure/CLI ordering checks before GO, after GO and while browser work is active, including owner/proxy/watchdog failures. Actual macOS14 descendant cleanup remains pending matching-host acceptance.

Reason: remembering a Playwright descendant PID after Node may reap it does not preserve ownership against PID reuse. Cost: a small native helper-role split and targeted lifecycle tests; no new product scope or human approval gate.
