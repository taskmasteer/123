# Task7 review —81d934f..56f2674
Reviewer /root/review_task_7. Spec issues found; task quality Needs fixes. No Critical.

## Important
1. **Nested pool acquisition can deadlock revision reconciliation.** `packages/adapters/src/supabase-repository.ts:42` holds a transaction connection, then calls `this.revision(r.id)`, which runs through `this.pool.query` on another connection. The production entry limits the pool to four connections (`apps/control/api/index.ts:11`). Four concurrent candidate reconciliations on different sites can each hold one connection and wait indefinitely for another; other API requests then stall too. Read the existing revision using the current `tx`. Add a bounded regression with a one-connection pool.
2. **Managed registry stops permanently at 50 sites.** `apps/desktop/src/lib/remote-client.ts:33` always requests `/sites` without pagination parameters. The route defaults to 50 (`apps/control/src/routes/sites.ts:7`), while the App consumes only `list.items` and provides no way to follow `nextCursor`. Once there are 51 accessible sites, some disappear from the managed UI; newly created sites can also be invisible because ordering uses random UUIDs. Implement cursor navigation or complete bounded page retrieval, and cover a collection exceeding 50 sites.

## Minor
- supabase-repository.ts:44 and remote-client.ts:13 compress transactional/validation logic into single lines; expand touched modules into blocks/helpers when doing later work.
- Report still contains line-ending/color-env notices. Normalize runner/env/repository endings during later verification cleanup.

## Cannot verify
Deployed Supabase/Auth/SMTP/PostgREST, R2 access controls, Vercel execution and supported native behavior remain documented acceptance gaps. Task8/9 deferred features fail closed.

## Strengths/checks
Fresh DB membership after crypto JWT, meaningful RLS/grants/immutable same-site constraints, actual byte verification/rechecked lease, durable invitation send and OTP/password retry, actual HTTPS/blocked-cookie test. Read complete two-commit diff; inspected unchanged core/editing.ts for revision persistence/current job consumption and CreateSiteDialog.tsx for managed create compatibility. No reported test reruns or mutations.
