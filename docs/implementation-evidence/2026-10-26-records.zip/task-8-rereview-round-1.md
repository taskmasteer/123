1. **Job controls use read permission for editing — ADDRESSED.** `packages/adapters/src/postgres-queue.ts:12–17` derives permission from the locked job, reloads current DB membership, requires scoped `site:edit` for edits, and requires ownership or admin for generation. Retry/cancel invoke it after locking at lines86–88 and152–154. `tests/integration/queue.test.ts:145–192` covers direct-route owner/assignment/demotion denials, unchanged complete job/admission rows, and positive admin/restored-editor controls.

2. **Native lifecycle can forward credentials across installations — ADDRESSED.** `apps/desktop/src/lib/remote-client.ts:38` supplies configured `expectedOrigin` for start/stop/revoke. Required native DTO fields and `bound_enrollment` reject mismatches before callbacks (`apps/desktop/src-tauri/src/managed.rs:16–28,78–92,157–184`). Tests at lines311–393 exercise actual DTO parsing, zero private-pipe callbacks for mismatched pending/acknowledged enrollment, unchanged saved credentials, and matched actions. Missing-origin payloads are rejected at line462. Consumer inspection found no omitted production lifecycle caller.

**New breakage in the fix diff:** None found.

**Out-of-Scope Observations:** Existing untranslated WorkerList progress labels remain deferred (`apps/desktop/src/features/workers/WorkerList.tsx:80`). The unobserved revocation lock-wait barrier remains deferred (`tests/integration/failover.test.ts:248`); `task-8-report.md:116` now correctly narrows its evidence to rejection after revocation, without claiming an observed race interleaving. Existing Task9 settlement and platform/cloud acceptance limitations remain unchanged.

**Evidence check:** Read the complete packaged fix diff once and inspected relevant authorization/DTO/private-pipe dependencies read-only. The appended report names covering integration, renderer and native commands with outcomes consistent with the added assertions:16 integration passes/1 existing skip,6 renderer passes, and15 native passes/1 ignored/1 filtered. No suites rerun; no unresolved code doubt required a focused test.

**Spec compliance:** Both scoped authorization/origin requirements satisfied, including the clarified owner-only generation controls.

**Task quality:** Approved for this fix scope; prior deferred acceptance limits remain.

**Fix round:** All findings addressed, no new Critical/Important breakage.
