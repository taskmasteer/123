### Task 10: Импорт пачек и реестр на 5000 записей

**Files:** создать `packages/core/src/import/{rows.ts,csv.ts,xlsx.ts}`, `apps/desktop/src/features/batches/{BatchImport.tsx,BatchTable.tsx,BatchDetail.tsx}`, `apps/control/src/routes/batches.ts`; тесты `packages/core/test/import.test.ts`, `tests/integration/batches.test.ts`, `tests/e2e/batch.spec.ts`.

**Interfaces:** `parseImport(file: {name:string; bytes:Uint8Array}): Promise<{rows: ImportRow[]; issues: RowIssue[]}>`; ImportRow = SiteInput + rowNumber; RowIssue = rowNumber/column/code/message. `submitBatch(actor, validRows, requestKey): Promise<{batchId:string; siteIds:string[]}>`; `pauseBatch|resumeBatch|cancelBatch(actor,batchId): Promise<void>`.

- [ ] **1. Написать тесты:** CSV с quoted commas и BOM, XLSX без исполнения формул/макросов, пустые ячейки, локальное сопоставление logo, дубликаты IDN/ASCII и существующие домены. Проверить отдельно «О сайте» у одной строки; ошибочные строки не теряются при запуске корректных.
- [ ] **2. Запустить** `npm test -- packages/core/test/import.test.ts`, `npm run test:integration -- batches`, затем e2e; ожидать failures.
- [ ] **3. Реализовать parse/preview/submit.** Никакого автоматического скачивания URL из logo. Не принимать повтор запроса как новую пачку, не перезаписывать существующие сайты. Кнопки паузы/продолжения/отмены выполняют серверные операции прав. Cursor pagination и server-side filters; не загружать все 5000 строк в renderer.
- [ ] **4. Прогнать** 100 fake jobs и 5000 записей с 2 workers, ошибками, паузой и продолжением. Assert число уникальных siteId, отсутствие пропусков/повторов страниц при неизменяемом dataset, продолжение остальных jobs после ошибки одной строки. Показать measured timings; не называть это нагрузочным тестом 5000 реальных публикаций.
- [ ] **5. Commit:** `feat: add batch imports and paginated site management`.

