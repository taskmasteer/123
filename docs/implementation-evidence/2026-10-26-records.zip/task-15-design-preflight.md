# Task15 transport design preflight

Status: READY for controller productionGO; read-only source audit against BASE 2d2a9e4. No implementation, tests, services, Git actions, or external calls performed.

## Decision and evidence

Use bounded HTTP batches plus durable SQL preparation; increasing deadlines alone leaves millions of calls. A new archive/container, queue, service, framework, or dependency is unnecessary. Keep core createBackup/restoreBackup, ExportHandle/RestoreReport, schema-8 archive bytes, old readers, STORE/ZIP64/GCM, provenance and quarantine semantics unchanged.

Audit: NativeArchives.managedBackup/chunked/managedRestore use serial per-record/24KB calls; control app.ts body() universally caps 64000B; PostgresBackup.install pages20 but performs every validation/remap/IO before committing. Task12 final measured target is900009 expanded metadata/270000 descriptors/532154933B metadata;13.5GB is BODY PROJECTION ONLY.

## Contracts and routes

Create contracts/recovery-transfer.ts with strict parsers and no adapter imports:
```ts
type Binding={version:1;id:string;sourceId:string;records:number;digest:string};
type Part={seq:number;offset:number;size:number;sha256:string;base64:string;complete:boolean};
type RecoveryTransferPage={binding:Binding;kind:'metadata'|'resources';cursor:string;nextCursor:string|null;items:Part[];expiresAt:number};
type RecoveryPreparationProgress={binding:Binding;phase:'staging'|'preparing'|'validating'|'ready'|'committed'|'cancelled'|'failed';prepared:number;total:number;cursor:string;error?:{code:AppErrorCode;message:string}};
```
Add stage envelope {binding,cursor,digest,kind,items}; digest hashes exact canonical framing and decoded bytes. Routes: GET snapshots/:id/batch?cursor=..., POST restores/:id/batch, /prepare, /commit; POST snapshots|restores/:id/renew and /cancel. Existing begin/mappings remain; beginRestore additionally binds streamed authenticated archive-inventory digest. First stage seals verified mappings; later mapping changes conflict.

Ports remain readBatch(actor,id,cursor), stageBatch(actor,id,batch), prepareBatch(actor,id), commitPrepared(actor,id). Actor comes from authenticated control. Opaque bounded cursors identify version, frozen binding, lane, seq/offset; validate against durable server state, never accept SQL/table/objectKey/path selectors. Read cursors deterministically replay immutable snapshot pages. Metadata pages issue resource cursors restricted to their descriptor window.

Each request/response: decoded raw≤1MiB, encoded JSON≤2MiB, ≤256 metadata parts or64 resource parts. Metadata records≤1000000B; split at remaining batch capacity, require exact offset/size/hash and complete marker. Resource selectors resolve only staged/snapshot descriptors; existing path/namespace/typed-table validators remain authoritative. Native renderer/Rust/Node JSON64000/raw24000 stay unchanged. Only exact authenticated transfer routes select larger control parsing and trusted Node response limits; all other routes retain limits.

## Ownership and durable replay

remote-recovery-transfer.ts owns bounded packing, response validation, backpressure, retry and private disk spooling. One NativeArchives-owned scheduler permits≤4 HTTP requests total across operations; sequential cursor lanes are valid. No whole-installation arrays/Maps or giant Promise.all; metadata spool/index uses existing disk patterns. Existing bounded32MiB archive-member processing remains.

009_recovery_transfer.sql adds private, revoked transfer-progress and batch-receipt/work-claim tables, indexed by transfer/lane/cursor and expiry; original ordinal namespaces remain. Receipts atomically bind full batch hash and accepted prefix; exact retries return/resume that prefix, changed replay conflicts, gaps reject. Bulk SQL inserts/counters acknowledge only persisted bytes; completed objects reuse immutable verified digest records. An interrupted object PUT retries conditional creation and verifies existing bytes before acknowledgement. Partial batches keep durable subcursor/work claims, so retries never repeat acknowledged objects or count bytes twice.

Network retry owner allows three transient retries with100/500/1500ms injected delays; ambiguous POST retries identical cursor/hash. Auth, validation, binding/hash, cancellation and expiry errors never retry. Final commit replay returns durable report.

## Preparation and final installation

postgres-recovery-transfer.ts owns pages, receipts, renewal and cleanup. Extract current install transformations/validators into postgres-restore-preparation.ts; postgres-backup delegates, preserving reviewed mapping/evidence/job/publication rules.

Preparation processes≤256 records/1MiB metadata per call, plus existing bounded per-record payload work, stopping between records after10s. Persist transformed rows at6B ordinals, counts/catalog proofs and cursor atomically; fenced work claims prevent concurrent/replayed preparation from overwriting progress. Batch dependency lookups and prepared INSERTs, retaining bounded caches. Check bytes/hashes/checkpoint evidence, exact catalog closure, identity mapping, missing references and predecessor cycles before ready; expensive validation has durable phases. No whole-installation hydration.

Commit accepts only ready frozen state. Under existing FIRST exclusive transaction: fresh admin/lease, empty target, setwise typed INSERTs/pointers/sequences/quarantine/report and commit. Move closure/crypto/R2/filesystem work entirely before it. Bound lock wait5s, statements15s, cumulative SQL105s; exact commit client180s below Fluid240s. Observe actual target commit duration; optimize or report blocker if bounds fail.

## Lifetime and cancellation

Successful batches renew only currently live snapshot/restore and matching pins to60min, capped24h from creation; idle active runners renew every30s. Native working-operation expiry follows successful renewal within the same cap; finished handles retain existing lifetime. Never revive expired capabilities or claimed/deleted inventory.

30s ordinary HTTP deadlines, bounded owned IO, operation AbortController and durable work claims fence late completions. Cancel/role loss/session-origin change stops admission, aborts and awaits owned requests; server rechecks authority/expiry before every acknowledgement. Mark cancellation terminal before cleanup; retain tracked immutable remnants until claims drain/expire, then delete bounded64-row pages outside transactions. Existing worker maintenance and recovery entry points sweep expired transfers; no new scheduler. close/root-switch drains maintenance and archive-owned work before persistence, excluding the initiating restore promise to avoid self-wait.
Current Auth audit: RemoteClient obtains refreshed access tokens per native call, while NativeArchives background work captures the original token; context derives JWT session_id only after /session accepted that exact bearer (otherwise token hash). Keep an in-memory credential slot per operation. Validated status/renew calls may replace it only for identical actor, origin, managed mode and verified session_id; server transfer scope binds that same verified session identity. Never infer sameness from userId alone. Opaque/no-session tokens remain exact-token bound; refresh returns clear reauthorization-required state and preserves resumable durable staging only until existing expiry. No refresh/access token persistence. RemoteClient disposal/logout/mode switch closes its tracked operation IDs through the original captured client before credentials clear; native close aborts/drains even when authority has expired and grants no read/renew rights. New-session/role-loss detection cancels instead of adopting credentials; absence of validated polling stops renewal. Working status caches same-token context≤30s; token changes/new actions/handle release reverify. Every batch still checks fresh server admin. Count session/renew overhead in actual HTTP budgets.

## Verification after GO

Behavioral RED first through existing NativeArchives→createApp→disposable SQL path, not missing imports. Factor retention-capacity seed into recovery-transfer-fixture.ts; retain original metadata-only532154933B evidence. Full-count small-body variant uses real valid source/state/PNG/evidence and270000 descriptors, explicitly distinct bytes/projection. Assert backup metadata≤5000 HTTP calls, restore metadata/stage/preparation≤20000, concurrency≤4, bounds, empty target until separate commit, source gone, stable IDs/history/Auth/provenance/quarantine. Planning minimum3516 metadata pages each direction; actual counters decide acceptance. Inject lost/changed/partial replay, missing/hash/oversize, expiry/role/cancel and delayed maintenance without real sleeps.

Run requested new worker/SQL commands, covering backup/native/history/archive/fence tests, typecheck/build; report exact commands/results, calls/bytes/durations separately from conditional RTT and pending Task14 full-body/native/provider acceptance. Migration009 is operational only, excluded from managedRecoveryTables: portable logical schema remains8. Preserve controller plan edit; self-review and scoped commit only after GO.

