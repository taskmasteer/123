**Durable fairness at production retry cadence — ADDRESSED.** `packages/adapters/src/postgres-publication.ts:473` orders eligible reservations by their durable selection stamp, retaining existing attachment/provider eligibility predicates. Lines476–479 acquire established locks and CAS the exact PostgreSQL timestamp before fallible work; stale competing selections cannot advance. Lines167–168 retain the stamp after attachment. A slow failing orphan loses priority to eligible healthy work while keeping unresolved exclusion and exact binding.

**New breakage:** None found in the fix diff.

**Out-of-scope observations:** Previously deferred classified diagnostics, bundle warning and live provider/native acceptance remain nonblocking. No additional observations.

**Evidence:** Read the complete282-line packaged diff once and scoped locking/worker dependencies. `tests/integration/publication.test.ts:237` exercises actual runWorker, fresh services, two healthy outboxes and one materialized step. Lines286–310 model40-second failures and execute the runner's selected15-second/3-second waits by shifting SQL deadlines consistently. Lines311–319 assert repeated failures, all healthy publications completing exactly once, and failed reservation retained exclusion. This addresses the prior timing omission.

**Verification evidence:** Final report records publication17 passed, pipeline26 passed, focused cadence1 passed, typecheck/build/whitespace successful. Named coverage agrees with diff. No suites rerun, mutations or external actions.

**Spec compliance:** Pass for scoped fairness; publication exclusion/binding intact.

**Task quality:** Pass—durable ordering and production-cadence regression address defect.

**Fix round:** All findings addressed; no new Critical/Important breakage.
