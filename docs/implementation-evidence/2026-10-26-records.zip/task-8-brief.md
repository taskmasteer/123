### Task 8: Два исполнителя и восстановление по сохранённым этапам

**Files:** создать `supabase/migrations/002_queue_leases.sql`, `packages/adapters/src/postgres-queue.ts`, `apps/control/src/routes/jobs.ts`, `apps/worker/src/runner.ts`, `apps/desktop/src/features/workers/WorkerList.tsx`; изменить pipeline.ts; тесты `tests/integration/queue.test.ts`, `tests/integration/failover.test.ts`.

**Interfaces:** реализация Queue; `POST /worker/jobs/claim`, `POST /worker/jobs/:id/heartbeat|checkpoint|finish` требуют worker token и актуальный Lease. `runWorker(deps: WorkerDeps, workerId: string, signal: AbortSignal): Promise<void>`. Изменения сайта используют compareAndSet и тот же номер владения.

- [ ] **1. Написать конкурентные SQL-тесты** с двумя соединениями и управляемыми часами.
```ts
expect(claimedJobIds).toHaveLength(new Set(claimedJobIds).size);
expect(firstLease.expiresAt - now).toBe(120_000);
expect(heartbeatIntervalMs).toBe(30_000);
expect(maxParallelJobsPerDevice).toBe(2);
expect(staleCheckpointError.code).toBe('STALE_LEASE');
expect(resumedJob.stage).toBe(lastCommittedStage);
```
Сбой после R2 upload до commit оставляет объект-сироту, не ложный завершённый этап; принятие кандидата с устаревшей базой → CONFLICT.
- [ ] **2. Запустить** `npm run test:integration -- queue failover`; ожидать failures без SQL-функций.
- [ ] **3. Реализовать claim одной транзакцией FOR UPDATE SKIP LOCKED.** Lease generation увеличивается при новой выдаче; heartbeat/checkpoint/finish CAS. Не держать транзакцию во время API вызова. SECURITY DEFINER с пустым search_path и закрытым EXECUTE; вызов только сервером. Пауза заканчивает текущий этап и прекращает дальнейшую выдачу; отмена не удаляет published.
- [ ] **4. Выполнить реальные failover-тесты:** остановить worker после checkpoint, передать другому; возобновить старый и отвергнуть его результат. При отсутствии online workers задания ждут. У UI видны last heartbeat и последний сохранённый этап. Повтор запроса модели после crash возможен и честно учитывается в usage.
- [ ] **5. Commit:** `feat: add durable leases and multi-device recovery`.

