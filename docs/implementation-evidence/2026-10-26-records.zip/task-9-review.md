### Spec Compliance

- ❌ **Issues found:** the required resumable handoff has a crash window between committing the durable publication reservation and creating its provider ledger. An interrupted handoff can permanently reserve a site without any automatic or UI continuation path. See Important issue1.
- ✅ The requested contracts, core publication helpers, Vercel adapters, control routes and integration tests are present. Migration004 follows approved numbering.
- ✅ Separate provider outcomes/application settlement, account capacity, cancellation evidence, accepted-draft eligibility, safe desktop DTOs and server-only credentials are preserved.
- ⚠️ Actual REST/configuration/header, public DNS/TLS and native-platform acceptance remains unverified; opt-in test is separated from fixtures.

### Strengths

- `packages/adapters/src/postgres-publication.ts:154–213,389–398`: mutation dispatch is durable before HTTP; response commits require live account and publication-step authority. Unknown create traverses pages, no blind retry.
- `packages/adapters/src/postgres-publication.ts:185–198,326–347,409–426`: cancellation preserves unresolved effects/building capacity; verified external success survives CAS conflict without overwrite.
- `packages/adapters/src/postgres-publication.ts:42–84`, `packages/core/src/editing.ts:159`: direct publication reuses shared evidence and current permissions. `tests/integration/publication.test.ts:300` covers accepted/rejected/unaccepted/demoted cases.
- `apps/worker/src/pipeline.ts:79–87,259–272`, `apps/worker/src/runner.ts:35–45`: exact settlement precedes obsolete lease reads; continuation independent of both slots. `tests/integration/publication.test.ts:347` covers remote orchestration/loss/offline recovery.
- `packages/adapters/src/public-https.ts:29–151`: DNS admission, pinned lookup, normal TLS, isolated agent, remote-address check and bounded streaming/redirect validation form credible SSRF boundary.
- `packages/core/src/publication.ts:5–21`, `apps/control/api/index.ts:29`, `apps/desktop/src/lib/remote-client.ts:8–19`: publisher config separated from archives, server credentials, explicit desktop projections.

### Issues

#### Critical

None found.

#### Important

1. **Recover reservations whose provider attachment never completed.** Files: `apps/control/src/routes/jobs.ts:107–108`; `packages/adapters/src/postgres-publication.ts:62–64,105–126,152,428–431`.

Both generation and draft handoffs commit reservePublication/reserveControllerPublication before attach. Attachment performs fallible reads, including private R2 checkpoint loading for generation, before inserting provider_publications.

Process interruption/storage failure leaves unresolved reservation and publication site operation, but no provider ledger. Tick/latest/domain/status enumerate only provider_publications. claim_job excludes publication-owned sites; fresh editor lacks original request identity. Automatic continuation/UIResume cannot recover, durable exclusion persists indefinitely.

Create recoverable provider record atomically with reservation admission, or discover/idempotently attach unresolved reservations missing a ledger using exact original controller/job binding. Cover process loss immediately after reservation commit for both origins, including recovery after original worker lease expiry and without original UI request key.

#### Minor

1. **Persist safe reason for attention states.** `packages/adapters/src/postgres-publication.ts:372–386`: catch discards every diagnostic including config mismatch, invalid provider response/unavailable frozen policy. Generic repeated phases hide actionable problems. Persist bounded classified private error code and safe operator explanation.
2. **Resolve desktop bundle warning.** `apps/desktop/src/App.tsx:19`, `task-9-report.md:56–57`:501.07KB JS chunk warning; secondary management/editor panels may load on demand. Existing color warnings documented; output not pristine.

### Cannot verify

- `tests/integration/vercel-contract.test.ts:38–73` opt-in/unrun: actual publisher vercel.json ingestion, static/default/error headers, account rights, DNS/cert readiness. README76–82 records gate.
- Reported tests assessed against code/evidence; none rerun. Initial coldRetry timeout remains unreproduced stability concern, not reproduced publication defect.
- Bounded dependencies: postgres-queue/003 migration reservation/settlement/lease; supabase-repository admission recovery; shared editing replay/evidence; R2 bytes/paths. These confirm handoff gap and protections, no broad earlier-task review.
- Full packaged diff read in bounded sections, truncated output recovered. No source/index/HEAD mutation/live action/test execution.
- Official create/list/alias docs checked: https://vercel.com/docs/rest-api/deployments/create-a-new-deployment ; https://vercel.com/docs/rest-api/deployments/list-deployments ; https://vercel.com/docs/rest-api/aliases/get-an-alias . Documentation checks, not live acceptance.

### Assessment

**Task quality: Needs fixes.** Provider saga/fencing/cancellation/transport substantially exercised; reservation-ledger recovery gap blocks promised resumability. Fix boundary with targeted crash coverage before approval.
