### Task 14: Сборки Windows и macOS и пилот

**Files:** создать `scripts/{prepare-runtime.mjs,prepare-browser.mjs,check-package.mjs}`, `.github/workflows/verify.yml`, `docs/{development.md,pilot-report.md}`; изменить tauri.conf.json, Rust resource resolution, корневой package.json; тест `tests/e2e/pilot.spec.ts`.

**Interfaces:** `npm run verify` = typecheck + unit + integration + build; `npm run package:desktop` собирает конкретный OS target; `npm run pilot -- --fixtures` использует только fake adapters, `--live` требует явно настроенные подключения и выбранные demo domains. Отчёт фиксирует реальные результаты отдельно для каждой платформы и провайдера.

- [ ] **1. Написать package smoke и pilot сценарий:** на чистой машине без Node/npm приложение запускает нужный worker/browser; закрытие панели завершает children; повторный запуск сохраняет сессию/очередь. UI обычного user не запускает unenrolled worker.
- [ ] **2. Запустить fixture pilot** и проверить, что missing runtime/браузер/credentials приводят к понятной ошибке, а не тихому зависанию.
- [ ] **3. Упаковать pinned Node + compiled JS + matching Playwright Chromium** для Windows x64 и macOS arm64/x64. Не использовать Node SEA/pkg как обязательное условие v1. Tauri externalBin/resources, PLAYWRIGHT_BROWSERS_PATH, profiles отдельно в app-data. Обычному клиенту browser не обязателен до включения доверенного worker; для пилота допустим общий полный installer. Проверить WebView2 и вложенные macOS executable/helpers.
- [ ] **4. Прогнать 5–10 личных некоммерческих демосайтов после настройки аккаунтов.** Пять направлений, manual/auto topics, AI edit/refine/reject/publish, visual edit, rollback, два устройства, failover, custom-domain HTTPS и restore. Измерить размер, токены, время и ошибки. Получить визуальную оценку пользователя. Реальные Mac-тесты, подписание/notarization и сервисные integration tests, которые не выполнены, явно остаются незавершёнными; без них не заявлять полную готовность.
- [ ] **5. Commit:** `test: add cross-platform packaging and pilot evidence`.

## Общая проверка и критерии завершения

Команды в плане становятся доступными в соответствующих задачах. Сначала каждый тест должен подтвердить отсутствие нужного поведения, затем пройти после реализации. Не писать проверки, которые лишь повторяют внутренний код; тестировать наблюдаемые результаты и границы доверия. Не запускать повторно весь набор после каждого косметического изменения.

Перед передачей: `npm run verify`, fixture e2e и Windows desktop smoke. Отдельно — PostgreSQL race/RLS, provider contract smoke, macOS package smoke, live pilot. Ошибки среды не подменять успехом mock-тестов. Не выполнять push, публикацию приложения, покупки или включение платных тарифов как побочный эффект проверки.

Каждый commit содержит только файлы завершённой задачи и связанные документы. При параллельной реализации worktrees/ветки должны быть согласованы; интерфейсы изменяются вместе с потребителями. Префикс новых веток — `codex/`.

## Покрытие спецификации

| Требование | Задачи |
|---|---|
| Windows/macOS, русский UI, английские сайты | 3, 4, 14 |
| HTML/CSS/JS, отсутствие форм/лишних функций | 2, 3, 6 |
| 14 референсов, 5 стилей, разнообразие, редкие изображения | 3, 6, 14 |
| Создание и правки через ИИ в первом проходе | 3–6 |
| user/spec-user/admin, свои и назначенные сайты | 1, 5, 7 |
| Файлы admin, private R2, ключи на доверенных устройствах | 2, 6, 7, 12 |
| 2 устройства, очередь, heartbeat, продолжение этапов | 7, 8 |
| CSV/XLSX, пачки 100, 5000 записей | 1, 8, 10 |
| Публикация, DNS, лимиты Hobby, unknown result | 9 |
| Предпросмотр и визуальные правки | 2, 4, 5, 11 |
| История current+5, export, independent backup | 12 |
| HTTPS, availability, usage без денежного cap | 13 |
| Бесплатный личный пилот до покупки услуг | 6, 9, 14 |

## Технические источники

Проверены 26 октября 2026 года; при реализации сверить изменяемые контракты.

- [Responses tool loop](https://developers.openai.com/api/docs/guides/function-calling) и [управление контекстом](https://developers.openai.com/api/docs/guides/conversation-state): сохранять outputs и результаты tools; собственный чат не зависит от срока хранения response у провайдера.
- [Tauri sidecars](https://v2.tauri.app/develop/sidecar/) и [capabilities](https://v2.tauri.app/security/capabilities/): отдельный исполняемый файл и явные permissions для custom commands.
- [Playwright browsers](https://playwright.dev/docs/browsers) и [launch options](https://playwright.dev/docs/api/class-browsertype#browser-type-launch): matching revision и явный chromiumSandbox.
- [Vercel upload](https://vercel.com/docs/rest-api/deployments/upload-deployment-files), [create](https://vercel.com/docs/rest-api/deployments/create-a-new-deployment), [REST promotion](https://vercel.com/docs/rest-api/projects/point-production-traffic-to-a-given-deployment), [alias lookup](https://vercel.com/docs/rest-api/aliases/get-an-alias): это разные восстанавливаемые шаги.
- [Vercel Function limits](https://vercel.com/docs/functions/limitations): request/response до 4,5 МБ; не помещать архив сайта в body и не ждать длительную генерацию внутри handler.
- [R2 presigned URL](https://developers.cloudflare.com/r2/api/s3/presigned-urls/) и [S3 compatibility](https://developers.cloudflare.com/r2/api/s3/api/): прямой PUT, проверка операции/объекта и conditional requests.
- [Supabase JWT](https://supabase.com/docs/guides/auth/jwts), [RLS](https://supabase.com/docs/guides/database/postgres/row-level-security), [PostgreSQL SKIP LOCKED](https://www.postgresql.org/docs/current/sql-select.htm): серверная аутентификация, проверка свежих прав и атомарная выдача.

## Самопроверка плана

Проверены покрытие спецификации, согласованность интерфейсов, тесты пяти рисков, порядок зависимостей и отсутствие покупок в подготовительных шагах. Внешние ключи, DNS и Mac требуются для конкретных интеграционных испытаний; они не мешают этапу A. Продуктовый код и результаты выполнения тестов в этот документ не включены, поскольку реализация ещё не начата.

