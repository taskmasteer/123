# Task 6 Responses contract research

Verified against official OpenAI documentation on 2026-10-26. Read-only preparation; no credentials, model calls, installations, or implementation changes. Text/image model IDs remain account configuration; examples intentionally use `config.model`.

## Function tools and loop

Responses function definitions put `name`, `parameters`, and `strict` directly beside `type: "function"`. Set `strict: true` explicitly: every object schema needs `additionalProperties: false`, every property must be required, and optional values use nullable types. Omitted `strict` can fall back to best effort. Parse JSON arguments, then validate tool names and arguments locally before dispatch. Tool results use the returned `call_id`, not the item `id`. Setting `parallel_tool_calls: false` requests at most one tool call per response; still inspect the complete array defensively. [Function calling](https://developers.openai.com/api/docs/guides/function-calling)

```ts
const readTool = {
  type: "function", name: "read", strict: true,
  parameters: {
    type: "object", properties: { path: { type: "string" } },
    required: ["path"], additionalProperties: false,
  },
};
// After validating and executing a returned function_call:
history.push({ type: "function_call_output", call_id: call.call_id,
  output: JSON.stringify(result) });
```

Application policy: list/read/write/replace only; unknown tools stop with explicit failure. Track repeated call signatures plus file-change progress; bound total turns and stop a stalled loop with `needs_attention`. Strict JSON shape is not authorization or path validation.

## Continuity and replay

Prefer `store: false` plus the application's private replay history for this task. Preserve every response output item in order, including reasoning `encrypted_content`, function calls, and assistant `phase`; append correlated function outputs afterward. Current docs say stateless encrypted reasoning is returned by default; legacy `include: ["reasoning.encrypted_content"]` remains accepted but is unnecessary. Keep opaque reasoning opaque. Supported reasoning-context settings depend on the configured model; omit model-specific tuning by default. Preserve original assistant phase (`commentary` or `final_answer`), never infer a final answer merely from nonempty text. [Reasoning guide](https://developers.openai.com/api/docs/guides/reasoning)

```ts
// Conceptual HTTP loop, using replay-compatible items without flattening:
const body = { model: config.model, store: false, instructions,
  input: history, tools, parallel_tool_calls: false };
// Decode and validate response before dispatching tools.
history.push(...replayable(response.output));
// replayable preserves complete input-compatible item data, including phase.
// With the official JS SDK its documented helper is toResponseInputItems.
```

Alternatives: stored response chains use `previous_response_id`; Conversations provide durable server-side conversation IDs and items. Responses otherwise have a default 30-day retention; Conversations items have no 30-day TTL. Neither should become the application's chat/file source of truth. [Conversation state](https://developers.openai.com/api/docs/guides/conversation-state)

Do not combine `conversation` and `previous_response_id`. Resend instructions on chained requests because earlier top-level instructions are not inherited. A raw `fetch` adapter must read text from `output` message content; `output_text` is an SDK convenience, not a reliable raw-HTTP field. [Create response reference](https://developers.openai.com/api/reference/cli/resources/responses/methods/create)

## Explicit terminal and wait states

Inspect every message's content for `{type:"refusal", refusal:"..."}`. Refusal can accompany a completed response; return an explicit refusal outcome instead of treating it as successful generation or retrying it. `incomplete` must remain explicit (for example, `max_output_tokens` or filtering); partial files/text cannot imply successful completion. [Structured outputs error handling](https://developers.openai.com/api/docs/guides/structured-outputs)

Handle response `error`, status `failed`/`cancelled`/`incomplete`, and transport errors separately. For the initial implementation, reject unexpected queued/in-progress responses instead of silently finishing. Final completion requires a completed response, no pending tool calls, no refusal, and a final assistant answer; an explicitly commentary-only message is not final. Typed events also expose incomplete/failed outcomes if streaming is added later. [Responses streaming reference](https://developers.openai.com/api/reference/resources/responses/streaming-events)

For temporary 429/503, honor valid `Retry-After` as a minimum; otherwise exponential backoff with jitter. Bound retries and total delay; defer long server waits instead of retrying early. Use one retry owner so worker and adapter loops cannot multiply the Task 6 maximum of three retries. Cancellation interrupts fetch and backoff. [Rate limits](https://developers.openai.com/api/docs/guides/rate-limits)

Inspect error type/code: 429 also covers exhausted credit and organization/project spend or usage limits, which require user action rather than rapid retries. Map these into the existing provider-wait/attention workflow with a sanitized explanation. [Error codes](https://developers.openai.com/api/docs/guides/error-codes)

## Optional images and caching

Responses supports an `image_generation` tool with its image model configured separately; generated output is an `image_generation_call` whose `result` contains base64 image data. The direct Images API is another supported route. Validate and persist decoded bytes as an artifact. Neither the fetched image guide nor its examples establish a seed or idempotency guarantee; do not send the application's selection seed as if OpenAI supported that contract. [Image generation](https://developers.openai.com/api/docs/guides/image-generation)

Application policy/inference: persist the deterministic 0.1 selection decision before any request; no configured image model means disabled images and zero image calls. Key a private result cache by site/job selection identity, prompt, configured image model, format/size/options; reuse stored artifact bytes. Persist pending/completed state before/after the request. A crash after provider completion but before result persistence is an ambiguous paid outcome: do not claim exactly-once generation or automatically regenerate it. Logo selection is separate from the optional illustration budget.

Prompt caching reuses processed input prefixes; it does not reuse final generated image bytes or guarantee identical output. It is not application idempotency. Keep stable instructions/tool definitions first for potential prefix reuse without making correctness depend on a cache hit. [Prompt caching](https://developers.openai.com/api/docs/guides/prompt-caching)

## Minimal missing interface seam (repository inference)

Current `ModelRequest` carries visible `ChatMessage[]` only. `ModelResult` has summary, token totals, and optional response ID. The worker appends results only after `run` returns. Consequently, an in-memory adapter replay loop cannot survive a provider wait or restart, and a response ID alone does not meet the private-source-of-truth requirement.

Small optional extension, rather than a new orchestration system:

```ts
// Provider state is a versioned, bounded JSON envelope, no secrets.
interface ModelContinuation {
  provider: "openai-responses"; version: 1;
  operationId: string; model: string;
  items: unknown[]; // Adapter validates replay-compatible item shapes.
  // Include pending calls, completed call outputs, usage, loop/retry counters.
}
// ModelRequest: continuation?: ModelContinuation
// ModelRequest: checkpointContinuation?:
//   (state: ModelContinuation) => Promise<void>
// ModelResult: continuation?: ModelContinuation
```

Worker stores the envelope in its existing private checkpoint `state` and passes it back into `run`; the callback collects current file bytes and durably saves state/files before the next provider call. Checkpoint returned output before tool execution, then checkpoint tool result plus resulting files together. Persist completed `call_id` results to avoid re-executing `replace` after a restart. Bind continuation to the operation/instruction/base revision and configured model so a new edit or repair cannot replay the previous operation accidentally. Preserve optional defaults for FakeModel and existing callers. Return-only continuation is insufficient for interrupted loops. Retain application outcome/error mapping instead of widening public chat messages with provider internals.

Fixture priorities: full reasoning/phase/call_id round trip; raw HTTP without output_text; refusal despite status completed; incomplete without visible output; commentary-only response; malformed/unknown tool; restart after completed replace; 429 rate limit versus quota; cancellation during backoff; cached/disabled images and ambiguous image recovery. Verify headers/prompts/results/logs/artifacts never contain the API key.
