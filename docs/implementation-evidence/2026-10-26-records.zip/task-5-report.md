# Task 5 — persistent per-site editing and candidate review

Status: DONE (local demonstration scope). Base: 3289505b72af700be9394b218e1476289b9ebd14.
Branch: codex/site-factory-pilot.
Workdir: C:/Users/sazur/.codex/visualizations/2026/10/26/01a1777f-1fed-7cf3-9158-96e8e92fe058/site-factory.
This report is ignored, as requested. No speech source changes, subagents, paid calls, accounts, remote publication or native Computer Use attempts.

## Delivered behavior

- Added contracts/editing.ts and core/editing.ts with requestEdit, acceptCandidate, rejectCandidate, getConversation, publish, review listing, recovery and screenshot-evidence resolution.
- Added the private editing.json journal through createLocalEditingStore in local-state.ts. Candidate requests, ordinary chat, acceptance intents and publication intents persist before their external queue/CAS side effects.
- Candidate stores immutable baseRevision, baseDraftId, baseManifestId, parentRevisionId, candidate Revision identity, independent job ID, archived manifest, validation and state. BaseDraftId is the accepted draft, falling back to the initial published revision when no draft exists. Refinement uses the selected candidate manifest and retains the original site/baseRevision boundary.
- Extended the existing Job and runJob path with durable edit instruction, conversation and selected base. No parallel generator. Existing files are loaded from immutable artifacts; disabled creation styles do not block edits. Existing pinned selection is inherited from the base checkpoint when present; imported/manual revisions without such metadata use an explicit existing-site fallback without loading a template.
- Candidate completion registers an immutable candidate Revision and appends one assistant summary. It changes neither Site pointer nor Site revision. Failed edits preserve both pointers. Conflicted output remains archived and reviewable.
- Acceptance checks scope and evidence, journals its intent, then CASes draftId only. Replayed completion reconciles exact pointer/revision evidence after an interrupted journal write. Rejection journals its decision and cancels the retained queue entry, including recovery if queue cancellation was interrupted.
- Publication has a separate durable intent and explicit pipe method. It advances the provider using a stable intent ID and CASes publishedId only after published evidence. A pending intent blocks edits; retry/restart resumes the same intent. Conflict retains the candidate and does not fabricate success.
- LocalQueue.current(siteId) resolves independent edit jobs. The runtime uses it for job.status, registry operation display, retries and restart resumption. Initial generation retains its historical site-ID job identity.
- Both Node and Rust allowlists accept edit.request, edit.accept, edit.reject, edit.list, chat.list and site.publish with explicit fields and version/ID/revision/instruction validation. Role and path overrides are rejected. The existing stdio dispatcher routes these through desktop-runtime; there is no second transport.
- Candidate screenshot access verifies site, selected candidate relationship, immutable Revision, manifest and successful checkpoint validation evidence before reading a scoped private PNG. Unrelated candidate IDs are rejected. A rejected parent remains readable only as the bound before-image of a valid refinement; its standalone preview remains denied.
- FakeModel edit mode demonstrably replaces only the existing main heading with the literal supplied text. It preserves other markup and unrelated/manual CSS/JS files; it is visibly described as a demo rather than natural-language model execution.
- Added SiteEditor, ChatPanel and PreviewComparison. The Russian editor replaces the registry, retains chat across reopen, shows candidate history and states, compares before/after PNGs at 375/1440 widths, and separates refinement/accept/reject from header publication. Conflict preserves the instruction for a new request against the current draft. The demo note remains visible. No generated HTML/iframe enters the main webview.
- Applied the approved cool desktop palette, 340px chat, independent image/chat scrolling, stacked comparison at the compact window size, sticky domain/status header, keyboard-labelled fields/actions and concrete statuses.
- Fixed deferred first-load failure: an unavailable registry no longer displays the successful empty state or a fake count. Existing action/catalog errors continue to survive healthy polling.
- Formatted App.tsx, desktop-runtime.ts and app.css into readable blocks before extending them.

## RED/GREEN evidence

1. Wrote packages/core/test/editing.test.ts and tests/e2e/ai-edit.spec.ts before implementation.
2. First sandbox-only `npm.cmd test -- packages/core/test/editing.test.ts` could not launch Vite/Node subprocesses (spawn EPERM). This was environment failure, not RED evidence. The narrowly scoped escalated execution was approved; no approval rejection or native-app retry occurred.
3. Behavioral RED: the real runtime created and generated the site, then edit.request failed with INVALID_INPUT / unsupported desktop method. Implemented the durable worker/core path; the complete create → edit → refine → restart → accept → publish → edit → reject test passed.
4. Browser RED: real-pipe creation succeeded, but the editor action was absent; the first registry error also incorrectly displayed “Сайтов пока нет”. Implemented the editor and loaded-state distinction. Both browser scenarios now pass.
5. The first browser GREEN attempt found an ambiguous test locator matching both a select option and the visible candidate status. Scoped that assertion to the decision panel; this was a test selector correction, not a product failure.
6. Added real-adapter coverage for manual file/body preservation, spec-user/user/foreign scopes, failed-model partial writes, revision conflict during an edit, interrupted enqueue, interrupted rejection cancellation, interrupted acceptance/publication journal completion after successful CAS, pending-publication blocking and conflicting publication CAS. These expanded cases passed against the same real local storage and worker; only the specific external failure boundary is injected.
7. Self-review RED: supplying a foreign selected candidate ID with a valid own candidate revision returned a screenshot. Also, an edit consulted catalog.prepare and failed when creation catalog selection was unavailable. The regression run had eight failing cases (the catalog setup caused the downstream cases to fail). Fixed selected-candidate binding before evidence resolution and stopped creation catalog selection for edits while preserving the base selection. All cases passed.
8. Self-review RED: rejecting a parent candidate broke the before-image of an already prepared refinement. The runtime test failed with FORBIDDEN. Added narrow authorization for that immutable parent only through its valid selected descendant; standalone rejected previews remain denied. GREEN.
9. Actual runtime close/reopen during an edit verifies its saved instruction resumes, its chat contains exactly one user and one assistant entry, and Site pointers/revision remain untouched.

## Exact covering verification (2026-10-26)

- `npm.cmd test -- packages/core/test/editing.test.ts apps/worker/test/desktop-protocol.test.ts`: 17 passed in 2 files, 0 failed (6.44s).
- `npm.cmd test`: 159 passed, 1 existing platform skip, 11 files passed, 0 failed (9.80s). Existing skip: files.test.ts “rejects a symlink file before reading or overwriting its target”, because this Windows account lacks file-symlink privilege; junction coverage still runs.
- `npm.cmd run typecheck`: exit 0.
- `npm.cmd run build`: exit 0; TypeScript worker plus Vite desktop. Final desktop bundle 245.22kB / 76.06kB gzip; CSS 9.38kB / 2.60kB gzip.
- `$env:CARGO_TARGET_DIR='C:/Users/sazur/.codex/visualizations/2026/10/26/01a1777f-1fed-7cf3-9158-96e8e92fe058/site-factory/.local-state/cargo-target'; $env:SITE_FACTORY_TEST_NODE='C:/Program Files/nodejs/node.exe'; & 'C:/Users/sazur/.cargo/bin/cargo.exe' fmt --manifest-path apps/desktop/src-tauri/Cargo.toml; & 'C:/Users/sazur/.cargo/bin/cargo.exe' test --manifest-path apps/desktop/src-tauri/Cargo.toml`: 6 Rust tests passed, 0 failed, plus empty main/doc harnesses. Includes editing schema, malformed request, compiled ACL, native worker lifecycle and transport invalidation tests. Every Cargo command used the explicit project cache.
- `npm.cmd run test:e2e`: all 6 browser scenarios passed (16.5s), including new editor/first-load scenarios plus earlier creation, named-reference and persistent-error regressions. Uses actual stdio worker, not a fake UI backend.
- After resetting screenshot capture to scroll position 0 (to avoid full-page sticky-header capture offsets), `npm.cmd run test:e2e -- tests/e2e/ai-edit.spec.ts`: 2 passed, 0 failed (6.5s). Production code was unchanged after the full covering runs.
- `git diff --check`: exit 0; normal repository LF→CRLF notices only.
- Playwright emitted existing NO_COLOR/FORCE_COLOR notices; no browser/runtime test errors remained.

## Visual inspection

Opened and reviewed the actual browser-harness PNGs:
- .local-state/editor-comparison.png — 1280px window, verified before/after heading difference, candidate selection, separate accept/publish actions and persistent chat.
- .local-state/editor-minimum.png — 1040×680 viewport, stacked comparison, chat at 340px, no horizontal document overflow. The main review area can scroll vertically while the domain/status and chat remain available.
Both are browser screenshots, not native WebView2 screenshots. No native Computer Use action or approval request was attempted. Native interactive creation/close, Windows 11+, macOS 14+, packaging and actual installation remain Task 14.

## Integration notes for Tasks 6, 7, 8, 9, 11 and 12

- Task 6: consume Job.edit through runJob; it already passes the real instruction, baseManifestId, ordinary user/assistant conversation and inherited style selection to ModelPort. Do not regenerate from a template for an edit. Provider continuation/replay state must be separate private checkpoint metadata, never ChatMessage text or public history. FakeModel behavior is intentionally literal and narrow.
- Task 7: use createEditing's Principal-bearing methods behind authenticated boundaries. The desktop principal remains explicitly local-demo-admin; the client cannot supply a role. Real remote scopes/auth remain Task 7. The store/queue here are local demonstration adapters, not distributed transactions.
- Task 8: current-operation identity is independent from site ID; use queue.current(siteId), not queue.get(siteId), except when deliberately reading the initial generation checkpoint. Lease fencing and current pipeline pause/resume remain in force. The local controller serializes editor commands; distributed admission needs the production adapter.
- Task 9 / Task 12 publication provenance: Revision records stay immutable. This implementation keeps the accepted candidate Revision as both draftId and publishedId after a successful explicit publication. Revision.kind describes how the revision was created (candidate provenance), not proof that it is or ever was published. Do not filter published history by Revision.kind.
- Each explicit publication has a durable EditingState.publications record tied to siteId, revisionId, manifestId, expectedRevision and stable provider intent ID. Only state='completed' represents successful CAS-reconciled publication. Pending and conflict records must never be counted as published history. A pending record can recover via published pointer plus expectedRevision+1 after CAS succeeded but completion persistence failed. Initial auto-publication evidence remains in the generation checkpoint and must be unified by the later publication/history adapter.
- The current UI compares draftId/publishedId because publication retains the same immutable Revision. If Task 9 introduces a separate published Revision, use manifest identity to decide whether unpublished changes exist rather than comparing those IDs.
- Task 11 / future manual sources: Site pointers still resolve Revision.id → Manifest.id. The current accepted draft is authoritative for a new edit, and parentRevisionId captures selected-candidate refinements. Imported/manual versions without a generation checkpoint remain editable without a catalog/template lookup. Preserve this seam when adding manual editing.
- Screenshot reads must remain bound to selected candidate, site, revision, manifest and validation checkpoint. The optional candidateId on preview.screenshot authorizes a historical comparison base only through its relationship to that selected candidate. Never treat an arbitrary PNG ID as authorization.
- The shared privateJson journal retains its existing 2,000,000-byte cap and fail-without-overwrite behavior. Chat and immutable request snapshots are local persisted data; production retention/storage scaling remains with production adapters. Do not prune a candidate base or validation evidence still needed by a refinement or current draft/publication.
- Active-edit cancellation is not claimed or shown: the approved visual direction allows an actual cancel control only when its command is wired. Rejection is available for completed/conflicted/failed candidates. A second active request receives the specified wait message; interrupted edits resume after restart.

No unresolved Task 5 code defect was knowingly left after self-review. Real model, hosting, distributed state and native platform acceptance are the explicit downstream scope, not local-demo claims.

Commit: 9dbbeb7 — feat: add per-site ai editing and candidate review. Staged whitespace check passed; working tree clean after commit. No checks were repeated solely after commit.

## Task 5 review fix round 1 — concrete failed-edit diagnostics

FIX_BASE: 9dbbeb7867649c9139a9c02827917c1efeee00d2.
Scope: only the Important finding in task-5-review.md. The refinement-label and launcher-warning Minor findings remain deferred. No subagents, native interaction or native approval retries.

Finding addressed verbatim:
> `packages/core/src/editing.ts:75–77`: Every failed edit becomes the same generic “Правка не завершена” message. The pipeline persists the actual failure in `state.error` (`apps/worker/src/pipeline.ts:207`), but synchronization never loads it, so validation failures and model errors remain indistinguishable in both candidate details and persistent chat. This misses the explicitly required concrete error beside the result/stage. Load the matching checkpoint’s safe diagnostic, retain the pointer-preservation message, and assert its visibility/persistence in the existing failure test.

Changes:
- Failed-candidate synchronization reads state.error only from the current matching job/checkpoint. It binds checkpoint ID, job ID, stage, site ID, baseRevision, base manifest, parent Revision and the candidate identity (including the pre-archive null revision state).
- Missing, unreadable or incorrectly bound diagnostic evidence falls back to the existing pointer-preservation message. It cannot expose a foreign operation's diagnostic or prevent rejection of the failed operation.
- Before persisting public candidate/chat text, the diagnostic is reduced to the first line, stripped of control/bidi characters, capped at 400 characters, and redacted for credential assignments, authorization/cookie headers including quoted JSON fields, bearer/basic tokens, known key/JWT/opaque-token forms, private keys, URLs and private absolute paths. Input scanning is capped at 8192 characters. The overall summary remains below 512 characters with “Черновик и публикация сохранены.” retained.
- The sanitized summary is persisted as both candidate.summary and the existing single assistant chat message. Reopening the private journal preserves the same text without duplicating history.
- No frontend changes were needed: SiteEditor.tsx:82 renders selected.summary and ChatPanel.tsx:14 renders message.text directly as React text. Their existing display paths receive the repaired DTO values; no raw HTML or provider diagnostic metadata was introduced.

Test file: packages/core/test/editing.test.ts.
- Extended the existing provider-failure/pointer-preservation/rejection test to assert the actual diagnostic in public candidate details and chat, then reopen the local store and assert identical candidate/history content.
- Added validation-failure-versus-model-failure coverage with actual pipeline validation repair exhaustion, plus private-store reopening.
- Added bounded long diagnostics, credential/private-address redaction, and checkpoint/job/site/base mismatch cases. Those mismatch cases never expose the injected foreign diagnostic and preserve both pointers.

Exact commands and observed results:
1. An attempted targeted invocation using `-t 'failure|diagnostic'` was interpreted by npm.cmd's Windows command shell as a pipe and failed before tests (`'diagnostic' is not recognized ...`). It is not RED evidence. Switched to the complete requested test file; no launcher change was made.
2. RED: `npm.cmd test -- packages/core/test/editing.test.ts` — 3 failed, 13 passed, 16 total; 7.58s. The existing failure test expected “provider unavailable” but received only the generic message; the validation test expected “Validation failed after two repairs.”; the redaction test expected its safe diagnostic prefix. All three failures were the missing behavior.
3. Initial GREEN: the same command — 17 passed, 0 failed (7.75s), including the added independent long-message bound case.
4. Added a quoted JSON Cookie-header fixture. RED: `npm.cmd test -- packages/core/test/editing.test.ts -t redact` — 1 failed, 16 filtered/skipped (739ms); the diagnostic still contained the synthetic private-cookie value. Updated header redaction to recognize quoted keys.
5. Final GREEN: `npm.cmd test -- packages/core/test/editing.test.ts` — Test Files 1 passed (1); Tests 17 passed (17); duration 7.58s; exit 0.
6. `npm.cmd run typecheck` — `tsc --noEmit -p tsconfig.json`, exit 0.
7. `git diff --check` — exit 0, only normal LF→CRLF repository notices.

Only core synchronization and its tests changed. No broader suite/build/native rerun was needed for this scoped backend correction. Existing public error rendering was inspected; no new frontend flow was added. Raw checkpoint errors remain private; only bounded, redacted text enters candidate/chat DTOs. No unrelated Minor finding was changed.

Fix-round commit: 83f12570596e8b96a208727a37a71520f855961e — fix: preserve safe diagnostics for failed site edits. Working tree clean after commit; no checks repeated solely after commit.

## Task 5 review fix round 2 — multiple-cookie header redaction

FIX_BASE: 83f12570596e8b96a208727a37a71520f855961e.
The previous concrete-diagnostic finding was confirmed ADDRESSED. This round fixes only the new Important finding in task-5-rereview-round-1.md:
> `packages/core/src/editing.ts:25` stops cookie-header redaction at the first semicolon, exposing subsequent authentication cookies in persisted candidate/chat text. Focused reproduction: `Cookie: session=first-cookie; refresh_session=second-private-cookie` becomes `[скрыто]; refresh_session=second-private-cookie`. Redact the complete header value and add a multiple-cookie regression case.

Changes:
- Split Cookie/Set-Cookie handling from authorization headers. Cookie headers now redact through the end of the header line, including all semicolon-delimited cookie values/attributes. Unrelated diagnostic and authorization handling is unchanged.
- Added a parameterized real-pipeline regression in packages/core/test/editing.test.ts for Cookie, Set-Cookie and quoted Cookie keys with three synthetic authentication cookies. It verifies every value is absent from candidate output, the safe diagnostic prefix and pointer-preservation explanation remain, reopened persistent chat matches the redacted summary, and Site pointers remain unchanged.

Exact command/output evidence:
- RED: `npm.cmd test -- packages/core/test/editing.test.ts -t cookie` — 3 failed, 17 filtered/skipped; 985ms. All three failures showed `refresh_session=second-private-cookie; auth=third-private-cookie` surviving after the first redacted cookie.
- GREEN: `npm.cmd test -- packages/core/test/editing.test.ts` — Test Files 1 passed (1); Tests 20 passed (20); duration 8.20s; exit 0. This includes the existing bounded/redacted diagnostic, foreign-operation binding, failure/restart and pointer-preservation tests.
- `npm.cmd run typecheck` — `tsc --noEmit -p tsconfig.json`, exit 0.
- `git diff --check` — exit 0, normal LF→CRLF repository notices only.

Only packages/core/src/editing.ts and packages/core/test/editing.test.ts changed. No unrelated Minor finding, native UI, approval retry, subagent or external service action was involved.

Round-2 commit: 4066f16239359673cfb2b82576427e8257875fad — fix: redact complete cookie headers in edit diagnostics. Working tree clean after commit.
