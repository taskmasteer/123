# Final fix wave — Site Factory

This is the ONE final whole-branch fix wave, not a restart of completed tasks. Read final-review.md in this directory FIRST: its complete Important/Minor findings, exact citations and regression criteria are the requirements. The final report includes M6: bounded safe registry topic/latest-error projection coordinated with I5, including stale-error replacement and scope/secret filtering.

Workdir for every command: C:/Users/sazur/.codex/visualizations/2026/10/26/01a1777f-1fed-7cf3-9158-96e8e92fe058/site-factory.
Branch: codex/site-factory-pilot. FIX_BASE: a345580c69fb07d6cb34f0145f28437386f639fe.
You are the sole production implementer. No helpers, subagents or reviewers. Controller handles the only scoped rereview after all fixes.

## Inputs and authority

Read shared-context.md (binding Global Constraints/Tooling), docs/superpowers/specs/2026-10-26-site-factory-design.md and the specific plan sections cited by final-review.md. Read Task14's final report/rereview and relevant technical rulings for touched packaging/native seams. Do not reread the 44,065-line whole-branch diff or redo completed tasks. Inspect the named modules and their consumers as necessary.
Apply TDD for changed behavior, existing React performance guidance for UI, and verification-before-completion. Existing design and user instructions authorize routine implementation choices; raise concrete architectural ambiguities to controller, not the human. Any blocking uncertainty should state a proposed minimal resolution and consequences.

## Complete scope

Address I1–I10 and M1–M6 from final-review.md in this same wave:
- Managed AI send/refine independent of local blocked sentinel, including offline shared workers.
- Safe accessible checked first draft, while preserving publication reservations and initial auto-publication.
- Contextual role-scoped cancellation, including local running execution.
- Direct-body readability.
- Actual model-invented auto-topic/brief, checkpointed before subsequent paid work; exact manual about preserved.
- Factuality/no-invented-facts/concept rules for generate and edit.
- Durable batch-aware direction selection and simple bounded similarity assessment.
- Paste/manual batch input through bounded validation/preview/commit.
- Bounded and abortable upload phases and safe shutdown.
- Idle polling and registry query fanout.
- Source provenance, staged dependency isolation, local prepare state fence, empty managed source files, and stale capability/onboarding copy.

Do not weaken current invariants to make these paths usable. Keep exactly one mutating operation per site, expected-revision CAS, current lease/generation authority, unknown publication reservation/reconciliation, immutable upload capabilities, schema9/header-aware8 backup compatibility, restore quarantine, source/executable separation and native IPC limits. An unpublished draft may be shown while work owns the site, but mutation stays blocked until safe cancellation/settlement; never bypass an unknown provider outcome. A cancelled generation must not erase published content. Managed panels may submit to an offline queue without possessing local model keys.

Preserve checkpoint/retry/failover stability of subject, seed, catalog/style versions and already created image. Model planning is real production adapter behavior, tested with recording/fake transports without paid calls; do not turn it into another fixed-topic list or pretend a prompt alone proves factuality/uniqueness. Similarity assessment must be bounded at installation scale and respect explicit references and the one-enabled-style case; avoid an installation-wide in-memory scan.

## Validation and resources

Select meaningful RED/GREEN tests covering the changed behavior and trust boundaries, then typecheck/build and appropriate focused integration/E2E checks. Keep original timeouts/guards; do not relabel environment errors as RED or skips as passes. Full 940k/whole verify/capacity repetition is not automatic: run only if the code delta creates a named uncovered capacity concern, explaining it to controller first. Existing full baseline evidence remains historical, not fresh proof of changed code. A broad unit pass may be appropriate after the complete wave; avoid repeating the same suites after unrelated edits.

All Cargo commands MUST set CARGO_TARGET_DIR to this checkout/.local-state/cargo-target; inherited cache is unrelated. Filtered SQL uses direct C:/Program Files/nodejs/node.exe scripts/test-integration.mjs, never npm.cmd with a caret filter. Maintain safe disk headroom; no deletion of caches/current artifacts/user files for space without an exact owned-path rationale. Current free sample is much higher than the historical handoff, but remeasure as needed.
Packaging changes must classify retained Windows artifact impact. Do not call old binaries evidence for changed resources; retain their exact historical hashes and rebuild only when necessary to deliver a valid changed artifact, with bounded pre-bundle checks first. Mac actual execution remains pending. No new external downloads are needed without a concrete reason.

## Restrictions and reporting

Preserve original untracked docs/SITE_FACTORY_HANDOFF_2026-10-29.md unchanged. Do not commit it or controller evidence files accidentally. Preserve docs/implementation-evidence archive and .local-state proofs. Controller refreshes archive/decisions after final rereview.
Worktree and Git common metadata are outside this chat writable roots; use narrow require_escalated writes as necessary. No new checkout, no unrelated speech/pipe changes, no native GUI/CUA/headful/chooser retry, credential discovery, real provider/model/account/email/DNS/deploy/payment/signing/installer action, push or merge.

Write final-fix-report.md here with each finding's disposition, code changes, exact covering commands/output, meaningful RED/GREEN, source/test boundaries, self-review and remaining limitations. Commit the complete coherent wave (one or more logical commits allowed; all will be reviewed from FIX_BASE). Do not dispatch a reviewer. Return status, commits, one-line test summary, concerns, report path only. Send controller occasional concrete implementation/testing milestones and architectural questions. If any finding truly cannot be completed safely, report it explicitly; do not silently drop it or claim completion.
