# Task 4 review — /root/review_task_4

Range a1a1be81ea717382ea7213839246fdcd17cc8328..8b5035155792e8ea20d4e7d0feadf67263db919e.
Spec: Issues found. Quality: Needs fixes. Critical: none.

## Important findings (verbatim)

1. **A timeout permanently desynchronizes the native pipe.** `apps/desktop/src-tauri/src/worker.rs:232–235`: timeout and mismatched-response errors leave the same process and response receiver alive. If request A completes after its 30-second deadline, request B consumes A’s response and fails; subsequent requests remain one response behind. They are still executed, including mutations, despite being reported as failures. `preview.open` performs browser launch plus navigation, so it can exceed this deadline. Invalidate/restart the transport after timeout, malformed response or ID mismatch without replaying the ambiguous request, or correlate responses by ID while discarding expired ones. Add focused delayed-response coverage.

2. **Background polling erases unrelated operation errors.** `apps/desktop/src/App.tsx:16–17`: every successful list/device poll calls `setError('')`, although preview actions and catalog loading share that error state. A failed “Открыть” operation or catalog request therefore loses its explanation within approximately 600 ms while polling remains healthy. Keep polling errors separate from action/catalog errors; clear each only following the corresponding retry, success or dismissal.

3. **Users cannot select a library reference when creating a site.** `apps/desktop/src/App.tsx:22`, `apps/desktop/src/features/sites/CreateSiteDialog.tsx:14`: the dialog receives only `catalog.styles` and submits a style ID through `referenceId`. None of the 14 displayed library references can be chosen by its name. The approved direction requires creation to use the same reference and title shown in the library. Pass the reference catalog and expose eligible references; the existing catalog API already supports their IDs.

## Minor (deferred)

- SiteList.tsx:9: failed initial fetch becomes 'Сайтов пока нет' because loading ends without successful list response. Distinguish failure from loaded empty registry.
- App.tsx:16, desktop-runtime.ts:58, app.css:1: substantial logic/styles compressed into long lines. Format into readable blocks before later tasks expand transitions.

## Evidence boundary

Real native launch, Rust/Node and compiled ACL checks are established. Actual WebView2 create/visual/window-close interaction remain unverified after app approval timeout; Win11/macOS remain Task14 requirements. Browser harness is not native acceptance.

## Strengths/method

Explicit main-only compiled ACL, trusted fixed executable paths/cleared child env, scoped site-revision-manifest screenshot proof, real shutdown persistence regression, clear separated states. Focused outside-diff checks: catalog.prepare reference support, pipeline/queue display transitions, validator screenshot ordering. Complete diff reviewed; no suite reruns or mutations.
