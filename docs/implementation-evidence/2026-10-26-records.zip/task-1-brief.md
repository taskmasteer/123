### Task 1: Реестр сайтов и перезапускаемый локальный режим

**Files:** создать `package.json`, `tsconfig.base.json`, `.gitignore`, `packages/contracts/package.json`, `packages/contracts/src/model.ts`, `packages/contracts/src/inputs.ts`, `packages/core/src/sites.ts`, `packages/core/src/permissions.ts`, `packages/adapters/src/local-state.ts`, `packages/testing/src/clock.ts`; тесты `packages/core/test/sites.test.ts`, `packages/adapters/test/local-state.test.ts`.

**Interfaces:** производит общие типы, `normalizeDomain(value: string): string`, `authorize(principal: Principal, action: Action, site?: Site): void`, `createLocalState(directory: string, clock: Clock): Promise<LocalState>`. `Action` — `site:create|site:read|site:edit|site:publish|site:export|admin:manage`. `LocalState` реализует SiteRepository и атомарное сохранение состояния одним управляющим процессом; это не распределённая БД.

- [ ] **1. Написать тесты нормализации и сохранения.** На временном каталоге создать реестр и проверить:
```ts
expect(normalizeDomain(' HTTPS://EXAMPLE.COM/ ')).toBe('example.com');
expect(() => normalizeDomain('https://example.com/page')).toThrow();
expect(() => normalizeDomain('https://user:pass@example.com')).toThrow();
expect(normalizeDomain('пример.рф')).toBe('xn--e1afmkfd.xn--p1ai');
expect(reopenedSite.domain).toBe('example.com');
expect(duplicateError.code).toBe('DUPLICATE_DOMAIN');
expect(() => authorize(user, 'site:edit', ownedSite)).toThrow();
```
Добавить отказ на IP, localhost, port, query и fragment; домен без схемы принимается. В тесте `reopenedSite` получен через новый createLocalState после закрытия первого.
- [ ] **2. Запустить** `npm test -- packages/core/test/sites.test.ts packages/adapters/test/local-state.test.ts`; до реализации ожидается ошибка отсутствующего модуля.
- [ ] **3. Реализовать интерфейсы и workspace-команды** `test`, `typecheck`, `build`. Локальное состояние сохранять через временный файл и замену под process mutex; повреждённый файл выдаёт ошибку и не перезаписывается пустым состоянием. В production local-state недоступен.
- [ ] **4. Повторить тесты и typecheck**; все проверки зелёные, повторный запуск сохраняет запись.
- [ ] **5. Commit:** `feat: add site registry and local persistence`.

