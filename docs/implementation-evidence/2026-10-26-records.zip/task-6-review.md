# Task6 review — 4066f16..a4af9de

Reviewer /root/review_task_6. Spec issues found; task quality Needs fixes.

## Important
**Recoverable provider rejection makes initial generation permanently unretryable.** `packages/adapters/src/openai/responses.ts:131` and `:140` persist `terminal: 'failed'` for quota and HTTP authentication/configuration errors. On resume, line 88 throws before any HTTP request. `apps/worker/src/desktop-runtime.ts:174` invokes `queue.retry`, which preserves that continuation (`packages/adapters/src/local-queue.ts:72`). Consequently, entering a valid replacement key or replenishing quota still leaves the existing generation stuck. Changing the configured model also encounters the identity guard at `apps/worker/src/pipeline.ts:88`.

Add an explicit recovery path for account/configuration failures that starts an appropriate new provider operation while preserving saved files and completed tool results. Keep genuine refusal, ambiguous image outcomes and exhausted transient budgets distinct; do not silently reset them. Cover “401 → replace key → retry same generation” and “quota corrected → retry” fixtures.

## Minor
Report records inherited NO_COLOR/FORCE_COLOR warnings; resolve harness conflicting environment when updating it.

## Cannot verify
Actual account/model availability, live quality, supported Win11/macOS14, macOS compilation/Keychain and interactive WebView2 remain Task14 disclosed acceptance gaps. Remote storage/hosting/authorization remain later integrations; settings labels accurately identify local/demo status.

## Strengths
Complete ordered replay/call_id/reasoning/phase and matching-file checkpoints; retry-owner prevents multiplication. Refusal/commentary cannot finish. Image pending/completed cache distinguishes ambiguous paid outcome. Key replacement abort/drain and native private command/renderer clearing. Fixtures cover restart, retries, rotation/deletion and secret echoes.

## Checks
Read complete diff with bounded recovery of truncation. Named binary-image/text workspace risk checked tools.ts:31 and pipeline:135; binary preserved separately, no finding. Named terminal credential recovery risk checked queue/call sites and focused offline reproduction: first401, then Model response failed after key replacement, one total HTTP call. Named Chromium inheritance risk checked two env allowlists; keys excluded. No reported suites rerun, no mutations/credentials/live provider/native GUI.
