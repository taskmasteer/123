# Local PostgreSQL testing research

Checked 2026-10-26 for implementation tasks 7 and 8. This is environment preparation; no SQL, authentication, installation, cluster creation, server start/stop, service changes, or cloud operations were performed. No credentials or existing database configuration/data were read.

## Observed availability

- Native PostgreSQL **18.6**: `C:/Program Files/PostgreSQL/18/bin/`; `psql.exe`, `postgres.exe`, `initdb.exe`, `pg_ctl.exe`, and `pg_isready.exe` all returned their versions successfully.
- Native PostgreSQL **14.24**: corresponding `psql.exe`, `postgres.exe`, `initdb.exe`, and `pg_ctl.exe` exist and returned their versions under `C:/Program Files/PostgreSQL/14/bin/`.
- `psql`, `postgres`, `initdb`, and `pg_ctl` are absent from this shell's PATH. Use absolute executable paths, without modifying global PATH.
- Existing Windows services `postgresql-x64-14` and `postgresql-x64-18` are **Running**. PostgreSQL processes are present. TCP listeners occupy 5432 and 5433 (IPv4 and IPv6); this research did not establish which service owns which port.
- The .NET TCP listener inventory showed no listener on 55432 or 55433 at check time. Recheck immediately before a future cluster starts.
- Docker CLI **29.8.2** and Docker Desktop are installed under `C:/Users/sazur/AppData/Local/Programs/DockerDesktop/`. The current context is `desktop-linux`; `docker version` cannot reach `dockerDesktopLinuxEngine` because its named pipe is absent. No Docker process was reported. A usable Docker engine is **not currently verified**.
- `podman` was not found on PATH; installation elsewhere was not exhaustively searched.
- `wsl.exe` exists, but `wsl --list --verbose` returned `Wsl/EnumerateDistros/Service/E_ACCESSDENIED` in this execution context. Do not infer that WSL is absent or broken; distribution availability remains unknown.

## Best route for tasks 7/8

Reuse the **PostgreSQL 18 binaries to create a separate disposable, user-owned cluster**, with its own data/log/password files in a permitted temporary test directory and a freshly checked port such as 55432. This avoids existing service credentials/data, service installation, containers, and a cloud account. Cluster startup remains untested here; filesystem ACLs or sandbox process/network restrictions can still prevent it.

Proposed future runner lifecycle (not executed; placeholder variables must be assigned to dedicated test paths):

1. Generate a fresh random test-only administrator password into a restricted temporary file without printing it. Initialize with `initdb.exe -D $testDataDir -U test_admin --auth=scram-sha-256 --pwfile=$testPasswordFile --encoding=UTF8 --no-locale`.
2. Start only this directory: `pg_ctl.exe -D $testDataDir -l $testLog -o "-h 127.0.0.1 -p 55432" -w start`. Do not register a Windows service or alter an existing cluster. Bind only loopback.
3. Apply real migrations to its disposable database via `psql.exe -X -v ON_ERROR_STOP=1`, or the application's PostgreSQL driver. Pass connection details through an isolated test configuration; do not print generated passwords/connection strings. Use one fresh database per run or worker to avoid fixture interference.
4. In `finally`, close all test connections and stop **only** `$testDataDir` with `pg_ctl.exe -D $testDataDir -m fast -w stop`. Remove generated files only after resolving and checking that their absolute paths remain inside the dedicated test directory.

The PostgreSQL tools support creating a separate cluster and starting/stopping the server selected by `-D`; `pg_ctl -l` redirects its background server output. See [initdb](https://www.postgresql.org/docs/18/app-initdb.html) and [pg_ctl](https://www.postgresql.org/docs/18/app-pg-ctl.html).

## Required genuine tests

- Execute migrations, constraints, grants, policies, and SQL functions against this real server. A mocked adapter or in-memory store is not evidence for SQL/RLS behavior.
- Run RLS reads and writes as non-owner `NOSUPERUSER NOBYPASSRLS` roles, including direct unauthorized queries, own/assigned/foreign sites, missing grants, and denied INSERT/UPDATE checks. Superusers and BYPASSRLS roles bypass RLS; table owners normally bypass it too unless FORCE ROW LEVEL SECURITY applies. See [PostgreSQL row security](https://www.postgresql.org/docs/18/ddl-rowsecurity.html).
- Supabase-specific `auth.uid()`/JWT settings and roles need a clearly named local bootstrap fixture if absent from vanilla PostgreSQL. Assertions using such fixtures prove the real PostgreSQL policies under the supplied claims; they do not prove GoTrue/JWKS verification, JWT issuance, PostgREST role switching, or a deployed Supabase project's configuration.
- For queue races use at least two independent live connections and overlapping transactions with deterministic barriers. Prove disjoint claims, max two active jobs per device under concurrent claims, atomic generation increments, stale heartbeat/checkpoint/finish rejection, and SQL EXECUTE restrictions. `FOR UPDATE SKIP LOCKED` skips rows held by other transactions and is documented for multiple queue consumers; see [SELECT locking](https://www.postgresql.org/docs/18/sql-select.html).
- Cover lease duration 120 seconds, heartbeat schedule 30 seconds, expired-lease reclaim, checkpoint recovery, and stale site revision conflicts. Advance controlled application clocks or expire fixture rows within tests; avoid wall-clock sleeps. Any SQL time override must stay inside a test fixture/guarded seam rather than becoming a client-authorized production timestamp.
- Plain SQL assertions/driver tests are enough; pgTAP is optional and its Windows availability was not checked. No extension installation is needed merely to test RLS or row locks.

## Limits and alternatives

- Native PostgreSQL 18 is strong local SQL/RLS/lease evidence but not proof of Supabase managed Auth, API, storage, R2 uploads, signed URLs, or cloud failover. Test those contracts separately and label unavailable provider checks as skipped. Match the eventual hosted PostgreSQL major version before claiming version parity; the plan does not pin one yet.
- For full local Supabase integration later, first make the installed Docker engine usable, then install a **pinned project-local Supabase CLI** and use `supabase init` / `supabase start` without login/linking. This downloads images and starts local services, so it was deliberately not done in this research. Supabase documents that its full stack uses containers on Windows; its experimental native runtime currently targets Linux and Apple-silicon macOS. See [Supabase local CLI](https://supabase.com/docs/guides/local-development/cli/getting-started).
- No package installation is needed for the recommended native route. If a different PostgreSQL major version is required, use the official [Windows download page](https://www.postgresql.org/download/windows/), which links the EDB installer and ZIP binaries. Prefer ZIP binaries plus a disposable cluster when an additional system service is unnecessary.
- Docker Desktop has licensing conditions for larger enterprises, so do not promise that all Docker-based use is free; native PostgreSQL avoids that dependency. See [Docker Windows installation requirements](https://docs.docker.com/desktop/setup/install/windows-install/). A paid cloud account is unnecessary for either native PostgreSQL tests or local Supabase itself.

## Evidence boundary

Availability is verified by command discovery, binary version output, service/process inventory, Docker's read-only version/context commands, WSL's read-only inventory attempt, and the .NET local TCP listener inventory. Genuine migration, RLS, and queue test results remain **not run** until a later implementation task creates and uses the disposable cluster.
