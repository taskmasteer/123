# One final scoped rereview — prepared request

Use C:/Users/sazur/.codex/skills/subagent-driven-development/re-review-prompt.md. This is the ONLY scoped rereview of the final fix wave; do not perform another whole-branch review.
The controller will supply committed fix HEAD and the exact a345580..fixHEAD package after the sole implementer has completed its report. Do not start from this draft alone.

Read final-review.md for ALL original findings I1–I10 and M1–M6 verbatim, final-fix-brief.md for authorized requirements/rulings, and the complete final-fix-report.md for source/test/artifact boundaries and covering output. Binding Global Constraints/Tooling are in shared-context.md and approved spec. Read the supplied full fix diff once in bounded chunks; preserve coverage cursor across compaction. Do not regenerate the full branch diff or replay completed task reviews.

Verdict every original finding ADDRESSED/NOT ADDRESSED with precise code evidence. Check only new breakage introduced by this wave; unchanged-code observations go under Out-of-Scope and do not extend the wave. Both spec and quality verdicts are required. Controller rulings are context to evaluate, not correctness waivers. The broad review and post-report M6 clarification comprise one completed broad gate.

Named cross-module seams needing care:
- Managed UI uses server/session edit capability and can queue offline without local model keys; preserve local blocked/demo/live behavior and role authority.
- Initial checked draft initialization, exact replay, immutable revision identity/metadata, fresh lease/generation/site-version authority, different prior draft rejection, safe cancellation and unknown publication reservation.
- Local/managed cancellation and worker abort, stale completion fencing, existing published content, per-phase upload timeout/unknown completion/stop convergence.
- Automatic subject selected by real model adapter, checkpointed before downstream paid work; manual input and legacy checkpoint/continuation/prompt binding remain stable.
- Batch direction pinned before dispatch, concurrent workers/retry, explicit reference/disabled/one-style fallback and bounded real similarity signal.
- Registry safe bounded topic/error projection, retry clearing and query fanout; idle/hidden versus active polling, fresh action authorization/revocation.
- Direct-body readability without false rejection of readable descendants; actual provider factuality instructions with honest semantic limits.
- Paste/manual staged import, duplicate/invalid/correction/selective commit and local overlap state fence.
- Empty/EOF resource integrity and rendering; truthful capability-aware copy.
- Actual source clean/dirty/untracked fingerprint, required staged dependency containment and independent compiled byte anchor; exact artifact source boundary and no old binary relabeled as changed proof.

Treat implementation reports as claims: verify named coverage and shown output against the diff, not by replaying tests. Focused execution only for a concrete named doubt no existing run answers. No repeated unit/SQL/E2E/package/build/full940k fixtures. No GUI/CUA/headful/chooser, credentials/live model/provider/account/email/DNS/deploy/sign/installer execution, push or merge. Every shell workdir is the named Site Factory linked checkout; Cargo target always private checkout/.local-state/cargo-target. No helpers/subagents.

Read-only source/index/HEAD/branch. Write only final-rereview.md here (narrow escalation outside current writable roots as necessary). Return concise verdict/counts/report path; no implementation changes. External Win11/Mac14/signing/live/two-device/visual/full-body acceptance remains separate. Root will read all findings and explicitly adjudicate residuals after this single scoped pass; there is no second wave.


## Committed final range and latest evidence

Fix base a345580c69fb07d6cb34f0145f28437386f639fe, HEAD f89d4604bd31e4052c4ea18a92dd1c53b4badbac (both745cbfb andf89d460). Complete supplied diff review-a345580..f89d460.diff. Latest per-finding table and completed I10/f89d460 delivery supersede chronological checkpoints in report. Read controller verification note: absent zero-output typecheck log replaced transparently by a fresh exact tsc --noEmit exit0 controller log. Current artifact receipt .local-state/final-fix-idle-artifacts.json; first745proof .local-state/final-fix-artifacts.json plus before-receipts remain historical. Root reverified46proofhashes+381sourcefiles unchanged; current main/installer/manifest anchored to f89d460, dirtyonlyoriginal userhandoff. I10 now trulyidle0queries acrossfivepanels, with optional read-only batch-wide activity and exact existing autonomous-admission predicate; no new selection semantics. Root-approved first-draft initialization and other rulings are recorded in progress.md; evaluate their correctness independently.
