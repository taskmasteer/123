### Spec Compliance

- ❌ Issues found. The requested files and the approved external-selection, deterministic-producer, scoped-projection, asynchronous Save, filtered-claim and private-map architecture are present. However, the monotone denial requirement still has two CAS/journal interleaving defects, and exact source preservation and an advertised image style operation are incomplete. Important findings below identify the affected lines.
- ⚠️ Cannot verify actual Windows 11/WebView2, macOS 14/WKWebView, headful external Chromium interaction, packaged browser availability, physical devices, or live provider/managed-account acceptance. The driver defaults to headful (`apps/worker/src/preview/selection.ts:45`), but the supplied driver test explicitly uses headless (`tests/e2e/preview-isolation.spec.ts:34`). These remain Task14 acceptance items, consistently disclosed at `task-11-report.md:62`; this is not a request to weaken the approved fallback or ACL.
- ⚠️ Cannot verify Task12 retention of accepted visual maps/checkpoints/screenshots from this task. The private map is introduced at `apps/worker/src/pipeline.ts:374`; the controller must carry the recorded retention dependency into Task12.
- No controller-plan conflict was found. A–E, migration007 and the external Chromium fallback follow the recorded rulings. The terminal-denial implementation needs correction to satisfy the later ruling rather than a change to that ruling.

### Strengths

- `apps/worker/src/pipeline.ts:366` applies a typed deterministic producer to immutable source and avoids the model call; the validation branch refuses AI repair for this producer. `packages/core/src/editing.ts:155` retains the existing CAS receipt reconciliation rather than introducing a second acceptance engine.
- `packages/core/src/visual/html-patch.ts:14` checks every original source hash before applying source spans; `packages/core/test/visual.test.ts:10` asserts exact unchanged CRLF/non-BMP surrounding content and literal-script escaping. Source preservation has meaningful tests, although the cases below are missing.
- `packages/core/src/visual/projection.ts:26` reconstructs an allowlisted selection document; `apps/worker/src/preview/selection.ts:45` creates an isolated context and blocks requests, sockets, popups and navigation. Generated code and selection do not acquire a Save dispatch capability. The main Tauri CSP/ACL is not relaxed by this package.
- `packages/contracts/src/http.ts:10` constructs the safe candidate DTO without producer/actor/hash data; `apps/control/src/routes/visual.ts:21` checks scoped rights and current revision before private projection reads. The SQL claim filter is applied before candidate locking at `supabase/migrations/007_visual_claims.sql:16`, with the one-argument wrapper retained at line50.
- The integration cases at `tests/integration/visual.test.ts:26` exercise real PostgreSQL/R2-adapter seams for ordinary unenrolled spec-user projection, replay, original-saver authority and observed-before-reconciliation denial. Their admin final poll does not cover the first finding's own-saver interleaving.

### Issues

#### Critical (Must Fix)

- None found.

#### Important (Should Fix)

1. **A late observed revocation cannot persist denial through the revoked saver's own admission.** `packages/core/src/editing.ts:239` catches final-installation `FORBIDDEN` and attempts `updateCandidate` to record a failed Save. That write uses `packages/adapters/src/supabase-repository.ts:189`, whose `guard(tx, admission)` refreshes and requires the same polling actor's current edit rights. If the original saver passes the route's early denial check and acquires admission, then loses role or assignment before final CAS, final CAS rejects, and the attempted terminal journal write rejects again. The early hook at `apps/control/src/routes/visual.ts:19` has already passed and is not called on this error path. The server has observed and returned denial, but the durable Save and acceptance remain pending; restoring rights permits automatic installation without a new Save.

   Focused reproduction used the exact `createEditing` implementation with cloned durable state and an `EditingStore.transaction` enforcing the repository's fresh-admission guard. Start with a ready candidate, pending visual Save, no acceptance, site revision0 and published base. Own-saver `visualStatus` writes pending acceptance. The final-CAS port flips saver authorization to revoked and throws `AppError('FORBIDDEN')`; the next guarded store write also throws. Observed output was `FORBIDDEN`, durable Save `pending`, acceptance `pending`, revision0. Restore rights and poll the same Save: output becomes `completed`, draft is installed, revision1. This was an in-memory contract reproduction, not a real SQL concurrency run.

   Persist final authorization denial using the narrow site-locked denial authority independently of the revoked user's ordinary admission, including errors observed after the early hook. Preserve the existing terminal fence. Add a regression that revokes between admission/evidence and final CAS during the saver's own status call, restores rights, and proves replay/recovery cannot install.

2. **The denial hook marks an already committed Save as failed during the CAS-to-journal window.** `packages/adapters/src/supabase-repository.ts:147` checks only whether the Save journal says pending, then line151 changes it to failed/conflict when rights are absent. It does not classify the existing site's installation receipt. Final CAS and `updateCandidate` are separate transactions (`packages/core/src/editing.ts:172` and line185), so a valid CAS can install the draft first, followed by revocation and an own-saver status call before the completion journal write. The hook terminally fails that already installed Save. The monotone journal guard then prevents `settleAcceptance`'s existing installed-pointer reconciliation at `packages/core/src/editing.ts:155` from marking it completed.

   Focused execution of the exact `denyRevokedVisualSave` method supplied a site with `draftId=saveId`, revision1, base revision0, and pending acceptance/Save, representing an authorized CAS committed before revocation. With the fresh saver downgraded, it returned true and durably produced Save `failed`, acceptance `conflict`, while the installed draft remained `saveId`. The check used an in-memory transaction adapter; the interleaving follows from the separate SQL transactions in the diff. This is an incorrect failure receipt for an authorized completed installation, not proof of an unauthorized CAS.

   Under the site lock, recognize and reconcile an already committed installation before applying terminal denial to outstanding work. Keep legitimately installed pointers intact and report that Save completed. Add a CAS-success/journal-pending → revoke/status regression, alongside the existing revoke-before-CAS cases.

3. **Unrelated original bytes are rewritten on otherwise valid patches.** `packages/core/src/visual/editable-map.ts:27` decodes HTML with the default UTF-8 decoder, which strips a BOM; `packages/core/src/visual/html-patch.ts:95` re-encodes that entire decoded document. A text-only Save consequently removes an unrelated leading UTF-8 BOM. Separately, `packages/core/src/visual/html-patch.ts:31` replaces the complete style attribute using decoded text and canonical escaping, while `packages/core/src/visual/css-patch.ts:62` trims trailing original whitespace. Thus untouched inline declarations are not preserved byte-for-byte as required by ruling A and the review's binding source-preservation constraint.

   Focused exact-module checks confirmed: BOM-prefixed HTML changing only `<h1>Old</h1>` to `New` loses its initial `EF BB BF`; and changing only color in `STYLE='--custom: "a&b"; display: grid;   '` yields `style="--custom: &quot;a&amp;b&quot;; display: grid; color: red !important;"`. The custom property bytes, quoting/case and untouched trailing spacing are rewritten despite being unrelated to the color patch. Preserve original byte/lexical spans outside the actual edited value/declarations, including BOM and entity spelling. Add exact-byte regressions for text Save with BOM and style Save with unrelated declarations/entities/whitespace.

4. **Style editing is advertised for a valid self-closing img but always fails.** `packages/core/src/visual/editable-map.ts:49` advertises styles for sourced img elements, including ordinary HTML `<img src="old.png" />`. When style is absent, `packages/core/src/visual/html-patch.ts:33` inserts immediately before `>` and therefore after the existing slash, producing `<img src="old.png" / style="margin: 1px !important;">`. Reparsing rejects that source and the operation fails with “Правка изменила структуру.” This makes an offered supported simple edit fail on valid common image markup.

   Focused exact-module execution confirmed the input element exposes `["styles","imageAssetId"]` but `{styles:{margin:'1px'}}` throws that error. Insert the new attribute before the self-closing solidus while preserving the original slash/spacing, and cover both `<img/>` and `<img />` with the ordinary source-preservation assertions.

#### Minor (Nice to Have)

- `task-11-report.md:46` and `task-11-report.md:64` disclose retained bundle-size and color-environment warnings. Keep these on the existing final launcher/packaging cleanup ledger; the reported passing exit codes do not make their output pristine. They do not justify unrelated Task11 bundling work.

### Review Coverage and Focused Checks

- Read the full 3,602-line/253,267-byte review package, covering all 52 stat/diff sections, in bounded pieces. Only a tool-truncated managed/visual DTO fragment was recovered; no second full diff/source review was performed. All eight files named by the brief have corresponding hunks.
- Inspected unchanged `packages/core/src/permissions.ts` for the named assignment-loss doubt: owner/assignedUserIds determine scope. Inspected only the omitted `apps/control/src/app.ts:119`–151 dispatch context to establish that no generic site-visibility rejection precedes the visual denial hook. Therefore an already revoked assignment observed at the initial own-status boundary is covered by the new hook; finding1 concerns revocation after that check.
- Inspected only omitted `apps/worker/src/desktop-runtime.ts:224`–255 request-entry context for the named managed-mode selection doubt. The blocked-model guard names creation/AI/import operations, not visual selection; no enrollment/model gate was found on this path.
- Ran three small read-only Node reproductions against exact TypeScript modules using in-memory transpilation: source byte/image insertion cases; core recovery with the dynamic repository-style store guard; and the repository denial method with an already installed site receipt. They created no production/test files and exercised no credentials, providers, GUI or database service. The authorization transaction adapters are explicitly emulated; real SQL interleaving regressions are recommended for the fixes.
- Did not rerun reported unit/integration/E2E/Rust suites or benchmarks. The report's normal-gate evidence remains reported evidence, not independently rerun acceptance.

### Assessment

**Task quality:** Needs fixes.

**Reasoning:** The change uses the intended existing validation, queue and acceptance seams and provides useful real adapter coverage. Two authority/journal races contradict the monotone Save outcome requirement, while the exact-byte and self-closing-image regressions violate supported source-preserving editing behavior.
