**I1 — A delayed identical acknowledgement can move the durable cursor backwards. — ADDRESSED.**

- `packages/adapters/src/postgres-recovery-transfer.ts:377`–`:391`: final acknowledgement obtains current authorized/locked transfer state, then locks and rereads the exact receipt. It verifies digest and kind, returns current progress without writes for a completed receipt, and otherwise requires staging phase and the exact receipt input cursor before changing the metadata or resource cursor and marking the receipt complete in the same transaction. The removed early completed-receipt return no longer returns progress from an earlier transaction. These changes prevent delayed A from overwriting acknowledged B.
- `packages/adapters/src/postgres-recovery-transfer.ts:372`: completed resource receipts skip redundant object completion. The new final receipt check still executes after this outside-transaction read, so that read cannot authorize a stale cursor update.
- `tests/integration/recovery-transfer.test.ts:849`–`:918`: four deterministic real-SQL cases cover metadata and resource late ACKs, each with and without intervening admin demotion. They hold the original call after its incomplete receipt read without holding a SQL lock, acknowledge identical A and newer B, and then release A. Assertions cover current returned progress or fresh FORBIDDEN, durable metadata sequence 2, resource sequence/offset (2,0), metadata totals/row counts, object PUT counts, exhausted staging bytes/parts, and subsequent batch continuation. This directly addresses the reported final-ACK race rather than merely repeating the earlier receipt-insertion test.

**I2 — Legacy staging can reach READY without freezing Auth mappings. — ADDRESSED.**

- `packages/adapters/src/postgres-recovery-transfer.ts:59`–`:69`, `:481`: first preparation freezes the verified server snapshot mapping digest while acquiring the existing snapshot/transfer locks, before the phase/claim transaction completes. This applies to the legacy-staged restore as well as stageBatch. A missing digest can be established only in staging; later phases must match an existing digest and fail closed otherwise.
- `packages/adapters/src/postgres-backup.ts:165`: either the frozen digest or any non-staging phase prevents addMappings from changing an existing destination or adding another source identity. Exact destination replay returns without replacing stored verified identity/email data.
- `packages/adapters/src/postgres-recovery-transfer.ts:523`, `:539`: preparation persistence and commit admission verify the digest; the first preparation check also runs before a READY/committed return. Thus mapping drift cannot silently produce or reuse a prepared result.
- `packages/adapters/src/postgres-restore-preparation.ts:585`, `:591`–`:593`: expected digest is computed before activation; the final locked SQL read compares both the frozen digest and live verified JSONB with that prevalidated mapping. This closes drift after commit admission without adding crypto or external I/O inside exclusive activation.
- `tests/integration/recovery-transfer.test.ts:919`–`:1042`: the real-HTTP case stages 300 records solely through retained record-part/record-complete routes, rejects changed mappings while first preparation and a later cohort are held, permits exact replay, checks concurrent preparation claims, reaches READY, rejects map drift at READY/commit and after commit admission, and observes zero installed audit rows on rejected commits. Restoring the frozen map permits installation with all 298 audit actors and installation provenance using the original destination. The isolated READY catalog fixture at `:834` now explicitly supplies its frozen empty-map digest.

### New Breakage in the Fix Diff

- Critical: none.
- Important: none.
- Minor: none.
- Check: all four files and all hunks in supplied `review-82d0952..4488831.diff` were inspected for behavior introduced by this fix. Added receipt locking follows current state acquisition; the mapping checks retain server-derived identity data and do not broaden authority, change transport limits, or add work proportional to the installation inside final commit.

### Validation Checks

- Check: read task brief, shared Global Constraints, controller rulings, exact I1/I2 findings, the entire appended fix-round-1 report (`task-15-report.md:111`–`:145`), and relevant earlier evidence boundaries (`:80`–`:110`). Reviewed supplied FIX_BASE `82d095299d45de374e0f0068b759cc5141b36ca9` to HEAD `448883179e20ec4e282941097e470b443510cff5` package; no Git requery or whole-Task15 review.
- Check: the report records actual behavioral RED output at `task-15-report.md:117`: 3 assertion failures/23 filtered in 4.18s, identifying metadata 2→1, resource (2,0)→(1,24000), and legacy mapping acceptance 200 instead of 409. The new test barriers/assertions in the diff reproduce precisely those admission orderings.
- Check: `task-15-report.md:135` records initial 3 PASS/23 filtered and expanded 5 PASS/23 filtered. The expanded count matches four I1 parameter cases plus one I2 HTTP case in the diff.
- Check: `task-15-report.md:136` names the final covering command, `node scripts/test-integration.mjs recovery-transfer backup native-managed-backup recovery-visual -t '^(?!.*actual900009)'`, and records 36 PASS/1 full filtered across four files in 36.16s. Its five-case increase over the earlier 31-pass covering run (`:95`) matches this fix's added cases. The amended SQL/native/backup/visual boundaries are covered by the recorded run.
- Check: `task-15-report.md:137` records final typecheck exit 0 and build exit 0. These are recorded implementer results checked for scope and coverage, not independent executions by this rereviewer. The report explicitly keeps the older full-volume result tied to its original source fingerprint and does not claim a new full-volume pass for this fix.
- Check: no tests or suites rerun. Inspection raised no specific unanswered code doubt requiring a focused execution; the reported focused real-SQL/HTTP cases address both open defects and the added guards. No production, Git, helper, GUI, provider, network, account, or credential actions performed; only this requested report was written.

### Out-of-Scope Observations

- None newly observed. Controller-owned unchanged M1 delayed-remap detector and M2 bundle advisory remain outside this fix round and were not re-adjudicated. Native/provider/platform/full-body acceptance retains the existing Task14 boundary.

### Verdict

**Fix round: All findings addressed, no new Critical/Important breakage.** I1 ADDRESSED; I2 ADDRESSED. Open scoped findings: 0. New breakage: 0 Critical, 0 Important, 0 Minor. This is a scoped fix-round verdict, not a fresh whole-task review or Task13 authorization.
