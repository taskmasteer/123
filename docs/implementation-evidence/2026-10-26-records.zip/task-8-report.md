# Task 8 implementation report

Status: DONE_WITH_CONCERNS (downstream Task9 publication integration and supported-platform/live acceptance remain explicitly separate).
Base: e77c4ad369d387009170e05bd25de6e68c2adf7c. Worktree: codex/site-factory-pilot in the assigned visualization checkout. No primary checkout or speech changes; no child agents.

## Implementation

- Added 003_queue_leases.sql. Claim is one SECURITY DEFINER/empty-search_path transaction, EXECUTE revoked from public/anon/authenticated. Site/job SKIP LOCKED, device capacity serialized under worker lock, generation increment, exactly 120000 ms duration. Authority uses database clock_timestamp after site → worker → job → site_operations locks, exact stored owner/generation/state/expiry/admission and revocation. Submitted expiresAt is not authority.
- PostgresQueue implements claim/renew/checkpoint/finish, transactional enqueue/admission composition, fenced site CAS, pause/resume/cancel/revoke and provider-recovery preservation. Max two active jobs/device; runner heartbeat every 30000 ms. Same-stage checkpoints are valid. Checkpoint metadata completion stays unreferenced until expected-predecessor CAS atomically updates pointer/stage/Job JSON. Exact replay is idempotent; delayed predecessors and old owners fail. No checkpoint pruning.
- Pause is checked and released atomically at a completed stage boundary; same-stage model/image continuations continue through the current stage. Resume requeues paused work and preserves the checkpoint. Shutdown cooperatively aborts and releases paused work; lease loss never commits terminal state. Cancel increments generation and retains published content. Revocation is rechecked under the shared worker lock.
- Real managed HTTP ports cover claims, scoped private snapshots/files, revision/site/catalog reads, R2 preparation/upload/completion and bound publication handoff. Per-claim dependencies avoid mutable shared lease state. No model/storage/browser/network call is held inside SQL transactions. Production entry wires PostgresQueue as R2 LeaseAuthority; no production fake adapter was introduced.
- Durable publication_reservations bind request key, immutable binding, originating job or controller, and server-only resolution. Handoff atomically transfers site admission; unresolved exclusion survives cancel/revoke/expiry/terminal transitions. Settlement is SQL-only, server-trusted and verifies the installed pointer/revision/manifest in the same transaction. Worker HTTP can request bound handoff, never settle it. Exact handoff HTTP replay works after ownership transfer while the lease remains live. Premature completed finish is rejected.
- Native enrollment/start/stop/revoke works through a dedicated main-local command and the existing fixed sidecar pipe. Sidecar generates UUID + 32 random bytes; Rust persists the whole pending descriptor/credential atomically as one OS secret value before HTTP. Canonical base64url credential is server-hashed, never returned by enrollment. Fresh admin + UUID/hash/name/origin/admin binding makes retries exact; changed binding conflicts and revoked UUID never revives. Lost response/ambiguous OS write reuses saved identity; explicit revoke/new enrollment rotates. No administrator bearer persistence or renderer-returned machine token.
- Managed Workers UI shows heartbeat, saved stage and safe status, exposes enrollment/launch/stop/pause/resume/revoke/cancel, and polls native status. Native model settings remain explicit. Generation capability is true only with queue+store; publish/export remain false. UI explicitly says publication is unavailable. Remote failure never falls back to local.
- Optional uncertainRequests preserves unknown prior-attempt token/billing usage separately from known input/output totals. Absent means zero; validation requires bounded nonnegative safe integer (0..1000). Before ambiguous redispatch the continuation durably clears pending, increments retry/uncertainty and checkpoints. A second crash after that checkpoint cannot double count the same pending attempt. Known totals are unchanged; no billing estimate/pricing change.
- Task10 seam: nullable indexed jobs.batch_id references existing private.batches; enqueueInTransaction composes with a caller transaction and never starts nested admission. Task10 owns batch expansion and pause/cancel policy.

## Focused RED/GREEN evidence

All npm commands below used the assigned checkout. Child-process/PG tests required narrow sandbox escalation; initial sandbox EPERM/pg_ctl failures were environmental, not claimed as behavioral RED.

| Command | RED | GREEN / concrete proof |
| --- | --- | --- |
| npm run test:integration -- queue failover | Missing private.claim_job; then behavioral empty claims rather than two | Installed real SQL; claims unique, per-device cap two, exact120000 duration, generation/reclaim and checkpoint guards |
| npm run test:integration -- queue -t 'admin enrollment' | Enrollment response400 rather than200 | Same UUID/token replays one worker; changed token conflicts; forged worker ID rejected; revoked enrollment/claim fails |
| npm run test:integration -- failover -t 'only committed' | Scoped snapshot route NOT_FOUND before adapter | Reclaimed worker reads committed older-generation bytes/state; unreferenced older snapshot denied; old heartbeat/upload completion/checkpoint/finish/CAS all STALE_LEASE |
| npm test -- apps/worker/test/pipeline.test.ts -t 'managed runner' | queued rather than paused | Managed scheduling and cooperative shutdown pass |
| npm test -- apps/worker/test/remote-worker.test.ts | Missing remote queue adapter | Fixed HTTPS origin/path, redirects disabled, identity/claim DTO validation pass |
| npm test -- apps/worker/test/managed-runtime.test.ts | Private runtime unavailable | Private random identity and enrollment transport, no token returned, live-model prerequisite pass |
| cargo test ... managed::tests -- --nocapture | Pending native enrollment implementation | Response loss and ambiguous OS-store write retain same pending credential before any enrollment HTTP; safe summary and schema tests pass |
| npm run test:integration -- failover -t 'managed HTTP' | Settlement unavailable rather than conflict | Actual runJob→remote HTTP→Postgres→fixture object storage archives and enters waiting_provider; exact private checkpoint binds reservation; server fixture pointer/revision+settlement transaction completes |
| npm run test:integration -- queue -t 'explicit resume' | No reclaimed paused job; later atomic boundary stub false | Same paused job requeues without losing identity; boundary check/release serialized |
| npm run test:integration -- failover -t 'controller' | Missing controller handoff | Controller admission transfers atomically; exact replay idempotent; changed binding/new admission conflicts; finally-release cannot delete publication ownership |
| npm test -- packages/adapters/test/openai.test.ts -t 'ambiguous' | uncertainRequests undefined rather than1 | Crash with pending request, then crash after durable retry accounting before HTTP, then resume: exactly1 uncertain attempt, known12/6 tokens, no duplicate accounting |
| npm run test:integration -- failover -t 'cancellation/revocation' | Premature completed finish resolved; after guard fix HTTP replay409 rather than200 | Both regressions green: no early completion and exact handoff replay200; cancellation/revocation preserve reservation and published pointer |

Additional covering checks (not represented as test-first behavioral RED): explicit authenticated provider-recovery route test preserves exact checkpoint, continuation retries, known10/5 and uncertainty1; native real fixed-sidecar pipe test proves generic dispatch cannot mint credentials; new native ACL mock test denies generated/remote views before DTO handler, main-local reaches DTO validation without OS access. Some integration assertions were added after their implementation; this report does not claim every line was strictly test-first.

## Concurrency barriers and failure assertions

- queue.test holds an independent connection's site row lock, concurrently issues four claims for one device, and observes exactly two distinct jobs, neither on the locked site. Another device still claims independent work. Stored expires_at minus claimed_at equals120000 for each claim. Nonowner authenticated role gets42501 on direct claim EXECUTE.
- failover.test holds site lock on connection A, starts require_lease on connection B, and polls pg_blocking_pids until B is demonstrably blocked. A changes expiry to clock_timestamp and commits. B then returns STALE_LEASE, proving time was checked after the wait rather than at transaction start. No sleep establishes ordering.
- The same fixture reclaims the job, prepares a checkpoint, locks the worker on A, starts queue checkpoint commit on another connection, observes its lock wait, revokes and commits on A. The blocked commit returns STALE_LEASE and cannot change job.checkpointId.
- Upload bytes before metadata completion produce an orphan; metadata completion before queue CAS produces unreferenced immutable data. Neither advances saved progress. New ownership resumes exactly the committed snapshot/file bytes/usage. Old-owner writes fail even when site.revision has not changed. A newer checkpoint prevents late predecessor commit.
- Pause/resume uses the same device row lock as authority; its boundary release and pause flag observation are one transaction. Cancel preserves checkpoints, published pointer and unresolved publication exclusion. Controller release is keyed to kind+ID and cannot release a transferred reservation.
- The 30000ms heartbeat test controls a pending model call: no timer renewal before29999ms, renewal at30000ms; pause requested during that call retains the stage's result/transcript before releasing at validate.

## Final verification

2026-10-27, all commands in the assigned checkout:

- `npm run typecheck`: exit0.
- `npm run build`: exit0; TypeScript plus Vite77modules, desktop JS494.28kB (gzip141.19kB).
- `npm test`: exit0;21 files,225 passed,1 existing skipped,12.02s.
- First `npm run test:integration`:1 failed/22 passed/2 skipped because existing auth test expected the removed server-returned worker token. Updated only that fixture to submit a client-generated credential and assert no response token.
- Final `npm run test:integration`: exit0;6 files,23 passed,2 existing live-provider skipped,8.76s. Includes all queue/failover/auth/editing/upload/invitation tests.
- `npm run test:e2e`: exit0;13 passed,26.3s. Includes managed generation capability, heartbeat/stage/pause/cancel, local-mode creation/editing, pagination and model settings. These are browser fixture tests, not native GUI or cloud acceptance.
- `$env:CARGO_TARGET_DIR='C:/Users/sazur/.codex/visualizations/2026/10/26/01a1777f-1fed-7cf3-9158-96e8e92fe058/site-factory/.local-state/cargo-target'; $env:SITE_FACTORY_TEST_NODE='C:/Program Files/nodejs/node.exe'; cargo test --manifest-path apps/desktop/src-tauri/Cargo.toml -- --skip acl_grants_only_main_local_webview`: exit0;13 passed,1 ignored synthetic OS credential roundtrip,1 filtered old GUI ACL test. Includes actual trusted Node subprocess and new managed private-pipe test.
- After adding the isolated no-OS/no-GUI ACL assertion: same two explicit environment variables, `cargo test --manifest-path apps/desktop/src-tauri/Cargo.toml native_enrollment_acl -- --nocapture`: exit0;1 passed. Mock icon resource warning is not a native GUI launch.
- `git diff --check`: exit0 after removing new trailing blank lines. Existing LF→CRLF warnings remain; incidental Cargo.lock ordering was restored. Formatting-only changes after full npm gates were typechecked; no runtime behavior changed.

No full suite was repeatedly run without a failure/change justification. No live provider, email, model, Supabase, R2, deployment, existing database or native GUI was used. No approval rejection occurred in this final phase. The earlier GUI approval timeout was respected and not retried.

## Changed files

New: packages/adapters/src/postgres-queue.ts; supabase/migrations/003_queue_leases.sql; apps/control/src/routes/{jobs,job-controls}.ts; apps/worker/src/{runner,remote-worker,managed-runtime}.ts; apps/worker/test/{remote-worker,managed-runtime}.test.ts; apps/desktop/src-tauri/src/managed.rs; apps/desktop/src/features/workers/WorkerList.tsx; tests/integration/{queue,failover}.test.ts.

Modified: apps/control/{README.md,api/index.ts,src/app.ts,src/routes/workers.ts}; apps/desktop/src-tauri/{permissions/commands.toml,src/commands.rs,src/lib.rs,src/worker.rs}; apps/desktop/src/{App.tsx,app.css,features/settings/ModelSettings.tsx,lib/remote-client.ts}; apps/desktop/test/remote-client.test.ts; apps/worker/src/{desktop-runtime,pipeline,stdio}.ts; apps/worker/test/pipeline.test.ts; packages/adapters/src/openai/{responses,tool-loop}.ts; packages/adapters/test/openai.test.ts; packages/contracts/src/{model,http}.ts; tests/e2e/{fixture.ts,managed.spec.ts}; tests/integration/auth.test.ts. This report is orchestration-local under .superpowers.

## Downstream contracts and concerns

Task9 must not simply return published from remote publication.advance. Current pipeline checks current.revision against base before advance, then calls revisions.put/siteCAS; remote ports deliberately reject those writes. Task9 must add trusted server-settlement acknowledgment/recovery, including settlement while the worker is offline, accept only the exact bound revision/manifest and reject unrelated stale base, and remove duplicate worker mutation. Existing SQL settlement/finish fixture proves the reservation seam, not a complete post-publication runJob lifecycle. Real provider ledger, scheduler/reconciliation and external verification remain Task9. Publish/export capability stays off.

Task10 owns batch table expansion/admission and pause/cancel policy. Reuse indexed nullable jobs.batch_id and enqueueInTransaction(tx,job,controllerToken); caller can set batch association within the same transaction. No bulk import or local demo scalability rewrite here.

Task12 must retain metadata ancestry and accepted/new-edit source checkpoints and provider-recovery chains. No terminal/cancel path deletes checkpoint state/files here. Future GC requires its tombstone/availability writer fences.

Task13 aggregation: uncertainRequests is optional on ModelContinuation/ModelResult, absent0, nonnegative integer<=1000 per record. Count represents prior attempts whose billing/token usage is unknown, not actual billed count. Known inputTokens/outputTokens are not adjusted. Count is durably checkpointed with cleared pending/retry progress before redispatch, survives provider recovery and failover, and final transcript retains it. Aggregate latest continuation plus completed transcript, not each historical checkpoint snapshot, to avoid double counting. Current managed UI gives a plain unknown-usage note; aggregate dashboard remains Task13.

Acceptance limits: local real PostgreSQL and injected object/HTTP/model fixtures do not establish managed Supabase/R2 behavior. Native unit/mock/private-pipe evidence does not establish actual Windows Credential Manager/macOS Keychain failures, packaging, Windows11/macOS14 GUI or multi-physical-device operation. Native GUI approval was not retried. Model/network cancellation is cooperative; an already sent external request or issued PUT capability may still complete, but cannot mutate queue/site state without current authority. No exactly-once billing claim.

Self-review: re-read changed transaction/runtime/native boundaries; fixed publication HTTP replay and premature finish, updated all enrollment contract consumers/docs, ensured no SQL transaction spans external calls, preserved private recovery/usage state, checked fresh admin and revocation races and no renderer secret export. New modules were expanded into readable blocks; existing broad runtime/app files were changed narrowly. Full real-provider publication remains an explicit dependency, not a fabricated success path.

## Requested WorkerList visual QA

Captured and inspected `.local-state/managed-workers-harness.png` at1040×680 browser viewport (full-page image1040×707). Initial capture exposed global nowrap table overflow outside the card. Added only `.worker-list` scoped fixed table layout, wrapping, stacked action buttons and wrapped registration action row in app.css. Existing registry/integrations/pagination selectors are unchanged. Final capture includes a long device name and long saved-stage identifier; both wrap readably inside their cells, buttons remain inside the card and there is no horizontal overflow. Normal page scrolling accommodates height. This is an explicit browser fixture, not native acceptance.

After the style fix, `npm run build` exited0 (77modules, JS494.29kB/gzip141.20kB, CSS10.80kB/gzip2.91kB). `npm run test:e2e -- tests/e2e/managed.spec.ts -g 'managed browser harness'` passed1 test (7.2s final long-text run). An intermediate screenshot-fixture edit placed the long-text wait on the integrations view and failed; corrected its location to WorkerList and reran successfully. No production logic changed for capture.

Commit: 201e9c069c266432b5b87526646eb6531c3b406b — feat: add durable leases and multi-device recovery. Post-commit git status --short returned no changes. The orchestration-local report and ignored screenshot remain available at the documented paths.

## Review fix round 1 — Important findings

Fix base: 201e9c069c266432b5b87526646eb6531c3b406b. Scope: the two Important findings from task-8-review.md plus directly necessary tests/documentation. No subagents, external services, native GUI or unrelated cleanup.

1. Job controls now share authorizeControl, called after lockJob has locked the durable job and site. It reads current membership under the transaction and derives authorization from that locked job's kind. Editing retry/cancel requires scoped site:edit. Generation retry/cancel requires current site ownership for non-admins; assignment/read access is insufficient. Admin controls remain supported. No session role or submitted job kind grants permission. Direct HTTP tests cover ordinary owner generation cancel and retry, assigned user/spec-user generation denial, ordinary own/assigned edit denial for paused and waiting_provider states, and a stale spec-user session after fresh DB demotion. Denials assert the complete job row (including state/generation/lease) and, for edits, admission row remain unchanged. Positive controls confirm administrators can operate across owners and a freshly restored spec-user can control their edit.

2. RemoteClient sends configured expectedOrigin on native Start, Stop and Revoke. Native DTOs require it; bound_enrollment validates canonical HTTPS origin and compares the saved enrollment before invoking any private-pipe callback or forwarding a bearer. Mismatch returns CONFLICT and never deletes/overwrites the saved identity. Pending and acknowledged records are both covered. Enrollment/lost-response behavior is unchanged. The native test spies on the actual handle→private-pipe callback boundary: saved A/current B produces zero callback invocations for all three actions, therefore no sidecar HTTP/start/stop command is dispatched. Matched A actions produce exactly managed.start/status, managed.stop/status, managed.revoke/status; revoke receives only A's test bearer and clears storage only after success. The renderer payload test checks that the current configured B origin accompanies B's token before dispatch. This boundary proof uses an injected credential store and callback; the covering native suite separately exercises the real fixed Node private pipe. It is not a live HTTP or OS credential-store acceptance test.

### RED/GREEN and covering commands

All commands used the same assigned worktree. Cargo always used:

`$env:CARGO_TARGET_DIR='C:/Users/sazur/.codex/visualizations/2026/10/26/01a1777f-1fed-7cf3-9158-96e8e92fe058/site-factory/.local-state/cargo-target'; $env:SITE_FACTORY_TEST_NODE='C:/Program Files/nodejs/node.exe'`

- `npm run test:integration -- queue -t 'direct job controls'`: RED exit1, `own paused retry: expected 200 to be 403`; GREEN after edit-kind permission. Clarified assigned-generation case then RED exit1, `assigned generation user retry: expected 200 to be 403`; GREEN after fresh owner/admin check (1 passed/4 filtered).
- `npm test -- apps/desktop/test/remote-client.test.ts -t 'native lifecycle actions'`: RED exit1, expectedOrigin missing from all three request payloads. After fix, `npm test -- apps/desktop/test/remote-client.test.ts`: exit0,6 passed,256ms.
- `cargo test --manifest-path apps/desktop/src-tauri/Cargo.toml lifecycle_origin_mismatch -- --nocapture`: RED exit1, DTO rejected unknown expectedOrigin. After adding required DTO fields and the pre-action guard, `cargo test --manifest-path apps/desktop/src-tauri/Cargo.toml managed::tests -- --nocapture`: exit0,5 passed (includes lost enrollment response, ambiguous OS write and mock ACL). Existing mock icon warning remains deferred.
- Final covering `npm run test:integration -- queue failover auth`: exit0,3 files,16 passed/1 existing live-provider skip,5.48s. Includes added admin/restored-editor positive controls and all earlier queue/failover/auth cases.
- Final covering `cargo test --manifest-path apps/desktop/src-tauri/Cargo.toml -- --skip acl_grants_only_main_local_webview`: exit0,15 passed/1 ignored synthetic OS credential test/1 filtered old GUI ACL test,1.35s test time. Main/doc tests also exit0. Includes actual Node subprocess/private-pipe tests; no native GUI was opened.
- `npm run typecheck`: exit0. `npm run build`: exit0,77 modules; JS494.37kB/gzip141.22kB, CSS10.80kB/gzip2.91kB.
- `git diff --check`: exit0. Incidental Cargo.lock ordering restored. Full unrelated unit/browser suites were not rerun for these scoped boundary fixes.

Changed tracked files this round: packages/adapters/src/postgres-queue.ts; tests/integration/queue.test.ts; apps/desktop/src/lib/remote-client.ts; apps/desktop/test/remote-client.test.ts; apps/desktop/src-tauri/src/managed.rs; apps/control/README.md. Self-review confirmed authorization occurs after job locking/fresh membership, origin check precedes every action callback, no mismatch erases saved state, no new origin/token persistence and no unrelated production changes.

Evidence correction superseding the original concurrency paragraph: only the expiry test observes a waiter using pg_blocking_pids. The revocation portion launches a checkpoint attempt and revokes while holding the worker lock but does not observe the contender reaching the lock wait; it proves rejection after revocation, not the stronger observed-race interleaving previously claimed. This minor coverage finding and raw English progress labels remain deferred by the controller and are not code changes in this fix round. Task9 server-settlement/runJob integration and all platform/live-provider acceptance gaps remain as documented above.

Fix round1 commit: 2f0bdb29f1a5442601f6854d517d8c89e2acfe9d — fix: bind job controls and worker lifecycle to authority. Post-commit git status --short is clean. Scoped re-review range: 201e9c069c266432b5b87526646eb6531c3b406b..2f0bdb29f1a5442601f6854d517d8c89e2acfe9d.
