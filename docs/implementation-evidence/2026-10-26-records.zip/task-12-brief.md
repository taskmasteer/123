### Task 12: Версии, экспорт и восстановление

**Files:** создать `packages/core/src/{history.ts,retention.ts,backup.ts}`, `apps/control/src/routes/history.ts`, `apps/desktop/src/features/history/VersionHistory.tsx`, `apps/desktop/src/features/settings/BackupSettings.tsx`, `apps/desktop/src/features/files/SourceFiles.tsx`, `docs/operations/recovery.md`; тесты `tests/integration/history.test.ts`, `tests/integration/backup.test.ts`.

**Interfaces:** `rollback(actor, siteId, revisionId, expectedRevision): Promise<PublicationIntent>`; `planCleanup(now): Promise<{deletableManifestIds:string[]}>`; `exportSite(actor, siteId, revisionId): Promise<ExportHandle>`; `createBackup(actor, passphrase): Promise<ExportHandle>`; `restoreBackup(actor, archive, passphrase, target): Promise<RestoreReport>`. `listSourceFiles(actor, siteId, revisionId): Promise<{path:string;size:number}[]>` и `readSourceFile(actor, siteId, revisionId, path): Promise<ArtifactFile>` — только admin, с проверкой пути. SourceFiles показывает дерево, содержимое и скачивание. Backup — версия формата, encrypted metadata+files и hashes; ExportHandle передаёт ограниченный поток/файл через Rust, не мастер-ключ.

- [ ] **1. Написать тесты:** после 8 публикаций остаются current+5 previous; draft, candidate, активный job/intent защищены; rollback создаёт действие в журнале. Неверный пароль, отсутствующий файл или hash mismatch не частично восстанавливают рабочую базу. User/spec-user archive export и source-tree endpoints → FORBIDDEN.
- [ ] **2. Запустить** `npm run test:integration -- history backup`; ожидать failures.
- [ ] **3. Реализовать ретенцию и экспорт.** Сироты удаляются после 24-часового grace period и повторной проверки ссылок; отклонённые кандидаты становятся доступными очистке. Подробные job logs — 30 дней, aggregate usage сохраняется. Rollback проходит общий publication pipeline. ZIP пути проверяются при упаковке и восстановлении.
- [ ] **4. Восстановить один сайт с историей в пустой тестовой среде.** Сначала проверить manifest и создать staging restore, затем переключить записи. В recovery.md описать повторное приглашение Auth-пользователей, привязку stable IDs и перевыпуск worker tokens; сервисные ключи не включать в backup. Проверить локальную независимую копию, отличать её от R2 версии.
- [ ] **5. Commit:** `feat: add revision retention and portable recovery`.

