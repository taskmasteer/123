# Task 2 report — static artifacts and isolated validation

Status: DONE_WITH_CONCERNS (implementation and runnable checks complete; platform limitations below).
Branch: codex/site-factory-pilot.
Starting commit: 50c4f2fafbef84258796aef6caf5e076ac1cc0c6.
Implementation commit: 593086a93ac422d222a1575c1d9c46c3ad6565cc (feat: validate static artifacts in isolated chromium).
Date: 2026-10-26.

## Delivered interfaces and files

- Shared FileTools lives in packages/contracts/src/model.ts and has no dependency on apps.
- packages/core/src/artifacts.ts owns portable static path/media validation, case-fold and file/directory collision checks, and resource ceilings.
- packages/adapters/src/safe-files.ts provides private directory walks, reparse-point rejection, bounded regular-file reads, exclusive writes and fsync.
- packages/adapters/src/local-artifacts.ts implements ArtifactStore with complete staged directories, byte snapshots, SHA-256/SHA-1 metadata, and an atomic directory rename before a manifest becomes readable. Reads revalidate metadata, size, hashes, object keys, file paths and media types.
- apps/worker/src/files/tools.ts implements persistent serialized list/read/write/replace. Replace requires one exact match. Writes use exclusive temporary files and rename; neither shell, package installation nor eval is available to model tools.
- apps/worker/src/preview/server.ts serves immutable snapshots only on 127.0.0.1 with a 256-bit random capability URL. GET and HEAD only; no host-control endpoints. Host checks, immutable file mapping, encoded traversal checks, CSP sandbox, permissions policy, no-referrer, no-store, no MIME sniffing, DNS-prefetch opt-out, and rejected WebSocket upgrades are enforced. An HttpOnly SameSite=Strict per-preview capability cookie supports ordinary root-relative resources without exposing them to visitors who lack the URL.
- createPreviewServer(store) returns startPreview(manifestId), preserving the required caller signature while injecting ArtifactStore.
- apps/worker/src/validation/static.ts parses HTML through parse5 and checks artifact boundaries, forms/data-entry fields, active embedded documents and redirects, classic script types, document language, resource URLs, local links/anchors, obvious credentials and placeholders.
- apps/worker/src/validation/browser.ts exports validateSite(files). Every run starts a new Chromium process/profile and incognito context with chromiumSandbox: true, a minimal environment allowlist, blocked service workers, disabled downloads, no granted permissions, HTTP request interception, blocked WebSockets/popups, and restrictive preview CSP. Trusted init code additionally reports prohibited service-worker/download attempts and disables RTCPeerConnection because UDP is outside HTTP interception.
- Both widths 375 and 1440, all HTML pages, console/page errors, resource failures, runtime forms/links/anchors, horizontal overflow and the readability heuristic are checked. Viewport PNGs are persisted under .local-state/validation; report screenshotIds are validation/<uuid>.png.
- Added apps/worker workspace and TypeScript include paths. Pinned playwright 1.64.1 and parse5 8.0.1 in package metadata and package-lock.json. Matching Chromium 156.0.8078.4 / Playwright build 1248 was installed.

Resource ceilings are 100 files, 2,000,000 bytes per file and 10,000,000 total artifact bytes. Browser launch timeout is 5 seconds, navigation 2.5 seconds, individual browser operations/screenshots 2 seconds, with a 10-second overall validation deadline. These are process safeguards, not monetary limits.

## TDD and verification evidence

Initial typed skeletons plus executable tests produced behavioral RED: 45 failed assertions and 1 passing rejection across 46 tests. Unsafe writes incorrectly resolved, content-policy failures incorrectly passed, screenshots were absent, and runtime/overflow/egress/timeout cases were unimplemented. This was reported to the controller before implementation.

Subsequent RED cases exposed and fixed file/directory aliases, safely encoded resource serving, invisible text contrast, runtime anchor removal on a different local page, and silent prohibited service-worker/download attempts. WebRTC initially passed validation and was then disabled explicitly. No generated site JS was executed in Node, node:vm, eval or a shell; generated fixtures run only in Chromium.

Final verification, after the last source change:

- npm test: exit 0; 4 test files passed, 109 tests passed and 1 explicitly skipped (110 total, 51 baseline tests + 59 Task 2 cases).
- npm run typecheck: exit 0.
- npm run build: exit 0.
- git diff --check: no whitespace errors (Git emits its normal LF/CRLF advisory for this checkout).
- Real Chromium cases independently cover HTTP fetch, WebSocket, popup, service-worker registration, dedicated worker, WebRTC construction, download and dynamically created external image. Each run validates both viewports and persists PNG screenshots. A real listening local server records zero requests/upgrade attempts. The test also rejects browser-unavailable as a false substitute for real execution.
- PNG signature bytes are independently asserted against persisted screenshot files.
- A real runaway while(true) renderer produces browser-timeout and is closed within the validation/test deadline.
- Real Windows directory junctions are tested as a child escape and as the configured tools root. Reads, writes and listing reject them; outside files remain intact.
- Artifact persistence checks literal known SHA-256/SHA-1 values for abc, process-independent reopening, immutable input bytes, corrupt stored bytes, forged object keys, duplicates/case aliases, and a forced failure at the atomic-commit boundary. Earlier committed manifests survive; incomplete output is unreadable and failed staging is cleaned.

The managed command sandbox refuses Chromium child process spawning with EPERM. A narrowly scoped exec escalation was used for actual browser test commands; Chromium's own sandbox stayed enabled. Narrow escalation was also used to fetch the pinned npm packages and matching browser cache. No paid calls, accounts or remote service credentials were used.

## Exact limitations and remaining acceptance evidence

1. Windows file symlink creation itself fails with OS EPERM for this account, including an unsandboxed exec. The test named "rejects a symlink file before reading or overwriting its target" conditionally skips only this known Windows privilege error, with an explicit reason. It remains executable on macOS/CI or a Windows environment that already supports file symlinks. This is distinct from the passing real junction coverage. No Developer Mode or OS privileges were changed.
2. System.Environment.OSVersion reports "Microsoft Windows NT 10.0.19045.0". Do not count this local success as acceptance on the declared Windows 11+ or macOS 14+ pilot targets. Neither a supported-target Windows 11 run nor a macOS run was available here. A WMI OS-caption query was denied; no privileged OS-query retry was needed.
3. Readability is an automated heuristic: document language, nonempty body text, visible text elements with computed font size >=12px, and ordinary RGB text contrast over solid RGB backgrounds at ratios >=4.5 for normal text or >=3 for large text. It does not prove complete visual quality, accessibility, language quality, cropping, image/gradient-background contrast, non-RGB color spaces, transforms, or later user interaction states. Retained viewport PNGs support review; they are viewport screenshots (900px high), not a guarantee about every scrolled state.
4. Credential detection covers obvious OpenAI-style keys, AWS access-key IDs and private-key headers. Placeholder detection covers Lorem ipsum, common your-company/brand wording, TODO/TBD and explicit placeholder text/content. These checks do not prove that every possible secret or disguised placeholder is absent.
5. HTTP/WebSocket trap evidence verifies the tested APIs while validation is running. The browser is freshly isolated and sandboxed, but this is not an OS container/VM or a proof against Chromium vulnerabilities. Preview CSP and HTTP interception stay in force throughout a run; publishing must retain equivalent static-site policy in the publication adapter.
6. File storage assumes private process-owned directories. Encountered symlinks/junctions are rejected and bounded reads verify opened inode/device, but this is not a defense against a separate hostile process with the same OS identity racing ancestor replacement. That process already controls the worker account.
7. The interrupted-save fixture forces failure at commit instead of killing the process or simulating sudden power loss. Files are synced before rename. A genuinely killed process may leave an unreferenced .staging directory; readers only resolve completed UUID manifest directories and never expose staging. There is no claim of cross-process database semantics or power-loss durability beyond filesystem guarantees.
8. Screenshot files currently live in local private .local-state/validation storage. Upload/retention/product retrieval belong to later orchestration/storage integration; no public screenshot endpoint was added.

## Self-review

Reviewed all new production modules and shared contract/config diffs after tests. Paths stay portable and constrained; MIME comes from an allowlist; checksums measure the exact saved bytes; object keys cannot choose host paths; model tools expose no process execution; preview contains no mutation/control routes; browser-side site code stays in Chromium; both required widths are exercised; blocked browser launch cannot produce a passing validation. No changes were made to C:/Users/sazur/Desktop/speech.

## Primary documentation checked

- https://playwright.dev/docs/api/class-browsertype (chromiumSandbox, env and launch behavior).
- https://playwright.dev/docs/network (routing and service-worker interception boundaries).
- https://playwright.dev/docs/api/class-browsercontext (init scripts and fresh contexts).
- https://chromium.googlesource.com/playground/chromium-org-site/+/b397a6a505b620f11f9b7f62243a9b89cca3fc5a/developers/design-documents/dns-prefetching.md (DNS-prefetch opt-out header).

## Fix round 1 — two Important review findings

FIX_BASE: 593086a93ac422d222a1575c1d9c46c3ad6565cc.
Fix commit: 711e0a667e5352c154b5f5c78964fa4c26316c2f (fix: bound static validation and accept svg assets).

Scope: the two Important findings in task-2-review.md. The Minor body-direct-text readability item was explicitly deferred by the controller and was not changed.

Changes:
- The language check now applies only to text/html artifacts. A parsed SVG's synthetic HTML wrapper cannot make an otherwise valid SVG logo fail the site.
- Recursive AST walking was replaced with an explicit bounded stack. Each document is limited to 256 nesting levels and 20,000 AST nodes, including queued nodes. Exceeding either limit returns document-complexity with the file path.
- Parser and traversal exceptions become per-file static-error issues. validateSite also guards its static-preflight boundary, so unforeseen analyzer exceptions return a failed ValidationReport before any browser is started.
- No changes to shared contracts, artifact storage, browser sandbox settings, preview policy or the deferred readability behavior.

RED evidence:
1. Command: npm test -- apps/worker/test/validation.test.ts -t 'ordinary local SVG|excessive nesting|HTML parser fails'
   Final RED run after correcting test-only ESM fault-injection setup: 3 failed, 27 intentionally filtered/skipped, exit 1. A valid SVG produced the synthetic lang issue; 5,000 nested divs (~55 KB, below 60,000 bytes) returned OK without a structural bound in the Vitest thread; an injected parser RangeError escaped the validator. The reviewer's compiled-node probe had shown stack exhaustion; a per-document complexity bound is tested independently of host stack size.
2. Command: npm test -- apps/worker/test/validation.test.ts -t 'excessive AST size|static-preflight exception'
   2 failed, 30 intentionally filtered/skipped, exit 1. A broad document below 400,000 bytes returned OK without a node-work bound; an unexpected analyzer exception rejected validateSite instead of returning a report.

Five new regressions cover:
- Ordinary SVG logo accepted by both static validation and real Chromium, with two screenshots.
- Deep allowed-size HTML rejected with document-complexity by both public validation entry points, without throwing or starting Chromium.
- Broad allowed-size HTML rejected by the AST node limit.
- An unexpected parser failure converted to a per-file static-error report by both entry points.
- An unforeseen static analyzer exception converted by validateSite to a failed static-error report.

Fault injection replaces only the named parser/analyzer operation in the two crash-boundary tests. All ordinary fixtures use the actual parser and actual analyzer; the tests assert real validator outputs rather than mock call counts. Complete module exports are preserved. An initial attempt to spy directly on the ESM namespace was rejected as non-configurable; a partial module factory corrected that test setup before behavioral RED was recorded.

Covering final verification (before commit):
- npm test -- apps/worker/test/validation.test.ts: exit 0; 1 file passed, 32 tests passed, no skips. This includes the real sandboxed Chromium SVG case and all existing validation/security behavior. Actual Chromium execution uses the same narrowly scoped exec escalation required by this environment; chromiumSandbox remains true.
- npm run typecheck: exit 0.
- npm run build: exit 0.
- git diff --check: exit 0; normal LF/CRLF advisories only.
- Source received a whitespace-only indentation cleanup during self-review. No behavior changed after the passing checks.
- As requested, the unrelated repository suite was not repeated, and passing checks were not repeated merely after commit.

Self-review: iterative traversal preserves document order and visits template content; depth and queued-node bounds both fail closed; caught parse/traversal failures cannot permit browser execution; ordinary HTML still requires lang while SVG still receives other content/resource checks; no new generated-code execution path was added. Per-file parser input retains the existing 2,000,000-byte bound. Parse5 itself remains a synchronous parser; structural limits govern traversal work and errors are converted to reports, rather than claiming a preemptive wall-clock deadline around synchronous parsing. Existing platform/symlink limitations and heuristic boundaries remain as previously reported. Minor direct body text coverage remains deferred.


