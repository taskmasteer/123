# Task 7/8 queue boundary preparation

2026-10-26. Preparation only, not acceptance/review. Read task-8-brief.md first, then task-7-brief.md, shared-context.md, cloud-boundary-preparation.md and database-testing-research.md. Task 6 is committed at `a4af9de` and under review; Task 7 is not implemented. No production edits, services, DB connections/startup, installations, credentials, native UI or live providers used.

Inspected `packages/contracts/src/model.ts`, `packages/adapters/src/local-queue.ts`, `apps/worker/src/{checkpoints,pipeline}.ts`, relevant editing/checkpoint consumers and local pipeline tests. Graphify guidance consulted; no saved graph exists, so targeted source reads were used without installing/building one.

## Reserve in Task 7

The existing `Queue` exposes enqueue/claim/heartbeat/checkpoint/finish; `Lease` carries jobId/workerId/generation/expiresAt. Its local implementation is explicitly a demo adapter. `SiteRepository.compareAndSet` currently checks revision only; it cannot fence a reclaimed worker. A heartbeat before a mutation does not close that race.

Minimal proposed server-only seam:

```ts
interface LeaseAuthority {
  assertCurrent(tx: SqlTransaction, workerId: string, lease: Lease):
    Promise<{ jobId: string; siteId: string; generation: number }>;
}
```

`SqlTransaction` is the injected driver's existing transaction handle, not an HTTP DTO or new framework. A transaction-bound authority instance is equivalent if its scope is explicit. A standalone preflight returning a reusable “allowed” result is insufficient. Task 7 must reserve this scope even while its production authority remains unavailable.

- Resolve workerId from freshly verified, unrevoked worker credentials; compare it to the lease and database owner. Check running job, exact generation, unexpired stored lease, and matching durable site admission. Ignore submitted expiresAt as authority. Lock the relevant records through the protected write; revocation/cancellation/reclaim must serialize with this check. Use one documented lock order throughout.
- DB/server time governs leases, including the exact expiry boundary (`expiresAt <= now` is stale). Sample time after required lock acquisition. PostgreSQL `now()` is transaction-start time; `clock_timestamp()` changes during execution. Trusted test clocks may replace this inside a fixture seam; no HTTP timestamp or caller-controlled SQL time setting may grant authority. [PostgreSQL time functions](https://www.postgresql.org/docs/18/functions-datetime.html#FUNCTIONS-DATETIME-CURRENT).
- Inject explicitly: absent SQL authority means managed lease-guarded routes return unavailable; no permissive default or production fixture. Existing authenticated registry/admin operations can remain independently usable.
- Persist site admission across API instances: a short locked/CAS operation establishes one active modification/publication operation per site. Bind worker admission to operation/jobId plus generation; job generations alone are not globally unique site tokens. Reclaim updates that binding atomically. Worker site CAS checks authority, admission and expectedRevision in the same transaction. User acceptance/publication must use the same exclusion record. Process-local `serial()` is insufficient.
- Reserve upload_preparations/checkpoints producer identity: server-allocated IDs/keys, job/site, authenticated worker, generation, immutable metadata, completion state and expected predecessor checkpoint. Lease-held mutations never accept arbitrary object keys/site IDs as permission. Distinguish uploaded metadata from byte-verified content. New owners may read the last committed checkpoint from an older generation; that does not authorize an old owner to commit new output.

## Durable checkpoint composition

Keep current pipeline ordering: save private immutable snapshot, then advance queue. Remote implementation:

1. Short prepare transaction checks current authority/admission and stores immutable upload metadata plus expected prior checkpointId. Return scoped keys/PUT URLs.
2. Upload bytes and perform required storage checks outside SQL transactions. Upload success alone does not advance a stage. Private continuation and matching files stay outside public manifests; verify actual hashes before consumption.
3. Short completion transaction rechecks authority and preparation ownership, records completed immutable checkpoint metadata, and, when this is the queue commit endpoint, atomically updates job checkpointId/stage using the expected predecessor. If upload completion and `/worker/jobs/:id/checkpoint` remain separate, completion creates only a durable unreferenced checkpoint; the latter transaction rechecks everything and advances the queue.
4. Return success after commit. Exact retry of the same committed checkpoint is idempotent; a conflicting replay or outdated predecessor cannot overwrite later progress. Same-stage checkpoints are legitimate for model continuation, so stage ordering alone cannot establish freshness.

Crash after upload but before DB commit leaves an orphan; crash after metadata completion but before queue advance leaves an unreferenced record. Neither is resumable progress until job.checkpointId points to it. Crash after queue commit resumes that exact durable snapshot. No R2/model/browser/publication call belongs inside a transaction. Task 8 must decide the additive checkpoint commit argument (prefer expectedCheckpointId) and whether completion combines or precedes queue commit; current `checkpoint(lease, checkpoint)` lacks that ordering contract.

## Cancellation and late effects

Current `runJob` heartbeats every 30 seconds, aborts locally on heartbeat failure, and checks ownership around saves/publication. Current local cancel rejects running jobs; AbortSignal currently maps to paused. Task 8 must explicitly separate graceful pause (finish current stage, then release; no further claims), user cancel (durable invalidation and reject further commits), process shutdown and lease loss. Cancelling must preserve published content. On lease loss the old runner must not attempt a terminal finish under another owner's lease.

Abort is cooperative: an already dispatched model request, PUT or deployment can complete after cancellation/reclaim. Fence its DB results and site-pointer updates, retain/reconcile durable publication intent and provider outcome, and permit orphan cleanup. Do not promise exactly-once provider calls or immediate signed-URL revocation. A fresh owner may repeat an uncommitted model request; record real usage honestly. Task 9 owns real publication reconciliation; queue fencing alone cannot undo a provider promotion already accepted remotely.

## Real PostgreSQL tests to implement later

Use the separate disposable cluster lifecycle in database-testing-research.md with installed PG18 binaries; do not use existing services/credentials. No DB test was run here. Add integration config/script: current Vitest discovery excludes `tests/integration`. Use independent connections, explicit transaction barriers and trusted fixture time/fixture expiry updates, no sleeps.

1. Overlap two claim transactions: disjoint jobs, one increment per successful claim; locked job skipped, remaining eligible job obtained. PostgreSQL documents SKIP LOCKED for queue consumers. [SELECT locking](https://www.postgresql.org/docs/18/sql-select.html#SQL-FOR-UPDATE-SHARE).
2. Concurrent claims by the same device never exceed two live leases. Serialize capacity on the worker record or equivalent; locking different job rows alone does not prevent oversubscription. Concurrent jobs for one site never both receive admission; unrelated sites proceed.
3. Assert 120,000 ms duration, 30,000 ms runner heartbeat, expiry equality rejection, reclaim generation increase and preservation of last committed checkpoint. Forged expiresAt/workerId/time payloads cannot extend ownership.
4. Worker A checkpoints; expire A; worker B reclaims/resumes; release blocked A. A's heartbeat/upload completion/checkpoint/finish/site CAS all fail STALE_LEASE and leave B's state unchanged, including when B has not changed site.revision.
5. Race heartbeat versus reclaim, cancellation/revocation versus commit, and delayed predecessor completion versus newer checkpoint. Assert a valid serialized winner, no resurrection, atomic metadata/queue rollback, exact replay and conflicting replay behavior.
6. Fault barriers after upload, metadata commit, queue commit, and site CAS; reconnect fresh adapters. Assert orphan versus resumable checkpoint distinction, matching continuation/file bytes and stable publication intent. A gated fake provider resolving after lease loss demonstrates rejection of late commits without paid calls.
7. Stale base revision gives CONFLICT; cancel preserves published pointers; pause prevents further claims after its boundary; no online workers leaves queued work untouched. Run direct unauthorized EXECUTE checks using non-owner NOSUPERUSER NOBYPASSRLS roles; SECURITY DEFINER functions require qualified names, empty search_path and restricted EXECUTE. Local SQL evidence remains distinct from managed Supabase/R2/provider acceptance.
