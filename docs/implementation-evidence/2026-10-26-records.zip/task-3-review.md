# Task 3 review — /root/review_task_3

Range 711e0a667e5352c154b5f5c78964fa4c26316c2f..c268674b40a6dfa132b98990428dcd2565d93bac.
Spec: Issues found. Task quality: Needs fixes. Critical: none. Minor: none new.

## Important findings (verbatim)

1. **Persist the pending repair separately from validation.** `apps/worker/src/pipeline.ts:171–173` increments `repairAttempts` and checkpoints stage `validate` before invoking the repair model. If that call encounters quota exhaustion or is interrupted, resumption validates the unchanged files and consumes another repair attempt. Two quota waits can therefore permanently exhaust the repair budget without producing any repaired output; even interruption immediately after the checkpoint loses an attempt. Persist a pending repair stage/instruction and resume that operation before validating again. Add a regression covering a quota wait during repair followed by successful recovery.

2. **Prevent successful writes that make durable storage unreadable.** `packages/adapters/src/private-json.ts:11,17–18` limits reads to 2,000,000 bytes but writes arbitrarily large serialized state. Queue entries and revision records accumulate without deletion, so a transaction can successfully replace the last readable file with one every subsequent operation rejects—including reopening the adapter. Enforce the serialized size limit before replacing the existing file, or use storage that supports the expected growth. Verify that an oversized transaction preserves the previous readable state.

## Strengths

Private checkpoints precede queue advancement; publishable files remain separate. Publication revision identity is persisted before provider calls and registered after success, with post-CAS recovery. Edit output remains an isolated candidate. Reopened-adapter integration verifies frozen selections and indirection. Catalog admin authorization and disabled pinned styles are covered.

## Cannot verify

ReferenceLibrary Task 4, server authorization Task 7, real publication intent/promotion fencing Task 9, and cross-device coordination are explicit later tasks, not omissions of Task 3.

## Review method

Complete supplied diff read, missing middle recovered through bounded reads. No outside-diff inspection, Git operations, mutations or suite reruns.
