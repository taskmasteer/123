**Recover reservations whose provider attachment never completed — ADDRESSED.** `postgres-publication.ts:106` reconstructs attachment from the durable reservation without the original lease/UI key, validates controller journal identity and generation checkpoint evidence, and rechecks publication ownership before insertion. Latest/status discovers active orphan reservations; advance ensures attachment. Concurrent insertion preserves existing ledger data and frozen policy.

**Required durable fairness — NOT ADDRESSED.** The new backoff does not prevent starvation at the actual worker retry cadence.

### New Breakage in the Fix Diff

**Important — An unreadable oldest orphan can still monopolize every automatic tick.** `postgres-publication.ts:125` sets attachment retry to 15 seconds before fallible preparation. Its failure propagates through tick. The existing worker then waits 15 seconds after that error at `runner.ts:40`. Consequently, the orphan is already due again when the next tick arrives, and `postgres-publication.ts:471` selects that oldest row again.

With one active device and a permanently unreadable checkpoint, healthy outboxes and materialized provider steps can starve indefinitely. Slow R2 failures also exhaust the deadline before returning. `tests/integration/publication.test.ts:215` calls subsequent ticks immediately, so its passing result misses production timing. Ensure failures cannot consume every eligible tick through durable fair ordering or bounded continuation to another item; cover the actual retry cadence and slow failures.

### Out-of-Scope Observations

Deferred classified diagnostics, desktop bundle warning, and live provider/platform acceptance remain nonblocking for this scoped review. No additional observations.

### Evidence

- Read the complete 603-line packaged fix diff once, plus scoped admission, checkpoint, authorization and worker continuation dependencies.
- Crash tests cover both origins, fresh services, expired generation leases, concurrent recovery, cancellation, controller journal mismatch, current Resume permission and existing-ledger preservation.
- Provider dispatch/account fencing and evidence-based settlement remain unchanged.
- Report records publication/vercel-contract **19 passed/1 live skip**, affected worker/client tests **33 passed**, publication E2E **1 passed**, and successful typecheck/build/whitespace checks. Counts agree with the reported test coverage; suites were not rerun.
- No source/index/HEAD mutations, live actions, or test execution performed.

**Spec compliance:** Needs fixes—the required automatic fairness property remains unmet.

**Task quality:** Needs fixes—the recovery boundary is repaired, but the fairness regression test omits the production error delay.

**Fix round:** Findings remain open—durable fairness for failed attachment outboxes.
