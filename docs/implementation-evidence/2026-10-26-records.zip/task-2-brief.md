### Task 2: Файлы сайта и изолированная проверка

**Files:** создать `packages/core/src/artifacts.ts`, `packages/adapters/src/local-artifacts.ts`, `apps/worker/src/files/tools.ts`, `apps/worker/src/validation/static.ts`, `apps/worker/src/validation/browser.ts`, `apps/worker/src/preview/server.ts`; тесты `apps/worker/test/files.test.ts`, `apps/worker/test/validation.test.ts`.

**Interfaces:** потребляет ArtifactFile/Manifest/ArtifactStore; производит `FileTools = {list(): Promise<string[]>; read(path: string): Promise<string>; write(path: string, text: string): Promise<void>; replace(path: string, oldText: string, newText: string): Promise<void>}`, `validateSite(files: ArtifactFile[]): Promise<ValidationReport>`, `startPreview(manifestId: string): Promise<{url: string; close(): Promise<void>}>`.

- [ ] **1. Написать тесты containment, контрольных сумм и браузера.** Fixtures — минимальные собственные страницы.
```ts
await expect(tools.write('../outside.txt', 'x')).rejects.toThrow();
await expect(tools.read('C:\\Users\\secret.txt')).rejects.toThrow();
expect((await validateSite(withForm)).ok).toBe(false);
expect((await validateSite(brokenAnchor)).ok).toBe(false);
expect((await validateSite(responsiveSite)).ok).toBe(true);
expect(capturedExternalRequests).toHaveLength(0);
expect(await artifactStore.read(saved.id)).toEqual(originalFiles);
```
Также проверить UNC, drive-relative пути, symlink/junction, URL-encoding traversal, одинаковые имена с разным регистром и прерванное сохранение.
- [ ] **2. Запустить** `npm test -- apps/worker/test/files.test.ts apps/worker/test/validation.test.ts`; ожидаются красные тесты отсутствующей реализации.
- [ ] **3. Реализовать инструменты без shell/eval/npm.** Разрешить index.html, CSS, классический browser JS и локальные ресурсы; исключить package.json, api/, произвольный vercel.json, executable и symlink. Измерять размеры и хэши до фиксации manifest. Preview-server слушает только loopback, выдаёт только текущие файлы по случайному capability URL, не содержит control endpoints.
- [ ] **4. Реализовать Chromium-проверку и выполнить тесты.** `chromiumSandbox: true`, отдельный контекст/профиль, очищенное окружение без ключей, запрет service workers, внешних запросов, WebSocket, popups/downloads. Проверить 375 и 1440 px, внутренние ссылки, ошибки консоли и overflow. Ограничения времени защищают процесс; это не денежный лимит. Не использовать `node:vm` для сгенерированного JS.
- [ ] **5. Commit:** `feat: validate static artifacts in isolated chromium`.

