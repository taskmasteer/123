### Spec Compliance

- ❌ Issues found: the PNG decoder’s preallocation bound can be bypassed, and the new registry status filter omits failed generation jobs. Details below.
- ✅ Requested parser, staged import, retained invalid rows, individual description correction, batch controls, pagination, normalized SQLite persistence, managed admission and explicit assignment scope are implemented.
- ✅ All specifically requested files have corresponding changes. The approved SQLite, runtime, assignment and migration006 adjustments are consistent with the recorded rulings.
- ⚠️ Cannot verify actual managed deployment/provider behavior or Windows11/macOS14 native GUI acceptance from this change. These remain explicitly deferred in `task-10-report.md:83`.

### Strengths

- `packages/adapters/src/postgres-batches.ts:63–94` makes each successful row’s domain reservation, site, generation job and operation admission transactional. Existing-domain conflicts remain isolated to their rows.
- `packages/adapters/src/import-resources.ts:171–191` and `postgres-import-resources.ts:155–177` bind commit replay to the draft, revision and frozen payload, then admit only25 rows through the public path.
- `supabase/migrations/006_batch_imports.sql:6–14` preserves direct grant provenance while adding explicit all-child batch visibility. `tests/integration/batches.test.ts:49–104` exercises authenticated RLS, owner-control denial and preservation of later edit admissions.
- `packages/adapters/src/local-database.ts:103–176` validates legacy inputs before transactional migration, preserves their originals and validates a reopened SQLite connection. `apps/worker/src/desktop-runtime.ts:375–390` drains work before closing the shared database.
- `packages/core/src/import/xlsx.ts:17–122` bounds streamed archive expansion, coordinates, cells and strings before the maintained workbook reader. The cooperative elapsed limit is accurately documented.
- `apps/worker/test/batch-scale.test.ts:24–136` checks5000 durable identities, public25-row admission, partial restart, exact page traversal, snapshot reopen and100 fake jobs with two workers and an isolated failure.
- Inspected measurement artifacts match the report:5000-row commit709.03ms; remaining admission67334.26ms; page traversal332.49ms;100 fake jobs34642.93ms with99 completed/1 intentional attention. The saved unit JSON reports317 passed,2 pending,0 failed. These are local fixture measurements, not real publication capacity.

### Issues

#### Critical (Must Fix)

None identified.

#### Important (Should Fix)

1. **PNG dimension validation checks a header that pngjs can subsequently replace.**  
   `packages/adapters/src/import-resources.ts:23–26`

   `decodeLogo` checks width/height only at fixed offsets16/20, then passes the entire untrusted file to `PNG.sync.read`. Pinned pngjs7 permits another IHDR chunk: `node_modules/pngjs/lib/parser.js:73–86,116–178` does not reject repeated IHDR, and `parser-sync.js:28–29` replaces its metadata each time. Allocation/inflation therefore uses the later dimensions at `parser-sync.js:78–88`.

   A focused112-byte fixture containing a1×1 first IHDR followed by a2049×1 PNG produced:

   `{"accepted":true,"precheckedWidth":1,"decodedWidth":2049,"sourceBytes":112}`

   This bypasses the advertised2048-pixel limit and allows larger attacker-controlled decoded allocations in both managed and local logo completion. Reject duplicate/malformed IHDR chunks before decoding, validate the exact dimensions consumed by the decoder, and enforce a decoded/inflated-byte budget before allocation. Add a regression using the small duplicate-IHDR fixture.

2. **The new “Нужна проверка” registry filter does not find failed generation jobs.**  
   `packages/adapters/src/local-state.ts:142`, `packages/adapters/src/supabase-repository.ts:105`, `apps/desktop/src/App.tsx:176`

   Both list implementations filter the site’s stored `generationStatus`. Failure transitions update only `Job.state` through `pipeline.ts:437`; the site remains `queued`. Consequently failed imports disappear from “Нужна проверка” and remain in “В очереди”, although their displayed job status says attention is required.

   A focused admission→claim→`finish('needs_attention')` check returned:

   `{"jobState":"needs_attention","siteStatus":"queued","attentionFilterCount":0,"queuedFilterCount":1}`

   Define one status projection matching the displayed generation state and use it consistently in local and managed filtering, or atomically maintain the site status during queue transitions. Cover failure and paused/running transitions alongside cursor traversal.

#### Minor (Nice to Have)

1. **Local prepare completion lacks the managed adapter’s state fence.**  
   `packages/adapters/src/import-resources.ts:131`

   Its final transaction unconditionally restores `preview`. Two concurrent direct adapter prepare calls, with commit after the first completes, reproduced a committed101-row batch reverting to preview after only one admission. `postgres-import-resources.ts:103` correctly checks `uploading` first. Mirror that guard locally.

   Current native requests serialize in unchanged `apps/worker/src/stdio.ts:19`, which limits present product exposure; this is adapter robustness rather than a demonstrated native UI race.

2. **Reported gates retain warning noise.**  
   `.superpowers/sdd/2026-10-26-site-factory-implementation/task-10-report.md:52,55`

   The519.84kB bundle warning and conflicting `NO_COLOR`/`FORCE_COLOR` warnings remain. These are acknowledged existing concerns, not new blockers; track bundle splitting and consistent test color configuration.

### Cannot verify / focused checks

- Read the complete packaged diff once in bounded sections; recovered the output-cutoff SiteList line. No changed source file was separately reread.
- Inspected unchanged pngjs parser sources specifically for header replacement and decoded-allocation safety.
- Inspected unchanged read-excel-file `parseSheet.js` specifically for row/formula coordinate preservation; interior row gaps remain represented.
- Inspected unchanged `stdio.ts` specifically to determine whether concurrent local prepare calls are reachable through native dispatch.
- Ran only the three focused checks described above. Did not rerun reported suites, benchmarks, native gates or live services.
- Snapshot database consistency is represented, but full-installation restore still depends on Task12 quiescing/copying external catalog settings and immutable roots as documented in `apps/desktop/README.md:23`.

### Assessment

**Task quality: Needs fixes**

The implementation provides substantial durable admission, authorization and scale evidence, while preserving the existing editing/publication boundaries. The PNG allocation bypass and misleading status filtering require correction before approval.
