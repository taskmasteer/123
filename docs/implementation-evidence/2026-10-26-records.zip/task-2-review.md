# Task 2 review — /root/review_task_2

Range 50c4f2fafbef84258796aef6caf5e076ac1cc0c6..593086a93ac422d222a1575c1d9c46c3ad6565cc.
Spec: Issues found. Task quality: Needs fixes. Critical: none.

## Important findings (verbatim)

- **`apps/worker/src/validation/static.ts:54–63` — SVG assets fail the HTML language check.** SVG files are parsed as HTML, producing a synthetic `<html>` element without `lang`. Consequently, a valid page containing an ordinary local SVG logo fails validation. Restrict the document-language requirement to HTML artifacts and add a valid SVG resource regression test. A focused probe confirmed `{code:"readability", path:"logo.svg", message:"Set the document language."}`.

- **`apps/worker/src/validation/static.ts:35`, `apps/worker/src/validation/browser.ts:26` — nested input escapes validation instead of producing a report.** The recursive AST walker exhausts the Node stack on a roughly 55 KB HTML file containing 5,000 nested divs, well below the file limit. Static preflight executes before the surrounding error handling and deadline, so the browser timeout does not protect it. Use a bounded iterative traversal, handle parser/traversal failures as validation issues, and test deeply nested input. A focused probe confirmed `RangeError: Maximum call stack size exceeded` after approximately 119 ms.

## Minor (deferred)

- apps/worker/src/validation/browser.ts:122–125 — direct body text bypasses readability checks. The selector examines only body *; text directly inside body is excluded. A body containing tiny or white-on-white direct text has no inspected text element. Include the body itself when collecting elements with direct text nodes.

## Cannot verify

- Supported-target acceptance remains unverified: reported browser execution used Windows 10, not Windows 11+ or macOS 14+. File-symlink coverage was conditionally skipped; actual junction coverage exists.
- Broader visual quality and arbitrary secret detection remain heuristic, as disclosed. Publication-side enforcement belongs to later integration.

## Strengths and method

Atomic immutable artifact snapshots/hashes; bounded symlink-rejecting reads; immutable loopback capability preview; sandboxed Chromium and allowlisted environment; real egress traps and runaway-renderer coverage. Reviewer read complete diff (recovering output truncation), ran two focused read-only compiled-validator probes, did not rerun suite or inspect unrelated source.
