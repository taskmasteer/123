# Deferred findings index for the final whole-branch review

These are historical Minor items, not current confirmed defects. Inspect final source/task13–14 reports before deciding disposition. Source entries are in progress.md at the indicated task labels; original review files carry precise lines. Do not reopen completed task gates or rerun their suites merely because an item is indexed.

- Task1: corrupt-state test rejected savedAt before exercising invalid site/duplicate identity; local process ownership uses resolve rather than realpath (junction aliases).
- Task2: readability selector body * misses direct body text.
- Task4: Russian registry plural count. First-load failure/empty distinction and touched App/runtime/CSS formatting were addressed in reviewedTask5; retain that disposition unless final source regresses.
- Task5: persistent chat refinement relationship/label, handed toTask11 touched UI; verify final disposition.
- Task7: compressed SQL/DTO modules; calibrate actual final maintainability, no size-only finding on unchanged source.
- Task8: raw English stage/state values in WorkerList. Historical revocation test proved post-revocation rejection, NOT observed overlapping contender lock wait; only expiry barrier was observed. Reports must preserve this distinction unless later tests supply the missing evidence.
- Task9: generic catch loses classified safe publication attention reason; Task13 owns allowlisted diagnostic code/action/time/retryability while preserving unknown-result reservations/reconciliation/fairness.
- Task10: duplicate local prepare completion lacks state fence, existing serialized stdio prevented demonstrated concurrent UI reachability. Read task-10-review.md and final ownership/drain changes before classifying.
- Tasks6–12: inherited NO_COLOR/FORCE_COLOR warning, LF/CRLF notices, growing main chunk advisory (Task15 latest561.33kB). Task14 owns narrow launcher normalization/lazy feature splitting; retain actual warnings until fixed.
- Task7 visual QA: full-page pending invitation screenshot had sticky/sidebar scroll stitching artifact; actual viewport check rather than inferring native layout defect.

Actual Win11/WebView2, macOS14 arm64/x64 install/headful/descendant cleanup, signing/notarization, credential-store integration, live Supabase/R2/Vercel/DNS/HTTPS and two physical devices are external acceptance gaps ownedTask14. Existing pure/native mocks/headless/synthetic failover do not prove them. Same-adapter encrypted independent backup is approved v1; cross-adapter migration is separate. Full900k encrypted-member/13.5GB-body benchmark was never claimed by small-body transport/metadatainstallation evidence.

Initial branch BASE for final broad review is2b2fbefec0f6879fb36bec36c83cd755d1979812. Read the skill final-review reference when every task has completed, rather than treating this index as the review itself. Preserve accidentally trackedTask1 scratch report before any mandated final workspace cleanup; no blind clean/delete.
Task15 review M1: tests/integration/backup.test.ts:200/:207 earlyState detector compares bulk query parameter array directly with sourceStateKey string, making this particular assertion unreachable. Other restore/load assertions remain meaningful. Triage actual checkpoint-state read/barrier in final source; do not route a Minor into Task15 fix loop. Task15 M2 reiterates561.33kB advisory assigned14.
Task13 M1 coverage: tests/integration/health.test.ts:40–45 changes revision but not same-revision/new settled outcome. Code compares outcome correctly; add focused SQL sameRevision/newOutcome stale-read, stale-completion and due-claim regression during final14/final triage. Task13 M2 reiterates570.42kB/NO_COLOR warnings; default-worker failures stay separate from409worker1 proof.
Task14 M1: scripts/finalize-runtime.mjs:13 andlib/package-runtime.mjs:38 lack approved source revision/explicitdirtyfingerprint provenance in manifest; independentcompiledresourceintegrityotherwiseworks. Finalreviewtriagesourceidentityrecording.
Task14 M2: lib/package-runtime.mjs:69/:98 bare vendor imports are collected but not containment-resolved; portable/extractedsmokesundercheckoutcouldfindomittedvendorinancestor node_modules. Noactualmissingpackageestablished; finalreviewtriagestageddependencygraphresolution/isolatedcopyverification, retaincleanmachinegap. TheseMinorsareoutside14I1fixloop.

## Final residuals after the one scoped rereview (current)
- NB1 parked realMinor: local uppercase domain filter + second response-byte prefix may produce INVALID_INPUT cursor; lower-case/remove filter and restart. Exact pure probe and lines in final-rereview.md.
- NB2 parked realMinor: registry/batch may stop polling at waiting_provider while autonomous publication still settles; manual refresh/focus or PublicationPanel shows progress. Backend fencing/publication preserved. Safe pending-publication activity projection is future maintenance.
All16original broad findings are addressed; these2newMinor are explicitly adjudicated under the agreed one-wave/one-rereview cap, not dismissed or unreviewed fixed. Full decisions/costs in final progress rulings.
