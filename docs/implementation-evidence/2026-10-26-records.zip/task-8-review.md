### Spec Compliance

❌ **Issues found.** The durable queue, checkpoint fencing, publication reservation, native enrollment and managed runner are substantially implemented, including the approved `003_queue_leases.sql` adjustment. Two authorization/origin-boundary defects require correction.

⚠️ Real provider publication continuation and post-settlement `runJob` recovery remain Task9 work. Supported-platform/native GUI and live cloud acceptance remain unverified.

### Strengths

- `supabase/migrations/003_queue_leases.sql:29` implements transactional claims, worker capacity serialization, generation increments, restricted SECURITY DEFINER execution and post-lock lease checks.
- `packages/adapters/src/postgres-queue.ts:231` distinguishes immutable uploaded checkpoints from committed progress and enforces predecessor, producer and generation binding.
- `packages/adapters/src/postgres-queue.ts:160` preserves publication ownership independently of worker cancellation. Settlement remains server-only, and premature completion is rejected.
- `apps/desktop/src-tauri/src/managed.rs:64` persists pending enrollment before HTTP and returns an explicitly constructed safe summary. The loss/retry tests exercise meaningful recovery behavior.
- `packages/adapters/test/openai.test.ts:129` covers a second crash after durable uncertainty accounting, retaining known token totals without counting the same ambiguous attempt twice.

### Issues

#### Critical

None found.

#### Important

1. **Job controls authorize editing operations using read permission.** `packages/adapters/src/postgres-queue.ts:81,148`. Both retry and cancel accept `site:read` for every job kind. An ordinary `user` with access to a site can therefore cancel its AI edit or resume a paused/waiting edit through direct HTTP requests, including after demotion from `spec-user`. The approved role matrix permits ordinary users to cancel their unfinished generation; AI editing requires `spec-user` or `admin`. Authorize according to the locked job's kind and operation, requiring `site:edit` for editing controls. Add direct-route tests for ordinary users and freshly demoted editors.

2. **Revocation can forward the current installation's administrator bearer to a different saved installation.** `apps/desktop/src/lib/remote-client.ts:38`, `apps/desktop/src-tauri/src/managed.rs:146`. `worker.remove` obtains the current client's token but supplies no expected origin. Native revocation sends that bearer to `saved.origin`; the client compares returned origin with `this.base` only after the request has occurred. With enrollment for installation A and a current session for B, this boundary can disclose B's bearer to A. Pass the expected configured origin and reject mismatched saved enrollment **before** any network request. Apply the same pre-action binding to start/stop, and test that mismatches produce zero HTTP calls.

#### Minor

1. **Worker progress exposes untranslated internal values.** `apps/desktop/src/features/workers/WorkerList.tsx:80` renders values such as `validate · running` directly. This falls short of the Russian panel requirement. Map known stage/state values to Russian labels and provide a safe fallback.

2. **The report overstates the revocation race barrier.** `tests/integration/failover.test.ts:248` starts checkpoint commit and then revokes/releases the worker lock without observing that the contender actually reached its lock wait. Unlike the expiry portion, this section does not poll `pg_blocking_pids`. It may pass with checkpoint execution beginning after revocation commits. Add an observed barrier or narrow the report's claim.

### Cannot verify / evidence limits

- `apps/worker/src/remote-worker.ts:178`: pending publication handoff is delivered; real provider continuation and exact server-settlement acknowledgment through `runJob` are not. The direct settlement fixture does not establish that later lifecycle.
- PostgreSQL/storage/model fixtures do not establish deployed Supabase/R2 behavior or operation across physical devices. Native mock/private-pipe tests do not establish Credential Manager/Keychain behavior, packaging or Windows/macOS GUI acceptance.
- The reported mock icon warning remains test-output noise; previously deferred platform/tooling warnings remain Task14 follow-up.
- No suites were rerun. Focused dependency checks covered the role matrix and permission helper, repository admission/current-job contracts, editing recovery, OS-store encoding compatibility and remote upload transport. Cut-off function continuations were inspected in `pipeline.ts`, `responses.ts` and native `worker.rs`; no source/index/HEAD changes were made.

### Assessment

**Task quality: Needs fixes.**

The queue and recovery implementation has strong transactional boundaries and useful failure tests. Correct the job-control permissions and native origin binding before approving Task8; retain the explicit Task9 and platform acceptance limitations.
