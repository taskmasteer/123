### Task 5: Чат правок и принятие кандидата

**Files:** создать `packages/core/src/editing.ts`, `packages/contracts/src/editing.ts`, `apps/desktop/src/features/editor/{SiteEditor.tsx,ChatPanel.tsx,PreviewComparison.tsx}`; изменить local-state.ts, stdio.ts, desktop-client.ts; тесты `packages/core/test/editing.test.ts`, `tests/e2e/ai-edit.spec.ts`.

**Interfaces:** `requestEdit(actor: Principal, siteId: string, instruction: string, expectedRevision: number, candidateId?: string): Promise<Job>`; `acceptCandidate(actor, siteId, candidateId, expectedRevision): Promise<Site>`; `rejectCandidate(actor, siteId, candidateId): Promise<void>`; `getConversation(actor, siteId): Promise<ChatMessage[]>`. Методы pipe: `edit.request|edit.accept|edit.reject|chat.list|site.publish`. Candidate хранит baseRevision, baseDraftId, manifestId, status и проверку.

- [ ] **1. Написать проверки принятия, отклонения, уточнения и конфликта.**
```ts
expect(afterCandidate.publishedId).toBe(before.publishedId);
expect(afterReject.draftId).toBe(before.draftId);
expect(afterAccept.draftId).toBe(candidate.id);
expect(afterAccept.publishedId).toBe(before.publishedId);
expect(staleAcceptError.code).toBe('CONFLICT');
expect(secondInstructionBase).toBe(candidate.manifestId);
expect(afterRestartConversation).toEqual(savedConversation);
```
Дополнительно user получает FORBIDDEN; неудачная правка не меняет два указателя версии.
- [ ] **2. Запустить** `npm test -- packages/core/test/editing.test.ts`, затем `npm run test:e2e -- tests/e2e/ai-edit.spec.ts`; оба пока красные.
- [ ] **3. Реализовать состояния** queued/running/checking/ready/rejected/accepted/conflict. Последний принятый черновик — база первой правки; уточнение использует выбранного кандидата, но не меняет baseRevision. При втором активном запросе показать «Дождитесь завершения или отмените текущую правку». Предпросмотр «до/после», summary, кнопки «Уточнить», «Принять в черновик», «Отклонить», «Опубликовать».
- [ ] **4. Проверить сценарий create → edit → refine → accept → publish → edit → reject.** Только явная публикация правки переключает publishedId. Не перегенерировать весь сайт ради изменения текста; scope определяется запросом. При конфликте сохранить вариант отдельно и предложить повтор на актуальном черновике.
- [ ] **5. Commit:** `feat: add per-site ai editing and candidate review`.

