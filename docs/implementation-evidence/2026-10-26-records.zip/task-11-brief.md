### Task 11: Визуальные правки существующих элементов

**Files:** создать `packages/core/src/visual/{html-patch.ts,css-patch.ts,editable-map.ts}`, `apps/desktop/src/features/editor/{VisualEditor.tsx,ElementInspector.tsx,preview-bridge.ts}`; тесты `packages/core/test/visual.test.ts`, `tests/e2e/visual.spec.ts`, `tests/e2e/preview-isolation.spec.ts`.

**Interfaces:** `ElementPatch = {elementId:string; text?:string; href?:string; imageAssetId?:string; styles?:{color?:string;backgroundColor?:string;fontSize?:string;margin?:string;padding?:string}}`; `applyElementPatch(actor, siteId, expectedRevision, patch): Promise<Revision>`. Разрешённый набор значений проверяется; текст не превращается в raw HTML.

- [ ] **1. Написать тесты:** текст с <script> становится текстом; javascript: URL отвергается; меняется только нужный узел; внешние ресурсы и parent navigation не допускаются. После визуальной правки ИИ меняет структуру, сохраняя новый текст. Поддельное message с чужим source/token не вызывает сохранение.
- [ ] **2. Запустить** `npm test -- packages/core/test/visual.test.ts`, `npm run test:e2e -- visual preview-isolation`; ожидать failures.
- [ ] **3. Реализовать HTML/CSS AST patch и отдельный preview.** Стабильные element IDs и sidecar map, запись исходника, без сериализации runtime DOM. Preview iframe с opaque origin, sandbox без allow-same-origin, запрет forms/popups/top-navigation; только собственный nonce bridge, сгенерированные scripts в режиме выделения отключены. Ни одна native capability не доступна этому контексту. Сервисные IDs не раскрывают tenant/account/provider secrets.
- [ ] **4. Проверить выбор, правку и конфликт** на Windows WebView2 и macOS WKWebView; отдельно проверить isolation через custom Rust commands. Если iframe-поведение платформы не даёт требуемой изоляции, использовать внешний Chromium preview с выделением через доверенный драйвер, не ослаблять ACL.
- [ ] **5. Commit:** `feat: add source-preserving visual edits`.

