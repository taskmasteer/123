### Task 3: Генератор и пять собственных направлений

**Files:** создать `apps/worker/src/pipeline.ts`, `apps/worker/src/checkpoints.ts`, `apps/worker/src/model/types.ts`, `packages/adapters/src/fake-model.ts`, `packages/adapters/src/fake-publication.ts`, `packages/adapters/src/local-queue.ts`, `templates/catalog.json`, `templates/{light-product,dark-tech,editorial,corporate,diagram}/index.html`, соответствующие `styles.css`, `references/catalog.json`, `apps/desktop/src/features/references/ReferenceLibrary.tsx`; тест `apps/worker/test/pipeline.test.ts`.

**Interfaces:** `ModelRequest = {mode: 'generate' | 'edit'; site: Site; instruction: string; baseManifestId: string | null; conversation: ChatMessage[]; styleId: string; selectedElementId?: string}`; `ChatMessage = {id: string; role: 'user' | 'assistant'; text: string; createdAt: number}`; `ModelResult = {summary: string; inputTokens: number; outputTokens: number; providerResponseId?: string}`; `runJob(job: Job, lease: Lease, deps: WorkerDeps, signal: AbortSignal): Promise<void>`. WorkerDeps: Queue, SiteRepository, ArtifactStore, CheckpointStore, ModelPort, Clock и PublicationPort.

- [ ] **1. Написать fake-provider тесты полного прохода и ошибок.**
```ts
expect(completed.state).toBe('completed');
expect(manualBriefUsed).toContain('user supplied description');
expect(new Set(batchStyles).size).toBe(5);
expect(failed.state).toBe('needs_attention');
expect(repairCalls).toBe(2);
expect(otherJob.state).toBe('completed');
expect(freshJob.publishedId).not.toBeNull();
```
Фиксировать seed; повтор этапа не меняет тему, шаблон или выбранное изображение.
- [ ] **2. Запустить** `npm test -- apps/worker/test/pipeline.test.ts` и получить ожидаемые failures.
- [ ] **3. Реализовать сохраняемые этапы** brief → assets → generate → validate → archive → publication. Тема из about имеет приоритет; пустое about создаёт отдельную английскую IT/crypto-тему. Шаблоны собственные, структура может изменяться моделью. FakeModel детерминированный и возвращает флаг демонстрационного режима в runtime status. Служебные brief, tool transcript и resume metadata идут в отдельный private checkpoint, а не в публикуемый manifest. Публичный артефакт содержит только финальные файлы сайта; тест проверяет отсутствие служебных JSON и истории prompts.
- [ ] **4. Проверить тесты и render пяти шаблонов.** Без форм, выдуманных клиентов/отзывов, framework runtime и внешних shared assets. На старте страницы содержат title/charset/viewport, осмысленные якоря и техническую настройку noindex для пилота. Схемы и простые SVG допустимы. ReferenceLibrary показывает доступные стили и источник; admin может отключить стиль для новых jobs и изменить описание референса. Версия шаблона, уже записанная в job, не меняется. Локальный доступ задаёт authorize; после задачи 7 эти операции используют серверные admin endpoints.
- [ ] **5. Commit:** `feat: add resumable generation pipeline and starter styles`.

