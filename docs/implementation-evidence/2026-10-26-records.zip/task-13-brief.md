### Task 13: Доступность, HTTPS и расход ресурсов

**Files:** создать `apps/worker/src/health/{scheduler.ts,probe.ts}`, `packages/core/src/usage.ts`, `apps/control/src/routes/health.ts`, `apps/desktop/src/features/sites/HealthStatus.tsx`, `apps/desktop/src/features/settings/UsagePanel.tsx`; тесты `tests/integration/health.test.ts`, `packages/core/test/usage.test.ts`.

**Interfaces:** `probeSite(siteId, expectedRevisionId): Promise<{checkedAt:number; status:'ok'|'dns_pending'|'https_error'|'unreachable'|'wrong_version'; detail:string}>`; `scheduleHealth(now): Promise<string[]>`; `UsageEvent = {jobId:string; provider:string; inputTokens:number; outputTokens:number; bytesStored:number; durationMs:number; estimatedCostUsd:number|null}`.

- [ ] **1. Написать тесты:** healthy, NXDOMAIN, certificate error, wrong release, redirect на private IP, DNS rebind и IPv6 loopback. Никогда не отключать TLS validation. Assert расписание 6 часов, отсутствие повторного активного health job, устаревшая проверка видна после offline.
- [ ] **2. Запустить** `npm run test:integration -- health`, `npm test -- packages/core/test/usage.test.ts`; ожидать failures.
- [ ] **3. Реализовать worker-based мониторинг.** Ограничить адреса зарегистрированными доменами, проверять разрешённый IP при соединении и на каждом redirect, не отправлять cookies/ключи. Не выполнять HTTP probe в привилегированном renderer. Выключенные устройства означают stale status, а не выдуманный success.
- [ ] **4. Проверить статистику** retries и incomplete attempts; неизвестная стоимость = null, не 0. Токены/время/объём показывать отдельно от оценки по тарифу. Денежного auto-stop нет. Не выдавать оценку за счёт провайдера и не делать непрерывный polling, удерживающий базу активной.
- [ ] **5. Commit:** `feat: add worker health checks and usage accounting`.

