### Spec Compliance

- ❌ **Issues found.** All eight explicitly requested new files, the native/control/SQL delegation, recovery documentation and next operational migration are present. The bounded batch protocol and separate durable preparation/READY activation are implemented. Two correctness gaps prevent approval of the required idempotent replay and immutable Auth mapping behavior: Important I1 and I2 below.
- ✅ `packages/contracts/src/recovery-transfer.ts:3`, `:62` define and enforce the requested 1 MiB decoded / 2 MiB encoded / 256 metadata / 64 resource limits. `apps/worker/src/native-archives.ts:138` owns the operation-scoped transport and `:146` suppresses renewal before draining an admitted renewal for final commit. `packages/adapters/src/postgres-restore-preparation.ts:50`, `:577` separate exclusive SQL activation from body preparation.
- ✅ `supabase/migrations/009_recovery_transfer.sql:1` adds operational progress/receipts/parts/proofs with public-role revocations; the package does not change migrations001–008 or the encrypted archive codec. No provider, dependency, live-account or product-workflow expansion appears in the supplied change.
- ⚠️ **Cannot verify from diff — actual platform/provider acceptance.** Windows11/macOS14 GUI/chooser/package/credential ACL, two physical devices, live Auth/R2/Vercel deployment behavior, session-affine database configuration and deployed Fluid limits remain Task14-owned acceptance. The report and `docs/operations/recovery-transfer-design.md:46` explicitly retain these gaps. The task-scoped review does not close them.
- ⚠️ **Cannot verify from diff — full-body/archive throughput.** The measured full count run starts after encrypted extraction and uses valid small physical bodies. It does not establish a900k-member encrypted physical archive run, 13.5 GB body throughput, measured remote RTT or 48 GiB envelope acceptance. This is the documented compositional Task15 proof, not a missing full-body claim; Task14 owns the remaining acceptance and must retain those distinctions.
- ⚠️ **Cannot verify from diff — unchanged native/codec internals.** Rust IPC, full STORE/ZIP64/GCM/old-reader internals and other unchanged validators are outside the supplied hunks. The report records covering archive/native/history tests, and the package leaves their formats/core interfaces intact; final branch review and Task14 must preserve those limits. No unsupported platform or full-body success is inferred.

### Strengths

- `apps/control/src/app.ts:168` authorizes current admin and transfer scope before selecting the large body parser; `apps/control/src/routes/recovery-transfer.ts:7` derives session binding only after verification of the exact bearer. `tests/integration/recovery-transfer.test.ts:80`, `:124`, `:266` exercise issuance binding, same-SID signed refresh, foreign/unbound capabilities and authorization before oversized-body parsing.
- `packages/adapters/src/postgres-recovery-transfer.ts:388` records owned destination keys before object IO, and `tests/integration/recovery-transfer.test.ts:322` covers cancellation while a late immutable PUT is still pending. The design keeps IO outside installation SQL transactions and retains discoverable cleanup ownership.
- `packages/adapters/src/postgres-restore-preparation.ts:389` reuses the existing checkpoint projection with exact server-verified file proofs instead of redownloading every checkpoint file. `packages/core/test/retention.test.ts:33` checks byte/digest projection equivalence and ordering; `tests/integration/recovery-transfer.test.ts:186`, `:701` cover legacy proof upgrade and no-file-redownload behavior.
- `apps/worker/src/desktop-runtime.ts:525` waits for admitted maintenance before persistence closes, and `apps/worker/src/native-archives.ts:135`, `:469` drain owned operation/request work. The new controlled barriers test the maintenance, disposal and final-commit/renewal admission orderings.
- `tests/integration/recovery-transfer.test.ts:459`, `:703` use the actual NativeArchives-owned runner/control/disposable PostgreSQL chain with stable-ID, evidence, owner-remap, quarantine and empty-target-before-commit assertions. The saved `.local-state/task15-transfer-5000.json:1` records900009 source metadata,270000 descriptors,3525 backup-budget calls,14836 total restore calls, maxInflight2, request/response683675/683822B, commit41600.23ms and observed1094253.21ms.
- `packages/adapters/src/postgres-restore-preparation.ts:613` replaces catalog edge insertion with one parameterized setwise statement; `tests/integration/recovery-transfer.test.ts:825` tests multiple distinct versions, conflict handling and absence of body IO in activation.

### Issues

#### Critical (Must Fix)

- None found.

#### Important (Should Fix)

**I1 — A delayed identical acknowledgement can move the durable cursor backwards.**

- **Location:** `packages/adapters/src/postgres-recovery-transfer.ts:367`–`:375`, particularly the unconditional metadata/resource cursor updates at`:371` and`:374`.
- **Cause:** The method reads an incomplete receipt outside the final transaction at`:362`, then locks the transfer state but never rereads that receipt's completion status or verifies that the current cursor still equals this receipt's input cursor. Two identical requests can both enter this path. If one acknowledges batch A, batch B then completes, and the delayed A acknowledgement finally runs, it overwrites B's cursor with A's older output. Row locking serializes these writes but does not make the stale write valid. The existing stale-receipt test at `tests/integration/recovery-transfer.test.ts:705` covers the earlier receipt-insertion race, not this later acknowledgement race.
- **Impact:** An ambiguous POST retry can regress metadata_seq or resource_seq/resource_offset after newer work is acknowledged. Subsequent writes can hit already-existing metadata/proof rows or be rejected at the wrong cursor, preventing a resumable restore from progressing. This violates the required idempotent replay/order semantics even when every retry has identical bytes.
- **Focused verification:** Executed the supplied diff's actual `PostgresRecoveryTransfer.stageBatch` method by in-memory TypeScript transpilation, with valid framing and a deterministic transaction/receipt persistence stub. The first identical A call was held immediately before its final acknowledgement transaction; a second A call advanced0→1, a B call advanced1→2, then A was released. Output: `{"test":"late identical metadata acknowledgement","expectedCursor":2,"actualCursor":1,"regressed":true}`. Exit0 asserts that observed defect; it is not a passing product regression. No files, production state, SQL cluster, Git state, suites or repeated races were modified/run. Framing validators were stubbed because the unanswered doubt was final acknowledgement ordering; the production acknowledgement branch itself was executed.
- **Fix:** Inside the final transaction, after fresh state/scope authority, reread/lock the exact receipt and check its digest. If already complete, return current progress without cursor writes. Otherwise require the current staging cursor to equal the receipt's input cursor before advancing it atomically. Add a real-SQL deterministic regression that holds the late acknowledgement across the next acknowledged batch, for both metadata and resource cursor/offset paths.

**I2 — Legacy staging can reach READY without freezing Auth mappings.**

- **Location:** `packages/adapters/src/postgres-backup.ts:165`; `packages/adapters/src/postgres-recovery-transfer.ts:468`–`:478`, with the only mappingDigest write at`:359`.
- **Cause:** `addMappings` treats the presence of mappingDigest as the sole freeze guard. Only the new `stageBatch` path sets it. The retained HTTP record-part/record-complete staging routes can fill a bound restore without calling stageBatch; `prepareBatch` then accepts the complete staged records and changes phase without recording the mapping digest. `apps/control/src/routes/recovery.ts:49`–`:54` continues to admit mappings on that same transfer ID. Neither authorization nor addMappings prohibits a changed mapping while phase is preparing/validating/ready.
- **Impact:** Stage a restore through the retained legacy routes with source user S→destination D1, prepare it to READY, then submit S→D2 through mappings. The call is accepted, although prepared user/site/actor rows already contain D1. Final commit uses the newly read D2 mapping for installation/quarantine/report metadata while installing the D1-transformed rows. Concurrent mapping changes between cohorts can also produce a mixed preparation. The new durable READY boundary must freeze Auth identity independently of which supported staging route produced the records.
- **Fix:** Freeze the verified mapping digest atomically when preparation first starts, for all staging paths, and reject changed mappings after that boundary while allowing exact replay if desired. Recheck the frozen digest at READY/commit. Add a mixed legacy-stage/new-prepare regression showing a changed mapping cannot alter an already-prepared restore.

#### Minor (Nice to Have)

**M1 — The migrated delayed-remap test has an unreachable early-read detector.**

- **Location:** `tests/integration/backup.test.ts:200`, assertion at`:207`.
- **Cause/impact:** The wrapper now handles the bulk `data->>'source'=any` query whose second parameter is an array, but still compares that parameter directly with the string sourceStateKey. Therefore earlyState cannot become true, and that particular assertion no longer detects the ordering regression it describes. The test's other restore/load assertions remain meaningful, so this is not a claim that the whole test asserts nothing.
- **Fix:** Observe the actual checkpoint state-body read through the transport, or compare the relevant array membership and use the intended barrier; ensure a deliberately early state read makes this assertion fail.

**M2 — The final build retains the desktop bundle advisory.**

- **Location:** `.superpowers/sdd/2026-10-26-site-factory-implementation/task-15-report.md:95` (561.33 kB Vite advisory).
- **Cause/impact:** Final verification is successful but not warning-free. The package does not show a Task15-specific bundle regression; this remains a visible performance/packaging follow-up rather than a Task15 correctness blocker.
- **Disposition/fix:** Retain Task14/final-review ownership. Inspect the packaged desktop bundle and address unnecessary eager code/splitting if warranted; do not hide the warning or describe the build as pristine.

### Review Checks and Evidence Disposition

- **Scope checked:** BASE2d2a9e4f9553283e3b66e053b040ea3b7107953a→HEAD82d095299d45de374e0f0068b759cc5141b36ca9, all30 paths in the457124B supplied package, read sequentially in bounded chunks. One truncated documentation output was recovered from its unread package range. No Git requery or broad crawl.
- **Named cut-hunk check:** The `stageRecord`/metadata completion context in postgres-backup.ts was cut before its write guards. Read only lines123–221 to assess the concrete cross-API risk of legacy staging/mapping mutation after durable preparation. Existing staged records are immutable; the unguarded legacy Auth-map transition is I2. No other source-file reread or broader code inspection was performed.
- **Evidence read:** Entire brief, shared global constraints, controller rulings, implementation report and reviewer contract; exact saved final5000 measurement artifact. Report claims were compared against the implementation and tests, not treated as a correctness waiver.
- **Full-run boundary:** The report's final22/22PASS full run precedes the catalog-edge setwise factor. The HEAD delta has the focused31PASS/1fullskip SQL/native/backup/visual verification and fresh typecheck/build recorded at report`:95`. The activation test at `tests/integration/recovery-transfer.test.ts:825` covers the multi-version delta. Earlier1178.59s success, later timeout and interrupted known-defect run are historical evidence, not passes for final HEAD. No full-volume rerun was requested or performed here.
- **Tests run by reviewer:** Only the single deterministic in-memory acknowledgement-order check described in I1. No package suite, full5000 proof, native GUI, provider/account, network, install or credential action.

### Assessment

**Task quality:** **Needs fixes**.

**Reasoning:** The implementation substantially closes the large-copy call-budget and durable-preparation problem, with strong real-SQL and measured evidence. The remaining stale-ack cursor rollback and staging-path-dependent Auth-map freeze undermine retry safety and immutable preparation, so Task15 should not pass its gate until I1 and I2 are fixed and narrowly verified. Issue counts: **0 Critical, 2 Important, 2 Minor**.
