- **I1 - Mac ownership socket fails under ordinary long data/temp paths** - ADDRESSED. `apps/desktop/runtime-guard/src/owner_socket.rs:12`, `:22-29`, `:44-60` allocate the fixed `/private/tmp/sf-guard-<32hex>/owner.sock` endpoint (65 ASCII bytes), independently of application data and ambient TMPDIR, while retaining the 100-byte bound. Exclusive nonrecursive mkdir uses Unix mode0700 at creation; existing collisions are retried without adoption. The nonce has independent 128-bit OS entropy; the existing 256-bit token remains unchanged in `apps/desktop/runtime-guard/src/macos.rs:482-488`.
- **I1 ownership and integration check** - ADDRESSED. `owner_socket.rs:65-77` leaves profiles at `data/runtime-temp`; `:87-92` retains socket mode0600/nonblocking operation; `:94-112` removes only the fixed endpoint and newly created empty directory, including early-return cleanup. `macos.rs:488-536` integrates the new endpoint and listener lifetime guard; `owner_socket.rs:129-139` stops/joins before path cleanup. Normal drain remains in `macos.rs:564-573`. The fix does not alter fixed-helper/token authentication, direct-parent/fd5 checks, fd1/2/3/4 transfer, safe argument/environment rules, or retained direct-child group ownership.
- **I1 regression coverage check** - ADDRESSED. `owner_socket.rs:173-199` covers deliberately long data and the ordinary Mac smoke-root shape. `:202-245` covers collisions, failure paths, unbound cleanup, and refusal of recursive deletion. `:248-275` verifies stop/join before endpoint removal. Mac-only tests at `:279-320` cover actual fixed-root binding, modes, bind failures, and long ambient TMPDIR in a child test process.

### New Breakage in the Fix Diff

- **None** - 0 Critical, 0 Important, 0 Minor findings in the supplied three-file fix diff.

### Out-of-Scope Observations

- **None newly identified** - M1/M2 are explicitly deferred in the implementer's report and were not re-reviewed.
- **External acceptance remains pending** - Actual macOS14 arm64/x64 linking, package/install, socket/FD/process-group execution remains unexecuted on this Windows host; this is the existing matching-host acceptance gap, not a remaining I1 source defect or new fix regression.

### Evidence Checks

- **Scope checked** - Read the task brief, verbatim I1, appended fix report, binding Global Constraints/Tooling, Mac ownership ruling, and the complete supplied review package once. Reviewed only I1 and new breakage in `b218336086716e3004e815f009479a83bd4aea71..8768d2d2589c25615d19e251562d956b9f98e1ab`; no Git diff was regenerated.
- **Reported test evidence checked against the diff** - The appended report names the two path-length RED cases and their `InvalidInput: Owner socket path too long` failures; the final helper-lib command reports 9 passed/0 failed, both Mac all-targets checks report exit0, and fmt reports exit0. The named cases and assertions exist in the amended source. These are implementer-reported runs, not independently rerun results; Mac-only tests were compiled, not executed.
- **Windows impact checked** - `scripts/package-desktop.mjs:18-21` builds/copies this helper only for Darwin; `apps/desktop/src-tauri/Cargo.toml` has no runtime-guard dependency; `apps/desktop/runtime-guard/src/lib.rs:1-2` gates the new module to macOS or tests. No Windows rebuild was needed to assess this source-only Mac fix.
- **No focused test run** - Source inspection raised no named unresolved concern that the documented coverage did not answer. Per scoped instructions, no suite/build/SQL/full-volume test was rerun and no production/index/HEAD/branch state was changed.

### Verdict

- **Spec round verdict: PASS** - I1 ADDRESSED; 0 open findings. The source repair satisfies the approved short private root allocation without weakening the AF_UNIX bound or exposing a production root/socket selector.
- **Quality round verdict: PASS** - No new Critical/Important/Minor breakage found in the fix diff; reported coverage matches the amended boundary and failure paths.
- **Fix round: All findings addressed, no new Critical/Important breakage** - 1 addressed, 0 not addressed, 0 new blocking findings. This verdict does not claim full Task14 or matching-host platform acceptance.
