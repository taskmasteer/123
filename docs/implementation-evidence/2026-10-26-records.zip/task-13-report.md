# Task13 implementation report — DONE_WITH_CONCERNS

Committed `da74bb10c7243ed5bade0cd79ce53144e098bf7b` — `feat: add worker health checks and usage accounting`;53scoped files,815insertions/115deletions,worktree clean. Final evidence: units409PASS/2skip with approved maxWorkers1;full SQL120PASS/3skip;native pure4PASS;complete E2E22PASS plus post-full managed2PASS;typecheck/build exit0. Default-worker failures remain separately recorded below.

BASE448883179e20ec4e282941097e470b443510cff5, clean confirmed. Sole production owner, approved preflight/controller rulings; no subagents/live services/providers/GUI. Final15 fix report and receipt/frozen Auth authority read before changes. SQL010 is next unused; portable schema9 must retain header-aware8 compatibility.

## Slice1 usage/activity

- TDD setup added typed monitoring DTOs, executable minimal aggregate/activity skeletons and behavioral tests. Initial default sandbox test could not start Vite Windows helper (spawn EPERM), no behavioral evidence. Narrow escalated `npm.cmd test -- packages/core/test/usage.test.ts` at03:58:15: RED2/2, expected12/8tokens,123ms/20bytes versus empty summary; expected30ms versus0. No missing-import RED claimed. Implementing conservative aggregation and bounded contiguous idempotent activity next.
- GREEN usage/activity2/2 at03:58:39. Health real disposablePG RED1/1 at03:59:41(empty claims), then canonical JSONB expectation fix→GREEN1/1 at04:00:50: independent120slease/6hdue, concurrency deduplication, revoke/version fences, no job mutation. HTTPS classification RED1/62 at04:01:15(raw ENOTFOUND instead of safe dns_pending), GREEN64/64 combined with usage at04:01:41. Existing strict address/DNS-rebind/redirect/TLS/header/body tests preserved. Schema8 activity-smuggling RED1/1 at04:04:29, then schema-aware guard GREEN with usage/pipeline29/29 at04:06:08. Optional activity does not change pipeline recovery fields.

## Interrupted accidental capacity selection — NOT verification

`npm.cmd run test:integration -- health backup recovery-transfer native-managed-backup recovery-visual -t '^(?!.*actual900009)'` started04:08:15; npm.cmd/cmd consumed leading caret, actual Vitest filter became `(?!.*actual900009)` and incorrectly selected the heavy case. Detected by fresh progress artifact, told controller, stopped source edits. This was mutable-source/inadvertent and is never a pass/frozen-full claim. Exact inspected child34172,parent46128,creation04:08:19,command Vitest with those fivefiles/filter was immediately reverified before Stop-Process. First exact-DateTime guard refused because of subsecond precision; no signal then. Second seconds+parent+fullcommand guard matched and stopped ONLY child. Harness finally exited1, owned PostgreSQL stopped and pg-test directory absent; both owned processes absent. No unrelated service/app/process touched.

Last progress: backup metadata84480/900009,331metadata calls+3session+1other,100176.914ms. Controller preserved old reviewed Task15 full artifact under task15-reviewed-transfer-5000.json; overwritten progress is not old evidence. The owned TEMP/site-factory-artifacts-rZwd2A spool was verified parent=resolved TEMP,creation04:08:30,only transport.sqlite182927360B+journal25136B, then removed through native PowerShell LiteralPath after cluster cleanup; absence confirmed. All subsequent filtered SQL commands use direct Node harness. Intended schema9 full gets distinct task13 artifact names.

## Recovery / UI integration iterations

- DirectNode `scripts/test-integration.mjs health backup recovery-transfer native-managed-backup recovery-visual -t '^(?!.*actual900009)'`:38PASS/1heavyfiltered,5files,38.54s at04:11:21. No weakened receipt/Auth/commit guard. Later new40k-row fixture smoke correctly observed385records vs old369(two sites ×8 extra rows); expected count amended to188/site+9. DirectNode health+recovery-transfer at04:17:19:29PASS/1heavyfiltered,20.57s, schema9 durations restored and operational fields absent.
- `npm.cmd test -- apps/worker/test/health.test.ts packages/adapters/test/monitoring-recovery.test.ts packages/core/test/usage.test.ts packages/adapters/test/public-https.test.ts`:70PASS,4files,263ms at04:14:59. Abortable due scheduling, worker stop/no completion, frozen-policy unavailable/no socket, monotonic partial time/offline wait/overlong gap, strict HTTPS and accounting.
- `npm.cmd run typecheck` and build passed at intermediate checkpoints; build103modules570.03kBJS/160.94gzip, existing>500kB advisory remains. `npm.cmd run test:e2e -- monitoring.spec.ts`:1PASS,3.6s at04:18; actual local demo+generated site, scoped/all usage, historical/image/cost unknown captions,1040px no overflow. Initial PNG showed row actions clipped inside horizontal registry; added scoped wrapping/table widths. Final planned E2E reuses these paths: `.local-state/task13-{site-usage,usage}-viewport.png` and root will inspect settled post-wrap output.

## Honest failed gates and storage UUID ruling

- First normal `npm.cmd test` at04:21:44:392PASS/2skip/13FAIL,41files211.68s. One real fixture expectation assumed every `/claim` call was a visual generation claim; new health request is independent and empty-body. Fixture now returns a valid six-hour health response and separately asserts visual job claims plus enrolled/model-free health. Remaining12 failures are5s pipeline/edit and120s5000-scale timeouts, followed by11aftereachEBUSY errors as timed-out work retained SQLite handles. This run overlapped focused SQL/CPU/disk load; it is NOT passing evidence or automatically waived. Four named files are being rerun alone, original guards unchanged, then normal units alone.
- Concurrent directNode focused health/publication/recovery/backup/native-managed/visual at04:22:51:61PASS/2FAIL/1heavyfiltered,77.20s. Both failures are new stored HealthObservation parsing of baseline fixture `md5(...)::uuid` tuples. They are PostgreSQL UUID values with arbitrary version/variant bits, not action IDs accepted by HTTP uuid(v1–5). Controller explicitly approved a separate ONLY read-only stored-observation identity validator with fixed8-4-4-4-12 hex syntax. Same-site/current-publication binding and strict renderer/worker target/claim/token/Auth parsers stay intact; baseline semantic fixture IDs are untouched. Positive arbitrary-version/variant, strict action rejection, malformed syntax and cross-site tuple denial tests added. Affected focused SQL rerun remains pending, not claimed green from earlier iterations.
- C:free10,177,126,400B before native/full gates. No cache removal. Planned Cargo uses local target/testNode plus incremental0/debug-symbols0, serialized with SQL/E2E/full fixture. No GUI/provider/credential acceptance claim.

## Activity coalescing, repeat failures and corrected gates

- The second normal unit run ALONE at04:29:47:397PASS/2skip/9FAIL,41files188.05s. Failures:120s5000-scale;5s publication/pipeline and six editing cases; desktop Retry poll observed running instead of needs_attention. These repeated failures were investigated rather than called harmless load. A focused measurement at04:34:20 demonstrated13 activity hook submissions for one short many-check job versus required<=7 (RED). That fake pipeline fixture counts hook invocations, not physical SQLite fsyncs. Intermediate stage-boundary-only reduction passed the<=7assertion, then controller required actual ending boundaries only.
- Final timer coalesces30s windows and uses optional trusted ActivitySegment on existing Queue.finish/pauseAtBoundary. SQLite/PostgreSQL fold accepted time through the SAME existing fresh lease-authorized transaction; a false boundary neither consumes the sequence nor loses its accrued time. Pending ambiguous submission is immutable; serialized boundary waits for periodic work, replays the identical pending segment and discards any unsealed tail if authority ends. No checkpoint replay fields or queue/publication transitions rewritten. Checkpoint/queue-heartbeat/backoff waits pause measurement without flushing. New Task13 schema DDL only is one startup transaction; legacy initialization was not expanded/optimized on suspicion.
- Actual SQLite regression at04:43:00:3false pause checks+finish=exact4existing transactions,0separate activity calls,30ms preserved. Actual batch pause after prior false check stores40ms; accepted-but-lost-ACK periodic25ms replay at ending adds exactly once; aggregate95ms,one row/job,stale post-end update denied. Combined bounded hook/clock test command3PASS/30filtered,3files1.41s. The pipeline fixture now verifies0separate recordActivity calls for the short run. No test timeout raised.
- Third default unit attempt at04:47:50:403PASS/2skip/6FAIL,42files171.14s. Remaining120s5000-scale and5s repair/edition cases, with four aftereachEBUSY follow-ons. No further repeated default command. Controller approved one ALL-tests `npm.cmd test -- --maxWorkers=1` resource-bounded gate, unchanged5s/120s assertions and in-file concurrency tests; its result must not be described as a default-command pass. That gate is currently pending.
- Clock-skew test first placed an assertion inside cancellation catch and falsely passed; corrected to assert captured delay AFTER scheduler return. Actual RED at04:40:28:1000ms instead of21600000ms when device clock was one day ahead. Server now returns its time with due time; trusted client sleeps their bounded relative difference, clamped at6h. GREEN in the3case focused command above.
- Safe-diagnostic test initially lacked an attached publication (setup NOT behavioral evidence). With actual attached ledger, RED at04:40:55 returned injected unrecognized `raw:SECRET provider url headers body`. `safePublicationDiagnostic` now constructs only allowlisted code/action/time/retryability; archive rejects unsupported diagnostic fields and no raw material crosses publication reads. No unknown-mutation reconciliation/exclusion/fair-selection change.
- Final focused directNode health/publication/recovery-transfer command at04:44:05:55PASS/1heavyfiltered,4files37.81s. Covers stored128-bit UUID compatibility with strict action parsing unchanged, strict schema8/9, actual385record schema9 smoke, copied duration totals/cleared operational fields, lateACK/frozen Auth guards, safe publication diagnostics/quota, PostgreSQL false-boundary→atomic finish and fresh scoped usage. Schema9 smoke artifact `.local-state/task13-transfer-2.json`:385metadata/108physical descriptors,221962metadata bytes/126465body bytes,5backup metadata calls/51restore calls,maxinflight1,maxJSON274533request/274604response,62.9131mscommit. These two-site values are NOT the later5000-site evidence.

## Native read-only schema gate

Every Cargo command explicitly used checkout `.local-state/cargo-target`, SITE_FACTORY_TEST_NODE=C:/Program Files/nodejs/node.exe, CARGO_INCREMENTAL=0, CARGO_PROFILE_DEV_DEBUG=0,CARGO_PROFILE_TEST_DEBUG=0. No caches/binaries removed; no dependency or Cargo.lock change. Initial pure schema gate compiled56.06s then3PASS/1FAIL: new read methods were in the field allowlist but the UUID-validation match arm was missing; duplicate allowlist arm warned. Corrected exact arms; second identical `cargo test --manifest-path apps/desktop/src-tauri/Cargo.toml commands::tests -- --nocapture`:4PASS,17filtered,0warnings,4.61scompile/0stest. It proves fixed read methods, malformed site ID/role/URL override and probe-authority denial, plus existing schemas. No GUI/chooser/OScredential/platform acceptance invoked. C:free8,726,061,056B after compile.

## Implemented behavior / interfaces (final gates pending)

- `contracts/monitoring.ts`: bounded safe read DTOs; stored PostgreSQL tuple syntax separate from action UUIDs; fixed captions;120s health lease/6h interval. PostgreSQL read-only claims are per-site/version/outcome, two slots per enrolled worker, separate from generation/edit jobs and mutation admissions. Complete rechecks worker revocation, token/generation/expiry, domain/current publication and frozen file/policy. Same revision republished under a new outcome does not inherit old healthy status. Never-checked/stale/failure/restored/demo stay distinct.
- Trusted worker probe uses exact registered-domain `/index.html` expectation and frozen supported publisher policy version+hash. Strict verifier retains all-address A+AAAA/public-address rejection, connect-IP pinning/rebind detection, proxy-free agent/Host/SNI/normal CA validation, same-host HTTPS redirects, DNS/header/total/body/header limits, exact MIME/length/SHA256 and required headers. Added only cancellation and safe typed failure categories. Model-free ENROLLED visual workers run independent observations; ordinary desktop clients can read only. Batch pause does not halt health; worker stop aborts sleep/control/probe sockets. No cron or health SQL in publication/UI polling.
- Per-job latest accepted checkpoint token projection remains Task12's durable authority; trusted digest-based helper stays shared with Task15. New usage reads use aggregate SQL and exact physical namespace+key GROUP BY, not whole inventory/graph hydration or cumulative checkpoint sums. Duplicate references do not increase bytes; conflicting physical descriptions fail. Verified retained payload-byte subtotal excludes cumulative writes/database overhead; total remains nullable when complete historical inventory is unproven or shared attribution is incomplete. Partial time is separate one-row/job aggregate, never wall elapsed/CPU/provider bill. Image pending uncertainty retained for newly observed states; historical images/time/price stay unknown, cost null, no dollar stop.
- Admin installation usage and fresh scoped site usage; ordinary site health follows current membership/visibility. Fixed local/native read methods and strict remote response parsers. Russian `HealthStatus` and `UsagePanel`; source/code/keys/private replay never returned. Safe diagnostic minor uses existing publication/account step fences and preserves all unknown-result reconciliation paths.
- Operational010_health_usage.sql; immutable001–009 remain unchanged. Portable output9, legacy8 read compatibility selected from persisted validated header at archive/legacy batch staging/preparation/typed table validation/install. An8header cannot smuggle9tables/fields. Snapshot and restore clear live health claims and activity replay markers, retain known subtotal/coverage and mark observations restored/unverified; quarantine and revoked/new-generation worker authority preserved. Task15 bounded generic batches/cohorts/setwise final activation and frozen Auth/receipt guards remain; operational009 transfer tables are still excluded.
- Representative fixtures add30000activity aggregates+5000private/5000public health rows with partial measurements, stale healthy/TLS/wrong-version observations and live markers that snapshot must remove. Expected940009source metadata before packaged catalog extras; no additional body payloads. Heavy test keeps its old `actual900009` filter marker so existing anchored exclusions remain safe; assertions/counts include13data. Distinct `.local-state/task13-{progress,transfer}-5000.json`, `task13-full-volume.json` and `task13-closure-measured.json` preserve earlier Task12/15 artifacts. Final real counts/bytes/index/calls remain pending; no13.5GB/48GiBbody benchmark implied.

## Settled covering gates and final frozen run

- Controller-approved resource-bounded full normal units: `npm.cmd test -- --maxWorkers=1`, start04:56:07, **409PASS/2existing skips,42files,202.37s**, exit0. Original5s/120s guards and explicit in-file concurrency cases remained active. This is not a default-worker command pass; the three default-command failures above remain evidence and launcher worker budgeting is routed to Task14.
- Refined actual PostgreSQL health claim/completion predicates compare the current immutable same-site publication/artifact/evidence tuple as JSONB inside the existing lock order, with fresh server clock after locks; no hashing/body IO in transaction. Focused directNode health/publication/backup/recovery/native-managed/visual gate at05:07:21: **64PASS/1heavyfiltered,7files,55.00s**, exit0.
- Final schema9 two-site smoke at05:15:50: **1PASS/27filtered,2.77s**, exit0, including aggregate exact known physical bytes versus copied body total, token subtotal/time preservation and bounded usage DTO.
- First full E2E after integration:21PASS/1FAIL because strict managed pagination fixture rejected the newly legitimate site-health GET. Added its safe read DTO to that fixture (no guard/timeout change). Final `npm.cmd run test:e2e`: **22/22PASS,50.1s**, exit0. Final post-wrap1040px PNGs: `.local-state/task13-site-usage-viewport.png` and `.local-state/task13-usage-viewport.png`. Controller inspected both: all registry actions visible/wrapped, neutral count caption fixed, partial/null/demo labels clear; no further UI change requested.
- Final health-only directNode integration at05:22:41: **2/2PASS,1.10s**, exit0, including default production DB-clock assertion. Final `npm.cmd run typecheck`: exit0. Final `npm.cmd run build`: exit0,103modules,570.39kBdesktop JS/161.04kBgzip; existing>500kB chunk advisory remains.
- **Intended frozen full run started** directNode `scripts/test-integration.mjs` (unfiltered, serialized) after source manifest frozen2026-10-29T02:23:51.4618225Z,53source/test files, SHA256 `211D264F217FBC603BB331400A168CD1A06D57EAA6857732BDC6E162E2658B02`, BASE4488831. Manifest `.local-state/task13-final-full-source-manifest.json`. C:free8,694,530,048B; no pg-test directories before start. Owned exec session15326. No source/test changes while running. Full940009 metadata transport/capacity results are pending; no pass inferred from the smaller fixture.

## Self-review before final commit

Read the Task13 diff and all new authority/measurement modules against the approved brief/rulings. Health is outside mutation admission/queue jobs; ordinary clients receive fixed scoped DTOs, frozen expectations remain server-selected, fresh worker/site locks and current publication equality fence completions. Strict action/claim UUID parsing remains unchanged; the full128-bit stored UUID helper is read-only. Activity final/pause submissions reuse the existing freshly authorized transaction and contiguous replay helper; no checkpoint protocol or global retention graph hydration was introduced. Header-specific8/9 allowlists are consumed by staging, preparation, typed validation and setwise installation, with operational markers stripped and restore quarantine preserved. New010 tables/columns do not widen transfer operational tables.

One UI omission found in this self-review: managed-admin navigation did not list the already implemented aggregate usage panel. Source remains frozen during full capacity verification; the small nav correction and covering managed browser/typecheck verification will follow this run, with the backend/capacity source manifest difference explicitly recorded. Existing local PNGs have already been visually accepted by controller. No further UI polish is planned.

Maintainability: the established recovery/worker files are large and dense; changes stay at narrow schema/authority seams and new modules are focused. No unrelated refactoring, plan expansion, new dependency, provider networking or native GUI acceptance was performed. The pure usage helper accepts a bounded caller fixture; installation production summaries use SQL aggregation/deduplication, not whole-graph JavaScript Maps.

## Changed source and test files (scoped)

- `apps/control/src/app.ts`
- `apps/control/src/routes/health.ts`
- `apps/control/src/routes/jobs.ts`
- `apps/desktop/src-tauri/src/commands.rs`
- `apps/desktop/src/app.css`
- `apps/desktop/src/App.tsx`
- `apps/desktop/src/features/settings/UsagePanel.tsx`
- `apps/desktop/src/features/sites/HealthStatus.tsx`
- `apps/desktop/src/features/sites/PublicationPanel.tsx`
- `apps/desktop/src/features/sites/SiteList.tsx`
- `apps/desktop/src/lib/remote-client.ts`
- `apps/worker/src/activity.ts`
- `apps/worker/src/desktop-protocol.ts`
- `apps/worker/src/desktop-runtime.ts`
- `apps/worker/src/health/probe.ts`
- `apps/worker/src/health/scheduler.ts`
- `apps/worker/src/pipeline.ts`
- `apps/worker/src/remote-worker.ts`
- `apps/worker/src/runner.ts`
- `apps/worker/test/health.test.ts`
- `apps/worker/test/managed-runtime.test.ts`
- `apps/worker/test/pipeline.test.ts`
- `packages/adapters/src/local-backup.ts`
- `packages/adapters/src/local-monitoring.ts`
- `packages/adapters/src/postgres-backup.ts`
- `packages/adapters/src/postgres-monitoring.ts`
- `packages/adapters/src/postgres-publication.ts`
- `packages/adapters/src/postgres-queue.ts`
- `packages/adapters/src/postgres-recovery-transfer.ts`
- `packages/adapters/src/postgres-restore-preparation.ts`
- `packages/adapters/src/public-https.ts`
- `packages/adapters/src/recovery-records.ts`
- `packages/adapters/src/retention-schema.ts`
- `packages/adapters/src/sqlite-queue.ts`
- `packages/adapters/test/activity.test.ts`
- `packages/adapters/test/monitoring-recovery.test.ts`
- `packages/adapters/test/public-https.test.ts`
- `packages/contracts/src/model.ts`
- `packages/contracts/src/monitoring.ts`
- `packages/contracts/src/publication.ts`
- `packages/contracts/src/recovery.ts`
- `packages/core/src/activity.ts`
- `packages/core/src/publication.ts`
- `packages/core/src/usage.ts`
- `packages/core/test/usage.test.ts`
- `supabase/migrations/010_health_usage.sql`
- `tests/e2e/managed.spec.ts`
- `tests/e2e/monitoring.spec.ts`
- `tests/integration/health.test.ts`
- `tests/integration/publication.test.ts`
- `tests/integration/recovery-transfer-fixture.ts`
- `tests/integration/recovery-transfer.test.ts`
- `tests/integration/retention-capacity.test.ts`

## Current frozen capacity measurements (suite verdict pending)

Metadata-only5000×6 fixture:670008logical rows+270000physical descriptors+header=940009records. Added representative rows exactly30000job_activity+5000private.health_observations+5000public.health. Raw logical serialization466221230B,file-record serialization81300000B,total raw metadata547521230B; actual stripped snapshot546796386B. Compact index167714952B/160chunks,940169planned ZIP members. Snapshot capture59598.7062ms (capture helper30266.815ms),120001protected roots,heap growth2058416B/RSS16244736B. Closure/GC22252.0623ms,max measured exclusive transaction7534.3181ms. Actual frozen artifacts `.local-state/task13-full-volume.json` and `task13-closure-measured.json`. The13500000000B body field is a projection from descriptors and was never read/uploaded in this fixture (IOcounter0). Upcoming small-body full transport evidence is separate.

## Frozen full verdict — PASS

Unfiltered `& 'C:/Program Files/nodejs/node.exe' scripts/test-integration.mjs`, start05:25:56: **19filesPASS;120testsPASS/3existing skips;1024.87s;exit0**. Exact terminal summary preserved `.local-state/task13-full-gate-output.txt`. Session15326 closed normally; harness finally stopped/deleted its dedicated PostgreSQL cluster, no pg-test directories remained. All53 frozen source/test fingerprints matched after the run (0differences). C:free8652656640B after cleanup.

Actual complete5000-site/six-history transport AFTER trusted encrypted extraction:940009source metadata/270000physical descriptors;544759305Bsmall metadata;222187605Bsmall bodies;940022restored metadata including13packaged catalog records. Inventory SHA256d195c6a68850045fdfdae1c5aa998976b2603a716ccff68c2792021b1f87fbb3. Backup3681metadata/session/other calls (3672metadata pages),restore15295total calls (3672metadata,4219resources,7381prepare,18session,4other,1commit). Maxinflight2,maxJSON683675Brequest/683822Bresponse, within4/2MiB bounds and5000/20000budgets. Actual commit request41393.9585ms,whole transport789795.5109ms; this is a whole request measurement, not a claim that the entire transaction is under15s (individual existing statement guards remain unchanged).

Post-activation assertions passed:30000jobs and one activity aggregate/job;30000000input/15000000output tokens from latest accepted projections;3703680000mspartial duration preserved;all activity replay/health claim markers absent;5000public observations restored/unverified. Aggregate knownBytesStored222187605 exactly equals actually copied physical body bytes;bytesStored/full footprint and estimatedCostUsd remainnull;imageTokens/imagePending remainunknown. Summary stays<1KiB. Fixtures include restored authority/quarantine, lateACKreceipt/frozenAuth, setwise installation, scope and retention checks. This verifies small-body transport/SQL reachability and metadata capacity, not full13500000000Bbody or48GiB archive/cipher throughput. `.local-state/task13-transfer-5000.json` is the Task13 artifact; earlier Task15 reviewed artifact remains separate.


## Final UI-only correction and verification

All53 source/test fingerprints matched after full PASS, before this correction. RED: `npm.cmd run test:e2e -- managed.spec.ts -g 'managed browser harness respects'`:1FAIL/30.1s, missing admin Расход ресурсов button at line70 (original30000ms guard unchanged). Added exactly that admin navigation item. GREEN: `npm.cmd run test:e2e -- managed.spec.ts`:2/2PASS,10.0s,exit0; includes admin aggregate panel visibility and non-admin absence before/after role changes. Actual fresh-role installation/site usage denial is also covered by the full PostgreSQL gate (a caller-supplied admin role for an ordinary member is rejected). No backend/resource contract changed. Fresh `npm.cmd run typecheck`:exit0; `npm.cmd run build`:exit0,103modules,570.42kBJS/161.03kBgzip,existing>500kB advisory. Playwright reports existing NO_COLOR/FORCE_COLOR environment warnings; no test failure or timeout increase in GREEN.

Exact post-full delta `.local-state/task13-post-full-ui-delta.json` SHA25658E58E4638D36F94C7FE03801CCEE7BF8161763D1F4CA83134DA6249962EBBB9: ONLY `apps/desktop/src/App.tsx` and `tests/e2e/managed.spec.ts`; before/after hashes recorded. All51 other frozen files remain identical. No second capacity run was needed or claimed. `git diff --check`:exit0.

Final settled viewport PNGs, visually accepted by controller: `C:/Users/sazur/.codex/visualizations/2026/10/26/01a1777f-1fed-7cf3-9158-96e8e92fe058/site-factory/.local-state/task13-site-usage-viewport.png` and `C:/Users/sazur/.codex/visualizations/2026/10/26/01a1777f-1fed-7cf3-9158-96e8e92fe058/site-factory/.local-state/task13-usage-viewport.png`. Later admin nav correction does not change those local-mode views.

The three full SQL skips are unchanged external acceptance: (1) managed Supabase Auth/sign-in/refresh/invitation/PostgREST requires an authorized project/credentials; (2) real R2 signed-header/conditional-collision/anonymous-GET requires an authorized private bucket; (3) live opt-in REST static envelope/headers/exact alias-content requires SITE_FACTORY_VERCEL_CONTRACT=AUTHORIZE_DEDICATED_DEMO_PROMOTION. None was enabled.

Evidence hashes: Task13 transfer A504FA14E5BEF6217389E39BDFAD2385A9A7EB120A7092A2C623EB6BCEB77B0B;metadata-capacity CA37FEF3848B49D5E99AD2AD8991A54C94C23020CDA94218C2D95E7C6A4AB54B;closure 4EAFFC73C7F819ADAF98C89E933360571D3C99F7BF7B0DEBD8BEE0E6E77188E4.

## Remaining concerns and handoff

Implementation complete within approved scope; independent controller review pending. DONE_WITH_CONCERNS preserves observed default-worker unit failures rather than claiming that command passed: the approved resource-bounded full gate409PASS/2skip is distinct. Task14 owns deterministic launcher resource allocation and external Win11/mac14/headful/provider/physical-device acceptance. Existing bundle-size advisory remains. Historical usage/price/images/full-footprint uncertainty is explicit product behavior; partial duration does not claim CPU, provider billing, perfect suspend detection or complete elapsed time. Full capacity verifies metadata and small-body transport after trusted extraction; no13.5GB/48GiB encrypted-volume benchmark. No live credentials/provider/account/GUI action or unrelated cleanup occurred.


Commit/self-review closure: `da74bb10c7243ed5bade0cd79ce53144e098bf7b`,53files815insertions/115deletions; staged set was empty before scoped add and exact53-file manifest matched the changed/untracked set. Linked Git metadata required narrow escalation after filesystem index.lock denial; no automatic approval rejection. `git status --short` empty after commit. The report and local evidence are orchestration/ignored artifacts, not unrelated production changes. Synthetic fixture provider-provenance/token/duration totals are test data; no paid provider/API usage was measured or incurred. No pushes/merges. Controller independent review is the next gate.

## Fix round1 — I1 synchronous SQLite persistence helper

FIX_BASE `da74bb10c7243ed5bade0cd79ce53144e098bf7b` clean verified. Read exact finding and full review. I1 requested consolidation of the three repeated `job_activity` read→decode→`nextActivity`→upsert folds in `sqlite-queue.ts`, after existing authority checks and without a new transaction/accounting engine. Extracted ONE synchronous closure `activityInTransaction(lease,segment)` with the existing pure validator and identical SQL. `recordActivity` still runs `owned` and quarantine checks first; actual pause still returns false before any fold when no pause is requested; finish still validates final state and current ownership before folding. Each call remains inside the original `run` transaction. No RPC, protocol, schema, PostgreSQL, worker, UI or test implementation changed.

Covering command `npm.cmd test -- packages/adapters/test/activity.test.ts apps/worker/test/pipeline.test.ts --maxWorkers=1`: **2filesPASS/28testsPASS**, start08:10:40,14.86s (tests13.75s),exit0. Existing actual-adapter assertions retained:3false boundaries+finish=4existing transactions/0separate activity submissions,30ms preserved;real pause40ms;immutable accepted/lost-ACK25ms replay contributes once to95ms total;one row/job;stale post-end activity rejected. Existing worker pipeline assertions include no extra ordinary activity submission. This is a behavior-preserving quality extraction: no fabricated RED and no new implementation-mirroring test. Original guards unchanged; no broad unit/SQL/capacity rerun was requested or claimed.

`npm.cmd run typecheck`:exit0. `npm.cmd run build`:exit0,103modules,unchanged570.42kBdesktopJS/161.03kBgzip; existing>500kB advisory retained (M2/Task14). `git diff --check`:exit0. Self-review: exactly one source file changed; helper is synchronous and opens no transaction; all three call sites remain after fresh ownership and preserve previous control flow/replay behavior. No unrelated changes, helpers, provider/GUI/credential actions or cleanup. Review Minors M1/M2 are explicitly deferred per controller and were not modified in this round. Independent scoped rereview of FIX_BASE..fixHEAD remains required.

Fix round1 commit `e45e55df4c5cf4cd83d28d2d75332f9a6f47b573` — `refactor: share SQLite activity persistence fold`;1file,19insertions/3deletions. Scoped cached diff check passed; `git status --short` empty after commit. I1 implementation complete; M1/M2 unchanged and retained for controller/Task14. No push/merge.
