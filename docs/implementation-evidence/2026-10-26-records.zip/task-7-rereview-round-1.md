- **Nested pool acquisition can deadlock revision reconciliation — ADDRESSED.** `packages/adapters/src/supabase-repository.ts:41–42` passes the held transaction into `revision`, removing the second pool checkout. `tests/integration/revision-pool.test.ts:8` bounds checkout/statement timeouts with `max:1`; assertions cover insertion, exact replay, immutable conflict and one stored row.
- **Managed registry stops permanently at 50 — ADDRESSED.** `apps/desktop/src/lib/remote-client.ts:33` forwards validated UUID cursors. `apps/desktop/src/App.tsx:61` fetches the current page; `:124–127` exposes previous/next navigation. SQL/API coverage at `tests/integration/auth.test.ts:39`, client coverage at `apps/desktop/test/remote-client.test.ts:18`, and browser coverage at `tests/e2e/managed.spec.ts:27` exercise more than 50 rows, retry and cursor resets.

### New Breakage in the Fix Diff

None.

### Out-of-Scope Observations

None.

### Verification

Report evidence at `.superpowers/sdd/2026-10-26-site-factory-implementation/task-7-report.md:149–152` names covering commands and records3 client tests passed,13 integration tests passed with2 explicit provider skips,13 browser tests passed, and successful typecheck/build. The added assertions support those coverage claims. No suites rerun.

### Verdict

**Spec compliance:** Both scoped defects are resolved; pagination remains bounded per request, and revision reconciliation preserves transactional admission and immutability checks.

**Task quality:** Appropriate regression coverage, including a bounded reproduction of the original deadlock. Existing live-provider/native acceptance limits remain explicit.

**Fix round:** All findings addressed, no new Critical/Important breakage.
