# Task11 controller handoff

Read task-11-brief.md first, shared-context.md, the final Task10 report/contracts, visual-editor-boundary-preparation.md and visual-native-boundary-preparation.md. Earlier preparation is source-grounded guidance, not platform acceptance.

## Pilot selection boundary ruling

Use the spec's external sandboxed Chromium fallback as the pilot default. Keep the property inspector and explicit Save in the trusted desktop panel. The preview/selection window has no Tauri initialization or native transport. Do not enable generated content or srcdoc inside the main Tauri webview, weaken frame-src/ACL, retry the earlier native GUI approval, or claim mocked origin checks establish actual WebView2/WKWebView attribution.

Reason: pinned Wry0.57.1 ignores main-frame-only initialization on Windows, while actual sandboxed-srcdoc native URL attribution remains unproven on both platforms. Correct native ACL is conditional on actual attribution. The separate Chromium boundary can be exercised independently of Tauri. Cost: pilot selection uses a separate window; a later proven iframe adapter can replace the driver without changing patch semantics.

Keep one small selection-session driver around the existing isolated Chromium lifecycle: fresh sandboxed context/process, scrubbed environment, blocked service workers/permissions/popups/downloads/egress, immutable sanitized projection and generated scripts disabled. Selection callbacks are read-only, strictly schema/source/session/map/revision bound, rate/size limited and revoked on navigation/close/change. No generic browser-to-worker/native RPC, arbitrary page-supplied evaluation, credentials or private checkpoint state. Trusted explicit Save alone constructs the patch and calls the authenticated core path. Never serialize runtime DOM to saved source.

Managed spec-users can be ordinary unenrolled client devices. A read-only projection/selection renderer is not an enrolled generation worker: it must require neither machine credential nor OpenAI key, and must not download the private full archive/checkpoint through an admin-only source API. Use authorized scoped preview projection/map/resources, then send deterministic patch work to the existing trusted-worker validation pipeline. Local demo may use its existing local trusted pipeline. Preserve role/site scope and exact source hashes.

## Save and producer contracts

Explicit visual Save validates source-preserving patches, archives an immutable checked revision and installs it as current draft through expectedRevision CAS. Return that installed Revision. No second candidate-accept click and no implicit publication. Reuse internal candidate validation/evidence/acceptance rather than bypassing the existing accepted-draft publication invariants. A typed deterministic visual producer should bypass ModelPort and automatic AI repairs; failed validation preserves pointers and gives a concrete safe error.

The next AI edit must start from the newly saved actual files and retain manual changes while changing structure. Preserve pinned generation selection/source evidence, recovery and Task9 publication receipt/history. Add no duplicate editing engine. Private maps/projection identifiers never enter public site archives. Reject stale revision/map/source hashes, foreign or rejected candidates and map identities after AI restructures source.

Propose the initial eligible text targets, href policy consistent with existing artifact validation, bounded CSS color/unit/shorthand grammar and handling of existing !important before coding. Keep child structure and unrelated bytes/stylesheets intact; unsupported mixed/implicit targets should fail clearly. Resolve imageAssetId through Task10's owner/site-scoped verified asset seam; do not treat it as a filename/URL or fetch arbitrary remote resources. No structural block editing; user requests that through AI.

Task5 deferred refinement relationship labels belong in the touched chat UI. Actual headful/native launch, Windows11/macOS14/browser packaging and physical-device acceptance remainTask14; headless tests must be labeled accordingly. Pure Rust/mock checks can enforce the main-local command boundary without OS secret access, but are not native-engine proof.

No subagents or live providers/credentials/native GUI; controller provides review. Use the next unused migration number if a focused source-map/asset/operation record is necessary. Every Cargo command retains explicit local target and test Node settings.
