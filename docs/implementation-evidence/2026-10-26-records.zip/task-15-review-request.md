# Task15 independent review dispatch

Review Task15 for spec compliance AND code quality. This is the task-scoped gate; broad whole-branch review follows all tasks. Do not implement, mutate Git/worktree, or spawn any helpers/reviewers. Workdir is the site-factory checkout containing this file; never edit speech.

Read these requirements and evidence first:
- task-15-brief.md (single requirements source)
- shared-context.md (verbatim Global Constraints)
- task-15-controller-rulings.md (approved additional boundaries; judge any mandated design defect independently)
- task-15-report.md in FULL (claims/evidence, not proof of correctness)
- C:/Users/sazur/.codex/skills/subagent-driven-development/task-reviewer-prompt.md (review method and required report format)

BASE is2d2a9e4f9553283e3b66e053b040ea3b7107953a. The controller's launch message supplies final HEAD and generated review-package path. Review the WHOLE supplied BASE..HEAD package once in bounded chunks, not HEAD~1. The package includes log/stat/full contextual diff. Do not reread changed files unless a needed hunk is cut mid-function and explain the reason. No Git requery or broad crawl. Outside-diff checks are only for a concrete named risk, one focused check per risk; cross-cutting public API/locking/ownership semantics are valid named risks.

The report already carries tests: do not repeat suites, whole-load runs or races. Only run a focused test if a specific code doubt is unanswered by existing evidence; explain the doubt. Do not infer that unread/truncated evidence is absent; read it at its path. Treat output warnings as findings with calibrated severity. Missing actual Win11/macOS14/native/provider/full-body acceptance must remain explicit evidence gaps with downstream14 owner.

Write full review to task-15-review.md beside this file. Required: Spec Compliance verdict, Cannot verify from diff items, Strengths with lines, Critical/Important/Minor issues with file:line/cause/impact/fix, task quality verdict. Distinguish tested changes from historical successful runs on earlier source. Return only verdict, issue counts and report path; the controller reads the report in full. Do not pre-grade or suppress findings based on controller rulings.
