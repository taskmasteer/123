# Task10 local persistence feasibility

Controller read-only feasibility check,2026-10-27; not a selected architecture or load/packaging acceptance.

The pinned installed `C:/Program Files/nodejs/node.exe` v24.21.0 can import `node:sqlite` without an additional installed package. An in-memory DatabaseSync with `{allowExtension:false, defensive:true, timeout:1000}` created a STRICT table, inserted through bound parameters and retrieved the expected row. Output: `{"node":"v24.21.0","sqlite":"3.53.4","row":{"value":"works"}}`. Exit0; no filesystem writes or warnings. No production code changed. Persistent durability, migration, concurrency and throughput were not tested.

Official current24.x API documentation search result confirms DatabaseSync operations are synchronous and documents timeout/defensive options: https://nodejs.org/download/release/latest-v24.x/docs/api/sqlite.html . That result was for24.22.1, so do not assume newer APIs such as statement.close() exist in pinned24.21.0. Direct web opening of exact24.21 documentation failed. Do not upgrade bundled Node merely to use this proof.

This is a viable candidate for avoiding an extra native SQLite dependency in the future Task10 local normalized store. If selected, keep SQL behind current ports, parameterize values, disable extension loading, migrate old documents transactionally without deleting originals, retain existing controller ownership, and keep synchronous transactions bounded/yield between batches so heartbeats are not starved. Measure against the Task10 workload before claiming it solves scale. Task12 still needs a consistent snapshot/restore boundary.
