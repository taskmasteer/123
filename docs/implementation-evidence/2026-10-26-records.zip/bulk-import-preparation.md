# Task 10 bulk import preparation

2026-10-27. Preparation, not implementation, review, or acceptance. Read Task 10 brief first, shared context, Task 3 capacity/Task 4 plural ledger entries, and narrow registry/persistence/queue/client/upload/pipeline seams. Brainstorming and graphify guidance consulted; no graph built. No installations, services, suites, credentials, native UI, live APIs, or production changes. Task 7 managed pagination is changing: reuse its eventual contract; this report does not assess that fix.

## Existing boundaries and required interfaces

`contracts/src/model.ts` supplies `SiteInput`, `SiteRepository`, `Queue`; `core/src/sites.ts::normalizeDomain` supplies IDN/ASCII canonicalization. Reuse both normalization and server authorization; preview validation cannot reserve a domain. `SupabaseRepository.create` already inserts site, generation job and site admission together. Extract its transaction-scoped insertion primitive rather than call its independent transaction from a batch transaction. `private.batches` currently contains only id/owner/time.

Keep brief contracts:

```ts
type ImportRow = SiteInput & { rowNumber: number };
type RowIssue = { rowNumber: number; column: string; code: string; message: string };
parseImport(file: {name: string; bytes: Uint8Array}):
  Promise<{rows: ImportRow[]; issues: RowIssue[]}>;
submitBatch(actor: Principal, validRows: ImportRow[], requestKey: string):
  Promise<{batchId: string; siteIds: string[]}>;
pauseBatch(actor: Principal, batchId: string): Promise<void>;
resumeBatch(actor: Principal, batchId: string): Promise<void>;
cancelBatch(actor: Principal, batchId: string): Promise<void>;
```

These are trusted service calls, not 5000-row renderer DTOs. Proposed additive producer → consumer seams:

- Native file picker/resource reader → import service: opaque selected-file handle, bounded bytes; no renderer-supplied arbitrary filesystem path. Persist source privately before preview.
- Import service → `BatchImport/BatchDetail`: `prepareImport(handle): {draftId, validCount, invalidCount}`, `listImportRows(draftId,{cursor,limit,status}): {items,nextCursor}`; items contain original cells, normalized input and issues. Mapping/correction increments draft revision. `commitImport(draftId,expectedRevision,requestKey): {batchId}` resolves frozen valid rows internally into `submitBatch`.
- Managed client → control: authenticated staged import/chunk resources, finalize/hash validation, then draft commit. Enforce serialized byte bounds per chunk, not merely row counts. Native requests and control JSON bodies currently cap at 64,000 bytes. Keep file bytes and the internal `siteIds[]` result outside ordinary requests/responses.
- Batch repository → UI: `getBatch(actor,id): BatchSummary`, `listBatchRows(actor,id,{cursor,limit,status}): Page<BatchRowView>`, `retryBatchRow(actor,id,rowNumber,requestKey): RowOutcome`. Views expose counts/state/siteId/job summary/issues, never private checkpoints/provider history. Extend both Rust/Node protocol allowlists, HTTP validators and `RemoteClient`; unavailable managed operations must stay explicit.
- Registry → UI: extend Task 7's finalized list contract with validated domain/status/batch filters and page limits 1–100. Apply authorization/filters before keyset pagination, use a unique immutable ordering key, and reject cursors reused with incompatible filters. Return a scoped count separately if needed; page length is not total count.

Use UUID identities, UTC milliseconds, schema validation and fresh membership checks. Store invalid rows/source alongside the batch so starting valid rows never discards errors. Authorization checks batch ownership and affected site permissions; read access alone cannot grant mutation rights.

## Persistence and concurrency at 5000 rows

Ledger deferrals are material: `private-json.ts` caps each document at 2,000,000 UTF-8 bytes; `local-queue.ts`, `local-revisions.ts` and editing history grow whole documents. `local-state.ts` separately rewrites all sites with only process-local serialization, without that cap. Increasing caps leaves quadratic rewrites and cross-process lost-write risks.

Recommend a normalized transactional embedded local store for sites/jobs/revisions/batches/rows/request identities, with indexes and enforced single-controller ownership. Partitioned files plus a durable transaction/recovery journal are possible but impose more recovery machinery. Library/runtime selection remains implementation research requiring current primary documentation and pinned dependencies; no package is selected here. Keep artifacts/checkpoint bytes separately immutable. Migrate old demo documents once, validating identities/parents; retain originals until migration commit/reopen succeeds. Retention must preserve active jobs, checkpoint/revision pointers and publication evidence; Task 12 owns broader history cleanup.

Managed storage uses normalized PostgreSQL batch/row/request records. Unique `(actorId,requestKey)` binds a canonical frozen payload hash; exact replay returns the same batch, changed payload gives CONFLICT. Unique `(batchId,rowNumber)` persists outcome, allocated siteId/jobId and input hash. Admit each row in a short transaction: lock batch/check state and fresh permissions; reserve canonical unique domain; insert site/job/site-operation and row outcome atomically. A competing existing domain becomes a row error, never overwrite. Crash/replay cannot leave a site without its job or duplicate successful rows. Distinguish duplicate-domain constraints from unrelated uniqueness conflicts.

Persist batch first, then process bounded pages with durable progress. A failed row cannot roll back accepted siblings. Pause/cancel serialize with row admission and Task 8 claim/commit operations. Pause stops further admissions/claims and lets running work reach its documented boundary; resume does not retry terminal failures automatically. Cancel fences late commits, preserves published content and retains results. Avoid overriding Task 6 explicit provider-recovery rules. No network call belongs inside SQL transactions; process mutexes and read-modify-write JSON are insufficient across instances.

Relate each admitted job to its batch row so claims can enforce durable batch state. Retry a failed execution through the existing site/job identity; never create another site. Validation correction creates a versioned row attempt with retained original issues. Distinguish retryable transport failures, explicit provider-recovery failures, and input/domain errors requiring correction; display row/column, safe reason and next action.

## Bounded parsing and logo mapping

Proposed initial limits: 5000 data rows, 16 MB source, 64 MB aggregate XLSX uncompressed data, 256 ZIP entries, 16 columns, 8000-character about; bound every cell, shared-string table and issue count. Confirm these measured limits during implementation. Reject over-limit input before side effects; never silently truncate. Parse away from renderer, with time/cancellation limits and paginated preview.

CSV: fatal UTF-8 decode, optional BOM, explicit headers/aliases, quoted commas/escaped quotes/embedded newlines, blank cells and malformed quoting. Define rowNumber as 1-based logical record including header; XLSX uses worksheet row. Preserve about per row; blank optional values become absent. Deduplicate canonical domains across the entire import and recheck at commit.

XLSX: accept only bounded OOXML data, explicitly choose one sheet, reject encrypted/macro formats and embedded executable content. Never evaluate formulas, external links or relationships; formula cells get actionable FORMULA_NOT_ALLOWED issues rather than trusting cached values. Bound ZIP expansion while reading, not only declared sizes; reject unsafe entry paths and unsupported cell/error types. Strings beginning `=` remain data; escape spreadsheet-leading formula characters if exporting error CSV later.

`logo` is an import-only local selector, not `logoAssetId` or a URL fetch instruction. Preserve raw selectors privately; missing mapping blocks that row. Add `mapImportLogo(draftId,rowNumber,selectedFileHandle)` returning an owner/draft-bound immutable asset ID plus hash/media/size. Resolve only user-selected files; reject traversal/junction escapes, URLs and ambiguous names. Validate image signature/dimensions/bytes (initial raster allowlist), store privately, and verify ownership/hash at commit. Existing worker upload routes require a live lease, so add a separate authenticated import-asset admission path. Pipeline currently has no logo resolver: inject trusted `readLogo(assetId,siteId)`, copy verified bytes to a deterministic local artifact path before generation/checkpoint, and preserve across retries. Logos remain independent of optional illustrations.

## Evidence to implement later

Behavioral fixtures cover parsing bounds, IDN duplicates, one-row about, logo mapping, mixed valid/error rows and correction. Two SQL connections plus fault barriers cover concurrent same-key requests/domain races, changed payload, crash between row writes, resume/reopen, pause/cancel versus claim and stale-worker commits. Assert stable row outcomes and unique site/job IDs.

Measure 5000 persisted records and 100 fake jobs with two workers, injected failure and pause/resume: parse/admission/page latency, peak process/renderer memory, bytes written, storage size and mutation cost before/after restart. Test data exceeding the old JSON cap. Traverse unchanged datasets with filters/cursors and assert exact set/order, no repeats/skips; bounded page polling must not accumulate all rows. Reuse Task 7 pagination, add local/server filters and Russian `сайт/сайта/сайтов` counts including 1/2/5/11/21. Report measured environment/results explicitly; fake jobs do not prove 5000 real publications. Task 8 durable queue/fencing and Task 7 finalized pagination are prerequisites for integrated claims.
