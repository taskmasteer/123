### Task 4: Desktop-окно и управление локальным исполнителем

**Files:** создать `apps/desktop/package.json`, `apps/desktop/index.html`, `apps/desktop/src/{main.tsx,App.tsx,app.css}`, `apps/desktop/src/features/sites/{SiteList.tsx,CreateSiteDialog.tsx}`, `apps/desktop/src/lib/desktop-client.ts`, `apps/desktop/src-tauri/{Cargo.toml,build.rs,tauri.conf.json}`, `apps/desktop/src-tauri/src/{lib.rs,commands.rs,worker.rs}`, `apps/desktop/src-tauri/capabilities/main.json`, `apps/desktop/src-tauri/permissions/commands.toml`, `apps/worker/src/stdio.ts`; тесты `tests/e2e/create-site.spec.ts`, Rust unit tests рядом с worker.rs.

**Interfaces:** JSON pipe `DesktopRequest = {id: string; version: 1; method: 'site.list' | 'site.create' | 'job.status' | 'preview.open'; params: unknown}`; ответ `{id, result}` либо `{id,error:{code,message}}`. Rust `dispatch(request: DesktopRequest) -> Result<serde_json::Value, AppError>`; TypeScript `DesktopClient.request<T>(method: string, params: unknown): Promise<T>`. Методы проверяются allowlist и схемами, не строкой shell.

- [ ] **1. Написать сценарий:** открыть панель, создать example.test, увидеть этапы, готовый локальный сайт и явную надпись «Демо — без внешних сервисов». Запрос неизвестного метода и неверной protocol version должен завершаться отказом; сгенерированный контент не получает native bridge.
- [ ] **2. Запустить** `npm run test:e2e -- tests/e2e/create-site.spec.ts`; отсутствие UI/bridge даёт ожидаемый failure.
- [ ] **3. Собрать Tauri-приложение и fixed-path worker.** UI содержит список, создание, статус устройства, переключение разделов. Rust запускает только упакованный/явно заданный developer Node и доверенный script; не принимает executable/path из UI. IPC по stdin/stdout, журналы только stderr, завершение процесса при закрытии приложения. Начальный local mode использует один управляющий процесс.
- [ ] **4. Проверить** `npm run typecheck`, `cargo test --manifest-path apps/desktop/src-tauri/Cargo.toml`, e2e и `npm run tauri:dev` на Windows. Custom commands перечислить в AppManifest::commands и дать разрешения только main webview; отсутствие `window.__TAURI__` не считать достаточной защитой. Встроенный preview сначала отображает полученные из Chromium снимки; открываемый interactive preview — отдельный Chromium без IPC.
- [ ] **5. Commit:** `feat: add tauri desktop shell and local site workflow`.

