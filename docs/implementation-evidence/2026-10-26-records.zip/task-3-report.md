# Task 3 implementation report

Status: DONE. Commit: `c268674b40a6dfa132b98990428dcd2565d93bac` (`feat: add resumable generation pipeline and starter styles`). Work stayed in the linked site-factory worktree; no speech files, paid APIs, accounts, external hosting, or third-party asset downloads were used.

## Delivered behavior

- `runJob(job, lease, deps, signal)` persists brief → assets → generate → validate → archive → publication → completed, using a private checkpoint envelope separate from ArtifactStore. Checkpoint metadata contains job/site/base-revision identity, frozen seed/style/version/topic/image, original instruction/conversation, model summaries/token counts, file-tool operations, validation report, repair/transport attempt counts, manifest, intended publication revision, and deterministic publication intent.
- Manual about takes precedence. Blank about gets a deterministic English technology topic associated with its domain. The optional original local network SVG is selected deterministically for 10 of 100 seed residues; at most one is inserted. No image service is called.
- CheckpointStore gained trusted `load(id)`, returning its envelope, private state and file bytes. The worker checks job/site identity, schema, stage, artifacts, successful validation evidence and publication identity before resuming. The immutable private envelope is written and fsynced before the queue points to it. An orphan envelope after interruption is harmless.
- Validation runs the existing hardened real Chromium validator by default. Two repair attempts maximum persist across restarts. Transient model transport failures retry at 1/2/4-second delays, with at most three retries; tests inject the delay rather than sleeping. Quota waits become waiting_provider. Abort pauses at the last durable checkpoint. Lease loss is propagated without a stale finish. The worker renews every 30 seconds and before side effects.
- Every model attempt gets a fresh private FileTools directory loaded from the last committed files. Partial writes from a failed model transport attempt cannot contaminate the retry. Only final website files enter ArtifactStore. There are no brief JSONs, tool logs, prompt histories or resume JSONs in published manifests.
- LocalQueue persists jobs/lease generations atomically, has a 120-second lease, fences stale workers, serializes work for each site, and limits each worker/device ID to two active jobs. It exposes get/retry/close for local orchestration. Paused/provider-wait/attention jobs require explicit retry; the same-site queue remains held behind an unfinished operation.
- FakeModel and FakePublication expose explicit runtimeStatus demo flags. FakeModel is a deterministic template-based local demonstration, with zero reported provider token usage. FakePublication makes no network calls and idempotently reports published.

## Revision and edit contract rulings implemented

- Site.draftId and Site.publishedId refer to Revision.id, not Manifest.id. Added shared immutable RevisionRepository `{ put, get }` and a local implementation; WorkerDeps.revisions is required.
- Archive saves manifest ID, deterministic `jobId:manifestId` intent, intended revision ID and creation time before the first publication call. Only after PublicationPort returns published does the worker register a published Revision, then compare-and-set the Site pointer. Immutable same-record revision put is idempotent. Resume can reconcile an already installed publication by its exact revision and manifest.
- ModelRequest.baseManifestId resolves through the current draft/published Revision. Edit jobs archive a validated candidate result in their private completed checkpoint. They do not mutate Site pointers or revision and never call PublicationPort. Task 5 owns registration/acceptance/rejection of that candidate and the later draft CAS.
- The local fake intent is only an identity. Task 9 must implement real persisted publication intent lookup and hosting state behind PublicationPort, including its atomic promotion and stale-revision protections. No real hosting behavior is claimed here.

## Catalog and five original templates

`createLocalCatalog(sourceRoot, privateRoot)` provides list, prepare(job, batchIndex, seed, referenceId?), load(styleId, version), updateStyle(principal,id,enabled), and updateReference(principal,id,description). prepare rotates enabled styles across a batch, supports source-reference IDs or style IDs, and preserves an already pinned Job.generation. Local mutations call authorize(admin:manage) and persist private overrides. Disabled styles remain loadable for pinned jobs; a missing pinned version raises NOT_FOUND instead of silently selecting a replacement. Actual source versions are release-versioned; changing template source requires a version bump.

The catalog contains all 14 supplied references and the source review date 2026-10-26, composition description, palette description, typography, density and allowed adaptations from the approved reference section. Descriptions are observations from that supplied review, not newly invented exact source color measurements. No reference code, photos, logos or text were copied into template sites.

Five different compositions were authored:

| Style | Structure and typography | Main palette |
|---|---|---|
| light-product | Left-aligned product story with a stepped routing panel, broad open spacing, Segoe UI | #f7fbff, #183254, #174ec2, #e5efff |
| dark-tech | Centered serif headline and horizontal protocol orbit, followed by a two-column technical explanation | #151629, #eff0ff, #bfacf7, #22233d |
| editorial | Oversized condensed agency headline, asymmetric side column and contrasting editorial sections | #f6df4d, #181818, #fffdf6 |
| corporate | Serif business narrative with a solid navy sidebar, service focus columns and sequential process | #ffffff, #23364b, #183e65, #dd8b4c |
| diagram | Persistent side navigation at desktop, large explanatory flow diagram and information definitions | #f4f6fd, #223256, #e2e8f8, #264d9b |

All are original HTML/CSS, local system fonts, English authored content, meaningful local anchors, visible focus, reduced-motion support, and title/charset/viewport/noindex metadata. No forms, fabricated customers/testimonials, frameworks, external shared assets or fake functional buttons. The future Russian ReferenceLibrary React screen remains Task 4 by the controller's ruling; remote admin mutations remain Task 7.

## TDD and self-review evidence

1. Minimal typed skeletons and five pipeline tests produced five real assertion failures (running versus completed/paused/waiting_provider/needs_attention). Implemented the pipeline and observed GREEN.
2. Six storage/catalog/fake publication tests produced six assertion failures for null claims, empty checkpoint state/catalog, missing style rotation and pending publication. Implemented durable adapters/catalog/templates and observed GREEN.
3. Regression RED/GREEN cycles covered reference fallback, bounded transient retry/backoff, private tool transcripts, pre-publication revision conflicts, mismatched intents, edit candidate-only behavior, revision indirection, immutable reopened revision records, malformed persisted running leases, and missing validation evidence. The initial direct-draft edit behavior was replaced before commit following the controller's acceptance-flow ruling.
4. A real adapter integration test closes/reopens the site registry and queue, reopens checkpoint/revision adapters, disables the pinned style, retries the persisted job, and completes using the same manifest/intent/topic without invoking model, template loading or validation again. It verifies that no published Revision exists during waiting_quota and that the final Site pointer resolves through a distinct Revision to the archived Manifest.
5. No browser bypass: ordinary sandbox execution initially failed to spawn Chromium (EPERM). A narrowly approved command escalation let Playwright spawn Chromium while `chromiumSandbox: true` remained unchanged. All preview requests are local and use the existing validator network controls.

Final verification on 2026-10-26:

- `npm.cmd test`: **137 passed, 1 skipped, 7 test files**, exit 0. The existing skipped test is `rejects a symlink file before reading or overwriting its target`; this Windows account lacks file-symlink privilege. Existing junction coverage still runs.
- `npm.cmd run typecheck`: exit 0.
- `npm.cmd run build`: exit 0.
- Five-template real-browser validation covers 375 and 1440 pixels, readable contrast/text, no horizontal overflow, working links and local resource policy. All ten initial screenshots were opened and visually inspected.

## Visual review artifacts

The latest run's screenshot paths are indexed in `.local-state/template-screenshots.json`. The following initial screenshots were personally opened and inspected, all under `.local-state/validation/`:

| Style | 375px | 1440px |
|---|---|---|
| light-product | 780b5a52-43ba-46e8-a6eb-6d5a35fc0cfe.png | 9d38dc11-1284-4780-8ea4-c97822afc592.png |
| dark-tech | 759f6431-cc95-46e8-a95a-dcdd84c81be9.png | bd2e18b1-e1cf-4a76-bdd6-d21075b43140.png |
| editorial | 6fd8bcaf-c8c6-40db-b629-3cd3db991b96.png | e8ac9e66-4f72-4424-aca6-264437f5ed4f.png |
| corporate | e8f22bb6-eca3-4a1b-a639-0e2922e64c49.png | eddb1c2b-fc52-46c5-b242-81c40f045a74.png |
| diagram | 353a32e2-2c9c-425f-b4d8-5fe6d52dd4f5.png | e8c589d8-a164-4fca-af33-47722075bac6.png |

Visual review found clearly different alignments, hierarchy, densities and reading paths. Mobile layouts stack intentionally; navigation remains readable and the diagram remains within its container.

## Integration limits to preserve

- This is local demonstration infrastructure, not cloud synchronization or a verified real model. Local JSON transactions serialize only one controlling process. Task 8 owns production coordination/scheduling.
- FakeModel demonstrates file-tool generation from a manual brief and a pinned template. It does not claim intelligent rewrite/translation or realistic token usage; real provider behavior is a later adapter task.
- Private checkpoints and attempt directories are retained for recovery; lifecycle/retention cleanup is not implemented in this task.
- No macOS/native packaging or real Vercel/API acceptance evidence is claimed. All browser evidence here comes from this Windows host.

## Review fix round 1

Base: `c268674b40a6dfa132b98990428dcd2565d93bac`. Fix commit: `a1a1be81ea717382ea7213839246fdcd17cc8328` (`fix: preserve pending repairs and bound local state writes`). Both Important findings in task-3-review.md were addressed within the local adapter scope.

1. A scheduled repair now stores `pendingRepairInstruction` in the private checkpoint along with the already-incremented repair attempt. Resuming validation first executes that pending instruction, without revalidating unchanged files or charging another attempt. The marker is cleared only after the model produces its output, then that output is checkpointed before validation continues. Persisted state validates the marker's shape, positive attempt count, and stage. Existing checkpoints without a pending marker remain readable. This does not infer/reimburse already-consumed repair attempts from older checkpoints that lacked this metadata.
2. private-json now uses one 2,000,000-byte bound for reads and serialized UTF-8 writes. Oversized state raises AppError INVALID_INPUT before creating a temporary file or replacing the previous state. Subsequent reads/reopen and later smaller writes remain usable. No database or new storage format was introduced.

RED command: `npm.cmd test -- apps/worker/test/pipeline.test.ts packages/adapters/test/private-json.test.ts` — exit 1, **3 expected assertion failures, 13 passes**. Quota and abort cases observed repairAttempts=2 instead of 1 after the second interruption. The oversized transaction incorrectly resolved instead of rejecting.

GREEN covering command: `npm.cmd test -- apps/worker/test/pipeline.test.ts packages/adapters/test/private-json.test.ts apps/worker/test/pipeline-storage.test.ts` — exit 0, **25 passed across 3 files**. Each quota/abort regression interrupts the same repair twice, then supplies successful repair output: one charged repair attempt, the same instruction on all three calls, two total validations, completion and automatic publication. The storage regression uses multibyte UTF-8 text exceeding the byte limit, verifies the previous document after reopening, and verifies a later smaller update succeeds.

Final commands after these source changes:

- `npm.cmd run typecheck` — exit 0.
- `npm.cmd run build` — exit 0.
- `npm.cmd test` — exit 0, **140 passed, 1 existing Windows file-symlink-privilege skip, 8 files / 141 tests**, duration 11.27s. Ran with narrowly approved Chromium process escalation; Chromium's own sandbox remained enabled.
- `git diff --check` — exit 0, no whitespace errors (only the repository's LF→CRLF normalization notices).

Self-review confirmed bounded two-repair behavior is retained for genuinely failed repair outputs, pending work remains private, and serialization capacity failure occurs before any filesystem replacement. No template/UI or publication contract changes were made.

**Capacity boundary for Task 10:** each local JSON document is capped at 2,000,000 serialized UTF-8 bytes, including queue.json and revisions.json. The limit applies to bytes, not a fixed number of records. Queue/revision history still accumulates without pruning; at capacity a mutation is now rejected safely and preserves the last committed document. Scale work must add retention/compaction, partitioning, or another approved persistence strategy before claiming larger sustained workloads. This fix does not increase local storage capacity.
