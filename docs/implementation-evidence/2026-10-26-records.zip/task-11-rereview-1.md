### Finding Verdicts

1. **A late observed revocation cannot persist denial through the revoked saver's own admission.** — **ADDRESSED**. `packages/adapters/src/supabase-repository.ts:159` adds the approved trusted final acceptance port. Under the site lock it rereads the durable candidate and immutable revision, binds the original saver/base/acceptance/admission, refreshes the saver, and commits denial independently of the revoked ordinary editing-store guard (`:173`–175). Successful CAS and completion journal share that transaction (`:181`–182). `packages/core/src/editing.ts:154`–157 and `:245` consume its committed result without another revoked journal transaction. The bounded own-status FORBIDDEN fallback also records observed denial (`apps/control/src/routes/visual.ts:83`–86). The real-adapter late-own-revoke schedule and restored-rights/fresh-repository replay assertions are present at `tests/integration/visual.test.ts:70`–113.

2. **The denial hook marks an already committed Save as failed during the CAS-to-journal window.** — **ADDRESSED**. The early hook checks the installed site plus immutable revision/base/manifest/parent receipt before denying outstanding work (`packages/adapters/src/supabase-repository.ts:151`–152; `packages/core/src/visual/acceptance.ts:11`–12). It completes the old legitimate installed-pointer/pending-journal window. New managed installations atomically write the pointer and completed journal (`packages/adapters/src/supabase-repository.ts:181`–182), and both completed and failed journals reject stale reopening writes (`:226`–227). `tests/integration/visual.test.ts:77`–89 covers a second own-status request after the actual SQL commit and the reconstructed legacy pending journal, followed by completed receipt, single increment and stale-write assertions.

3. **Unrelated original bytes are rewritten on otherwise valid patches.** — **ADDRESSED**. `packages/core/src/visual/html-patch.ts:102` retains the original UTF-8 BOM. Existing attribute edits retain their lexical envelope, and style edits map only declaration spans back to raw HTML attribute spans (`:31`, `:87`–91). `packages/core/src/visual/attribute-spans.ts:10`–23 handles entities, CRLF normalization, original quoting and encoded replacement text; `packages/core/src/visual/css-patch.ts:53`–59 retains untouched declarations and trailing whitespace. Exact-byte and repeated-edit cases at `packages/core/test/visual.test.ts:9`–28 cover BOM, raw/entity quotes, attribute case/spacing, CRLF, an unquoted value and boolean STYLE.

4. **Style editing is advertised for a valid self-closing img but always fails.** — **ADDRESSED**. New style insertion moves before a real self-closing solidus and its preceding whitespace, while distinguishing a slash inside an unquoted attribute value (`packages/core/src/visual/html-patch.ts:32`–34). `packages/core/test/visual.test.ts:29`–39 asserts exact bytes for `<img/>`, `<img />`, both quoted-src forms, and the unquoted-src slash case.

### New Breakage in the Fix Diff

None found. The trusted receipt remains an internal dependency port, existing checkpoint evidence runs before that port, and local acceptance keeps its existing CAS/journal path. Terminal response paths disclose existing Save/Revision receipts, with no new source, archive or projection read after observed denial. The declaration-span and attribute-value changes introduce no identified regression in the fix scope.

### Out-of-Scope Observations

None newly identified. Previously recorded native/platform/provider acceptance, Task12 retention, bundle-size and color-environment limits remain outside this fix round.

### Checks

- Read the required prompt, Task11 brief, Global Constraints, all four previous Important findings verbatim, appended Fix round1 report and the specific controller ruling. Read all 888 lines of the 74,509-byte fix package once in bounded chunks, covering all 13 changed files. No second git diff or broad source review.
- Narrow unchanged context inspected only for named doubts: core evidence/site-read/recovery helpers, repository scoped/fresh/admission guards, and permissions establish the evidence gate, current site-scope checks and authority boundaries; the omitted visual-route admission block establishes the fallback/terminal-response control flow.
- The appended report names the covering files/commands and exit/count summaries: 71 passing tests across core visual/editing, worker pipeline and control preview; 10 passing actual PostgreSQL visual/uploads tests plus one explicitly skipped existing live-R2 test; typecheck and build exit0. The new test cases in the diff support those coverage claims. These remain reported results, not independently rerun acceptance.
- No suite or focused execution was needed: no concrete code doubt remained unanswered by the diff/context and existing reported runs. No production/index/HEAD/branch mutation, native GUI, provider/account access, approval retry or subagent dispatch. Only this scratch review report was written.

### Verdict

**Fix round:** All findings addressed, no new Critical/Important breakage.
